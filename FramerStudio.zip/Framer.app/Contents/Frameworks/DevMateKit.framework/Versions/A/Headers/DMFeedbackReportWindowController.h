//
//  DMFeedbackReportWindowController.h
//  DevMateFeedback
//
//  Copyright (c) 2014-2016 DevMate Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Base class for DMFeedbackController. You should not subclass it.
@interface DMFeedbackReportWindowController : NSWindowController

@end
