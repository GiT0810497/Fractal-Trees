//
//  DMTrialTimeReminderStepController.h
//  DevMateActivations
//
//  Copyright (c) 2014-2016 DevMate Inc. All rights reserved.
//

#import <DevMateKit/DMTrialManualReminderStepController.h>

@interface DMTrialTimeReminderStepController : DMTrialManualReminderStepController

@end
