(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
exports.Defaults = (function() {
  function Defaults() {}

  Defaults.baseFont = {
    "font-family": "-apple-system, Helvetica Neue, Helvetica",
    "font-size": "11px",
    "font-weight": "500",
    lineHeight: "10px",
    "-webkit-user-select": "none",
    "text-rendering": "optimizeLegibility"
  };

  Defaults.colors = {
    layerPanelBackground: "#141414",
    editorBackground: "#181818",
    appBackground: "#141414",
    panelStackBackground: "#141414",
    panelToggleBackground: "#141414",
    panelBackground: "#141414",
    textInputBackground: "#292929",
    textInputBorder: "#000",
    textInputSelectionBackground: "#AAA",
    radioInputSelectColor: '#FFF',
    radioInputLabelColor: '#888888',
    selectInputBackground: "#292929",
    selectInputBorder: "#000",
    inputPlaceholderColor: "#555",
    dialInputBorder: "#000",
    dialInputBackground: "#000",
    dialInputIndicator: "#585858",
    colorPickerNullBackground: "#282828",
    colorPickerNullGridOpacity: 0.25,
    inputCursorColor: "#28AFFA",
    numberColor: "#E8E8E8",
    stringColor: "#E8E8E8",
    curveWidgetLine: "#999999",
    curveWidgetAxis: "#292929",
    curveWidgetBackground: "#1E1E1E",
    segmentSelectedBackground: "#292929",
    segmentDeselectedBackground: "#1E1E1E",
    segmentSelectedText: "white",
    segmentDeselectedText: "#787878",
    highlightColor: "#FEFB00"
  };

  Defaults.borders = {
    panelSegmentBottom: "1px solid #000"
  };

  Defaults.textStyles = {
    rowLabel: _.defaults({
      "font-size": "11px",
      "color": "#888888",
      "font-weight": "500"
    }, Defaults.baseFont),
    rowLabelSelected: _.defaults({
      "font-size": "11px",
      "color": "#888888"
    }, Defaults.baseFont),
    panelToggle: _.defaults({
      "font-size": "10px",
      "font-weight": "600",
      "color": "#888888"
    }, Defaults.baseFont),
    textInput: _.defaults({
      "font-family": "-apple-system, Helvetica Neue, Helvetica",
      "font-size": "11px",
      "font-weight": "600",
      "-webkit-text-fill-color": "white"
    }, Defaults.baseFont),
    textInputHint: _.defaults({
      "font-size": "9px",
      "font-weight": "600",
      "color": "#666666"
    }, Defaults.baseFont),
    selectInput: _.defaults({
      "font-family": "-apple-system, Helvetica Neue, Helvetica",
      "font-size": "11px",
      "font-weight": "500",
      "color": "rgb(232, 232, 232)"
    }, Defaults.baseFont),
    imageInputLabel: _.defaults({
      "font-size": "9px",
      "color": "#888888"
    }, Defaults.baseFont)
  };

  Defaults.metrics = {
    panelStackWidth: 212,
    panelToggleHeight: 22,
    panelToggleIconHeight: 5,
    panelToggleIconWidth: 5,
    panelToggleIconX: 4,
    panelToggleIconY: 8,
    panelToggleLabelX: 11,
    panelToggleLabelY: 5,
    emptyPanelHeight: 50,
    panelPaddingTop: 10,
    panelPaddingBottom: 16,
    panelRowHeight: 30,
    panelRowLabelX: 11,
    panelRowLabelY: 12,
    textInputWidth: 56,
    textInputHeight: 22,
    textInputTop: "0px",
    textInputLeft: "5px",
    textInputBottom: "2px",
    textInputRight: "0px",
    textInputLabelRHSPadding: 6,
    textInputLabelY: 6,
    radioInputSize: 16,
    radioInputBorderWidth: 1,
    radioInputSelectionSize: 6,
    radioInputTextMargin: 11,
    radioInputSelectTop: 0,
    radioInputLockMarginLeft: -26,
    radioInputLockMarginTop: -2,
    selectInputWidth: 120,
    selectInputHeight: 22,
    selectInputTop: 0,
    selectInputLeft: 5,
    selectInputBottom: 1,
    selectInputRight: 0,
    segmentedInputHeight: 22,
    segmentedInputWidth: 120,
    stereoInputLeftX: 81,
    stereoInputLeftY: 6,
    stereoInputGap: 8,
    stereoInputRightY: 6,
    pairedInputGap: 8,
    colorPickerGridShadowColor: "rgba(0,0,0,0.2)",
    colorPickerGridShadowSpread: 0,
    colorPickerGridInset: 4,
    widgetX: 11,
    widgetY: 12,
    widgetSpacingBottom: 22
  };

  Defaults.animations = {
    panelOpen: {
      time: 0.20,
      curve: "ease-in"
    },
    panelClose: {
      time: 0.20,
      curve: "ease-out"
    }
  };

  Defaults.images = {
    iconPanelClosed: "images/icon-panel-closed.pdf",
    iconPanelOpened: "images/icon-panel-opened.pdf",
    iconStepUpActive: "images/icon-code-up-active.png",
    iconStepUpInactive: "images/icon-code-up-inactive.png",
    iconStepDownActive: "images/icon-code-down-active.png",
    iconStepDownInactive: "images/icon-code-down-inactive.png"
  };

  return Defaults;

})();



},{}],2:[function(require,module,exports){
var calculateTree, iterator, parseExpression, parseProduct, parseSum, parseValue, tokenize;

tokenize = function(input, position, output) {
  var char, consumed, ref, remainder, value;
  if (position == null) {
    position = 0;
  }
  if (output == null) {
    output = [];
  }
  if (input === "") {
    output.push({
      type: "end",
      position: position
    });
    remainder = null;
    return output;
  }
  char = input[0];
  consumed = 1;
  switch (char) {
    case "\n":
    case "\t":
    case " ":
      break;
    case "+":
    case "-":
    case "/":
    case "*":
    case "(":
    case ")":
      output.push({
        type: char,
        position: position
      });
      break;
    default:
      if ((value = (ref = /^\d+(\.\d+)?/.exec(input)) != null ? ref[0] : void 0) != null) {
        output.push({
          type: "number",
          position: position,
          value: value
        });
        consumed = value.length;
      } else {
        throw "Unexpected character " + char + " at " + (position + 1);
      }
  }
  remainder = input.substr(consumed);
  position += consumed;
  return tokenize(remainder, position, output);
};

iterator = function(tokens) {
  this.tokens = tokens;
  this.cursor = 0;
  this.expect = function(type) {
    return this.tokens[cursor].type === type;
  };
  this.accept = function() {
    return tokens[this.cursor++];
  };
  this.position = function() {
    return tokens[this.cursor].position + 1;
  };
  return this;
};


/*

Expression	← Sum
Sum			← Product (('+' / '-') Product)*
Product		← Value (('*' / '/') Value)*
Value		← [0-9]+ / '(' Expression ')'
 */

parseExpression = function(tokens) {
  var result;
  result = parseSum(tokens);
  if (!tokens.expect("end")) {
    throw "Expected end of expression at " + (tokens.position());
  }
  return result;
};

parseSum = function(tokens) {
  var left, repeat;
  left = parseProduct(tokens);
  repeat = function(left) {
    var operator, right;
    if (tokens.expect("+") || tokens.expect("-")) {
      operator = accept();
      right = repeat(parseProduct(tokens));
      return {
        type: operator.type,
        left: left,
        right: right,
        children: [left, right]
      };
    } else {
      return left;
    }
  };
  return repeat(left);
};

parseProduct = function(tokens) {
  var left, repeat;
  left = parseValue(tokens);
  repeat = function(left) {
    var operator, right;
    if (tokens.expect("*") || tokens.expect("/")) {
      operator = accept();
      right = repeat(parseValue(tokens));
      return {
        type: operator.type,
        left: left,
        right: right,
        children: [left, right]
      };
    } else {
      return left;
    }
  };
  return repeat(left);
};

parseValue = function(tokens, position) {
  var expression;
  if (position == null) {
    position = 0;
  }
  if (tokens.expect("number")) {
    return {
      type: "value",
      number: parseFloat(tokens.accept().value)
    };
  } else if (tokens.expect("(")) {
    tokens.accept();
    expression = parseSum(tokens);
    if (!tokens.expect(")")) {
      throw "Expected closing ) at " + (tokens.position());
    }
    tokens.accept();
    return expression;
  } else {
    throw "Expected value at " + (tokens.position());
  }
};

calculateTree = function(tree) {
  var left, right;
  if (tree.left != null) {
    left = calculateTree(tree.left);
  }
  if (tree.right != null) {
    right = calculateTree(tree.right);
  }
  switch (tree.type) {
    case "value":
      return tree.number;
    case "*":
      return left * right;
    case "/":
      return left / right;
    case "+":
      return left + right;
    case "-":
      return left - right;
  }
};

exports.calculate = function(expression) {
  var tokens, tree;
  tokens = tokenize(expression);
  tree = parseExpression(iterator(tokens));
  return calculateTree(tree);
};



},{}],3:[function(require,module,exports){
var ColorInput, StringProperty,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

StringProperty = require("./StringProperty").StringProperty;

ColorInput = require("./../input/ColorInput").ColorInput;

exports.ColorProperty = (function(superClass) {
  extend(ColorProperty, superClass);

  function ColorProperty(options) {
    if (options == null) {
      options = {};
    }
    this.validateColor = bind(this.validateColor, this);
    ColorProperty.__super__.constructor.call(this, _.defaults(options, {
      validateValue: this.validateColor,
      editorType: ColorInput
    }));
  }

  ColorProperty.prototype.validateColor = function(value) {
    if (value === "") {
      value = null;
    }
    return value;
  };

  return ColorProperty;

})(StringProperty);



},{"./../input/ColorInput":11,"./StringProperty":9}],4:[function(require,module,exports){
var ParentProperty,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

ParentProperty = require("./ParentProperty").ParentProperty;

exports.FunctionProperty = (function(superClass) {
  extend(FunctionProperty, superClass);

  function FunctionProperty(options) {
    var ref;
    if (options == null) {
      options = {};
    }
    FunctionProperty.__super__.constructor.call(this, _.defaults(options, {
      name: ""
    }));
    this.func = (ref = options.func) != null ? ref : function(value) {
      return value;
    };
    this.defaultArguments = [];
  }

  FunctionProperty.prototype.addArgument = function(argument) {
    this.addChild(argument);
    return this.defaultArguments.push(argument["default"]);
  };

  FunctionProperty.prototype.parseData = function(value) {
    var result;
    result = Utils.parseFunction(value);
    if (result.name !== this.name) {
      return null;
    }
    if (result.args.length === 0) {
      return null;
    }
    return result.args;
  };

  FunctionProperty.prototype.valueAsString = function() {
    var value;
    value = FunctionProperty.__super__.valueAsString.apply(this, arguments);
    if ((value == null) || value === '') {
      return "" + this.name;
    }
    return this.name + "(" + (FunctionProperty.__super__.valueAsString.apply(this, arguments)) + ")";
  };

  FunctionProperty.prototype.call = function() {
    var args;
    args = this.children.map(function(c) {
      return c.value;
    });
    return this.func.apply(this, args);
  };

  FunctionProperty.prototype.reset = function() {
    var argument, i, index, len, ref, results;
    FunctionProperty.__super__.reset.apply(this, arguments);
    ref = this.defaultArguments;
    results = [];
    for (index = i = 0, len = ref.length; i < len; index = ++i) {
      argument = ref[index];
      results.push(this.children[index]["default"] = argument);
    }
    return results;
  };

  return FunctionProperty;

})(ParentProperty);



},{"./ParentProperty":7}],5:[function(require,module,exports){
var NUMBER_REGEX, NumberInput, Property, calculate, property, ref,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

ref = require("./Property"), Property = ref.Property, property = ref.property;

NumberInput = require("./../input/NumberInput").NumberInput;

calculate = require("./Calculator").calculate;

NUMBER_REGEX = /^\s*-?\s*(\d+(\.\d+)?\s*)$/;

exports.NumberProperty = (function(superClass) {
  extend(NumberProperty, superClass);

  function NumberProperty(options) {
    var defStep;
    if (options == null) {
      options = {};
    }
    this.validateNumber = bind(this.validateNumber, this);
    defStep = options.step;
    if (defStep == null) {
      defStep = 1;
    }
    property({
      instance: this,
      name: "min",
      def: options.min
    });
    property({
      instance: this,
      name: "max",
      def: options.max
    });
    property({
      instance: this,
      name: "step",
      def: defStep
    });
    NumberProperty.__super__.constructor.call(this, _.defaults(options, {
      validateValue: this.validateNumber,
      editorType: NumberInput
    }));
    this.decimals = options.decimals;
    if (this.decimals == null) {
      this.decimals = 0;
    }
    this.type = "number";
  }

  NumberProperty.prototype.validateNumber = function(value) {
    var error, result, val;
    val = value;
    val = (function() {
      if (NUMBER_REGEX.test(val)) {
        return parseFloat(val);
      } else {
        if ((value == null) || value.toString().trim() === "") {
          return null;
        } else {
          try {
            result = calculate(val);
            return result;
          } catch (error1) {
            error = error1;
            return this.value;
          }
        }
      }
    }).call(this);
    if (val != null) {
      if (this.min != null) {
        val = Math.max(this.min, val);
      }
      if (this.max != null) {
        val = Math.min(this.max, val);
      }
    }
    return val;
  };

  NumberProperty.prototype.valueAsString = function() {
    var base;
    if (this.value != null) {
      return typeof (base = this.value).toFixed === "function" ? base.toFixed(this.decimals) : void 0;
    }
    return null;
  };

  NumberProperty.prototype.defaultAsString = function() {
    var base;
    if (this["default"] != null) {
      return typeof (base = this["default"]).toFixed === "function" ? base.toFixed(this.decimals) : void 0;
    }
    return null;
  };

  return NumberProperty;

})(Property);



},{"./../input/NumberInput":15,"./Calculator":2,"./Property":8}],6:[function(require,module,exports){
var SelectInput, StringProperty,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty,
  indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

StringProperty = require('./StringProperty').StringProperty;

SelectInput = require('../input/SelectInput').SelectInput;

exports.OptionListProperty = (function(superClass) {
  extend(OptionListProperty, superClass);

  function OptionListProperty(options) {
    if (options == null) {
      options = {};
    }
    this.validateOption = bind(this.validateOption, this);
    this.availableOptions = options.availableOptions;
    OptionListProperty.__super__.constructor.call(this, _.defaults(options, {
      validateValue: this.validateOption,
      editorType: SelectInput,
      availableOptions: {}
    }));
  }

  OptionListProperty.prototype.validateOption = function(value) {
    if (value === "" || !(indexOf.call(Object.keys(this.availableOptions), value) >= 0)) {
      value = null;
    }
    return value;
  };

  return OptionListProperty;

})(StringProperty);



},{"../input/SelectInput":18,"./StringProperty":9}],7:[function(require,module,exports){
var Property,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Property = require("./Property").Property;

exports.ParentProperty = (function(superClass) {
  extend(ParentProperty, superClass);

  Object.defineProperty(ParentProperty.prototype, 'settings', {
    set: function(value) {
      return this.children.map((function(_this) {
        return function(child) {
          return child.settings = value;
        };
      })(this));
    }
  });

  function ParentProperty(options) {
    if (options == null) {
      options = {};
    }
    this.updateChildrenDefaults = bind(this.updateChildrenDefaults, this);
    this.handleChildPropertyValueChange = bind(this.handleChildPropertyValueChange, this);
    this.setChildValues = bind(this.setChildValues, this);
    ParentProperty.__super__.constructor.call(this, _.defaults(options, {}));
    this.children = [];
    this.on("change:default", this.updateChildrenDefaults);
  }

  ParentProperty.prototype.addChild = function(child) {
    child.parent = this;
    child.on("change:value", this.handleChildPropertyValueChange);
    child.on("request", (function(_this) {
      return function(request) {
        return _this.emit("request", request);
      };
    })(this));
    return this.children.push(child);
  };

  ParentProperty.prototype.parseData = function(data) {
    var value;
    value = ParentProperty.__super__.parseData.call(this, data);
    return value.split(',').map(function(value) {
      return value.trim();
    });
  };

  ParentProperty.prototype.setValue = function(values) {
    this.setChildValues(values);
    return ParentProperty.__super__.setValue.call(this, values);
  };

  ParentProperty.prototype.setChildValues = function(values) {
    var data, i, index, len, ref, value;
    if (values == null) {
      return;
    }
    data = [];
    this.disableChildrenUpdates = true;
    for (index = i = 0, len = values.length; i < len; index = ++i) {
      value = values[index];
      data.push((ref = this.children[index]) != null ? ref.setValueWithData(value) : void 0);
    }
    this.value = data;
    return this.disableChildrenUpdates = false;
  };

  ParentProperty.prototype.setChildDefaults = function(defaults) {
    var defaultValue, i, index, len, ref, results;
    results = [];
    for (index = i = 0, len = defaults.length; i < len; index = ++i) {
      defaultValue = defaults[index];
      results.push((ref = this.children[index]) != null ? ref["default"] = defaultValue : void 0);
    }
    return results;
  };

  ParentProperty.prototype.valueAsString = function() {
    var values;
    if (this.value == null) {
      return '';
    }
    values = this.value.filter(function(v) {
      return v != null;
    });
    return values.join(', ');
  };

  ParentProperty.prototype.handleChildPropertyValueChange = function() {
    var child, data, i, len, ref, ref1, value;
    if (this.disableChildrenUpdates) {
      return;
    }
    data = [];
    ref = this.children;
    for (i = 0, len = ref.length; i < len; i++) {
      child = ref[i];
      value = (ref1 = child.getData()) != null ? ref1 : child["default"];
      data.push(value);
    }
    return this.value = data;
  };

  ParentProperty.prototype.updateChildrenDefaults = function(data) {
    var values;
    values = this.parseData(data);
    if (values != null) {
      return this.setChildDefaults(values);
    }
  };

  ParentProperty.prototype.reset = function() {
    ParentProperty.__super__.reset.apply(this, arguments);
    return this.children.map(function(child) {
      return child.reset();
    });
  };

  return ParentProperty;

})(Property);



},{"./Property":8}],8:[function(require,module,exports){
var TextInput, property,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

TextInput = require("./../input/TextInput").TextInput;

exports.property = property = function(options) {
  var def, instance, key, name, validate;
  instance = options.instance, name = options.name, def = options.def, validate = options.validate;
  key = "_" + name;
  return Object.defineProperty(instance, name, {
    get: function() {
      var value;
      value = instance[key];
      if ((value == null) && (def != null)) {
        value = (instance[key] = def);
      }
      return value;
    },
    set: function(value) {
      var current;
      current = instance[key];
      if (validate != null) {
        value = validate(value);
      }
      if (value !== current) {
        return instance.emit("change:" + name, instance[key] = value, current, instance);
      }
    }
  });
};

exports.Property = (function(superClass) {
  extend(Property, superClass);

  function Property(options) {
    if (options == null) {
      options = {};
    }
    this.lockClicked = bind(this.lockClicked, this);
    Property.__super__.constructor.call(this);
    property({
      instance: this,
      name: "value",
      validate: options.validateValue
    });
    property({
      instance: this,
      name: "caption"
    });
    property({
      instance: this,
      name: "abbreviatedCaption"
    });
    property({
      instance: this,
      name: "editorType",
      def: TextInput
    });
    property({
      instance: this,
      name: "dataPath"
    });
    property({
      instance: this,
      name: "default",
      validate: options.validateValue
    });
    _.extend(this, options);
    if (this.abbreviatedCaption == null) {
      this.abbreviatedCaption = this.caption;
    }
    this.type = "plain";
  }

  Property.prototype.setValue = function(value) {
    return this.value = value;
  };

  Property.prototype.lockClicked = function() {
    return this.emit("request", {
      type: "click:lock",
      name: this.dataPath
    });
  };

  Property.prototype.valueAsString = function() {
    if (this.value != null) {
      return this.value.toString();
    }
    return null;
  };

  Property.prototype.defaultAsString = function() {
    if (this["default"] != null) {
      return this["default"].toString();
    }
    return null;
  };

  Property.prototype.parseData = function(data) {
    return data;
  };

  Property.prototype.setValueWithData = function(data) {
    if (data != null) {
      data = this.parseData(data);
    }
    return this.setValue(data);
  };

  Property.prototype.valueToData = function(value) {
    return value;
  };

  Property.prototype.getData = function() {
    return this.valueToData(this.valueAsString());
  };

  Property.prototype.read = function(data, defaults, settings) {
    var defaultValue, result;
    result = this.resolveDataPath(data);
    defaultValue = this.resolveDataPath(defaults);
    this.settings = this.resolveDataPath(settings);
    if (this.settings == null) {
      this.settings = {
        disabled: false
      };
    }
    if (defaultValue != null) {
      this["default"] = defaultValue;
    } else {
      this["default"] = null;
    }
    return this.setValueWithData(result);
  };

  Property.prototype.write = function(data) {
    var currentKey, i, key, keys, len, nrOfKeys, results;
    if ((this.dataPath != null) && (this.value != null) && _.isObject(data)) {
      keys = this.dataPath.split(".");
      nrOfKeys = keys.length;
      currentKey = 1;
      results = [];
      for (i = 0, len = keys.length; i < len; i++) {
        key = keys[i];
        if (currentKey !== nrOfKeys) {
          data = data[key] || {};
          results.push(currentKey++);
        } else {
          results.push(data[key] = this.getData());
        }
      }
      return results;
    }
  };

  Property.prototype.resolveDataPath = function(data) {
    var currentKey, i, key, keys, len, nrOfKeys, result;
    result = null;
    if (_.isObject(data) && (this.dataPath != null)) {
      keys = this.dataPath.split(".");
      nrOfKeys = keys.length;
      currentKey = 1;
      for (i = 0, len = keys.length; i < len; i++) {
        key = keys[i];
        if (currentKey !== nrOfKeys) {
          data = data[key];
          currentKey++;
        } else {
          result = data[key];
        }
      }
    }
    return result;
  };

  Property.prototype.enable = function(enabled) {
    var current;
    if (enabled == null) {
      enabled = true;
    }
    current = !this.settings.disabled;
    this.settings.disabled = !enabled;
    return this.emit("change:enabled", enabled, current, this);
  };

  Property.prototype.reset = function() {
    delete this._value;
    this["default"] = null;
    this.changed = false;
    this.settings = {
      disabled: false
    };
    return this.emit("reset");
  };

  return Property;

})(Framer.EventEmitter);



},{"./../input/TextInput":20}],9:[function(require,module,exports){
var ComboTextInput, Property, property, ref,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

ref = require("./Property"), Property = ref.Property, property = ref.property;

ComboTextInput = require("./../input/ComboTextInput").ComboTextInput;

exports.StringProperty = (function(superClass) {
  extend(StringProperty, superClass);

  function StringProperty(options) {
    if (options == null) {
      options = {};
    }
    StringProperty.__super__.constructor.call(this, _.defaults(options, {
      editorType: ComboTextInput
    }));
    this.type = "string";
  }

  StringProperty.parseString = function(string) {
    return string != null ? typeof string.replace === "function" ? string.replace(/^"(.+(?="$))"$/, '$1') : void 0 : void 0;
  };

  StringProperty.prototype.parseData = function(data) {
    return this.constructor.parseString(data);
  };

  StringProperty.prototype.valueToData = function(value) {
    if (value != null) {
      return "\"" + value + "\"";
    }
    return null;
  };

  return StringProperty;

})(Property);



},{"./../input/ComboTextInput":12,"./Property":8}],10:[function(require,module,exports){
var FramerComponents;

FramerComponents = _.defaults({}, require('./data/ColorProperty'), require('./data/FunctionProperty'), require('./data/NumberProperty'), require('./data/OptionListProperty'), require('./data/ParentProperty'), require('./data/Property'), require('./data/StringProperty'), require('./input/ColorInput'), require('./input/ComboTextInput'), require('./input/DialInput'), require('./input/ImageInput'), require('./input/NumberInput'), require('./input/SegmentedInput'), require('./input/SelectInput'), require('./input/RadioSelectInput'), require('./input/SliderInput'), require('./input/TextInput'), require('./panel/MonoInputRow'), require('./panel/PairedInputRow'), require('./panel/Panel'), require('./panel/PanelRow'), require('./panel/PanelStack'), require('./panel/PanelToggle'), require('./panel/StereoInputRow'), require('./panel/WidgetRow'), require('./widgets/Background'), require('./widgets/Label'), require('./widgets/Curve'), require('./Defaults'));

window.FramerComponents = FramerComponents;



},{"./Defaults":1,"./data/ColorProperty":3,"./data/FunctionProperty":4,"./data/NumberProperty":5,"./data/OptionListProperty":6,"./data/ParentProperty":7,"./data/Property":8,"./data/StringProperty":9,"./input/ColorInput":11,"./input/ComboTextInput":12,"./input/DialInput":13,"./input/ImageInput":14,"./input/NumberInput":15,"./input/RadioSelectInput":16,"./input/SegmentedInput":17,"./input/SelectInput":18,"./input/SliderInput":19,"./input/TextInput":20,"./panel/MonoInputRow":21,"./panel/PairedInputRow":22,"./panel/Panel":23,"./panel/PanelRow":24,"./panel/PanelStack":25,"./panel/PanelToggle":26,"./panel/StereoInputRow":27,"./panel/WidgetRow":28,"./widgets/Background":29,"./widgets/Curve":30,"./widgets/Label":31}],11:[function(require,module,exports){
var ComboTextInput, Defaults, Lock,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

ComboTextInput = require("./ComboTextInput").ComboTextInput;

Lock = require("./../widgets/Lock").Lock;

exports.ColorInput = (function(superClass) {
  extend(ColorInput, superClass);

  function ColorInput(options) {
    if (options == null) {
      options = {};
    }
    this.setColor = bind(this.setColor, this);
    this.updateDisabledState = bind(this.updateDisabledState, this);
    this.handleWidthChange = bind(this.handleWidthChange, this);
    this.handlePropertyReset = bind(this.handlePropertyReset, this);
    this.handlePropertyValueChange = bind(this.handlePropertyValueChange, this);
    this.handleClick = bind(this.handleClick, this);
    ColorInput.__super__.constructor.call(this, _.defaults(options, {
      clip: true,
      backgroundColor: "white",
      borderColor: Defaults.colors.textInputBorder,
      borderWidth: 1,
      borderRadius: 3
    }));
    this.width = Defaults.metrics.textInputWidth;
    this.height = Defaults.metrics.textInputHeight;
    this.property = options.property;
    this.property.on("change:value", this.handlePropertyValueChange);
    this.property.on("change:default", this.handlePropertyValueChange);
    this.property.on("change:enabled", this.updateDisabledState);
    this.property.on("reset", this.handlePropertyReset);
    this.grid = new Layer({
      parent: this,
      clip: true,
      x: Defaults.metrics.colorPickerGridInset,
      y: Defaults.metrics.colorPickerGridInset,
      shadowSpread: Defaults.metrics.colorPickerGridShadowSpread,
      shadowColor: Defaults.metrics.colorPickerGridShadowColor,
      style: {
        background: "url(images/color-well-grid.png) repeat"
      }
    });
    this.overlay = new Layer({
      parent: this,
      width: this.width,
      height: this.height
    });
    this.onMouseDown(this.handleClick);
    this.on("change:width", this.handleWidthChange);
    this.handlePropertyValueChange(this.property.value);
    this.handleWidthChange();
    this.lock = new Lock({
      size: this.size,
      parent: this
    });
    this.lock.onClick(this.property.lockClicked);
  }

  ColorInput.prototype.destroy = function() {
    this.property.off("change:value", this.handlePropertyValueChange);
    this.property.off("change:default", this.handlePropertyValueChange);
    this.property.off("change:enabled", this.updateDisabledState);
    this.property.off("reset", this.handlePropertyReset);
    return this.off(Events.MouseDown, this.handleClick);
  };

  ColorInput.prototype.handleClick = function(event) {
    var frame;
    if (!this.enabled) {
      return;
    }
    frame = this.screenFrame;
    return this.property.emit("request", {
      type: "color",
      dataPath: this.property.dataPath,
      value: this.property.valueAsString() || this.property["default"],
      at: frame
    });
  };

  ColorInput.prototype.handlePropertyValueChange = function(newValue) {
    this.updateDisabledState();
    return this.setColor(newValue);
  };

  ColorInput.prototype.handlePropertyReset = function(newValue) {
    if (newValue == null) {
      newValue = null;
    }
    this.updateDisabledState();
    return this.setColor(newValue);
  };

  ColorInput.prototype.handleWidthChange = function() {
    this.grid.width = this.width - (2 * Defaults.metrics.colorPickerGridInset);
    this.grid.height = this.height - (2 * Defaults.metrics.colorPickerGridInset);
    this.overlay.x = Defaults.metrics.colorPickerGridInset;
    this.overlay.y = Defaults.metrics.colorPickerGridInset;
    this.overlay.width = this.grid.width;
    return this.overlay.height = this.grid.height;
  };

  ColorInput.prototype.updateDisabledState = function() {
    var ref, ref1;
    if ((this.property.settings != null) && this.property.settings.disabled) {
      this.backgroundColor = Defaults.colors.textInputBackground;
      this.grid.visible = false;
      this.overlay.visible = false;
      if ((ref = this.lock) != null) {
        ref.visible = true;
      }
      return this.enabled = false;
    } else {
      this.backgroundColor = this.property.value != null ? "white" : Defaults.colors.colorPickerNullBackground;
      this.grid.visible = true;
      this.overlay.visible = true;
      if ((ref1 = this.lock) != null) {
        ref1.visible = false;
      }
      return this.enabled = true;
    }
  };

  ColorInput.prototype.setColor = function(value) {
    if (value === "null" || value === "undefined") {
      value = null;
    }
    if (value != null) {
      this.grid.opacity = 1;
      this.overlay.backgroundColor = value;
      this.overlay.opacity = 1;
      return this.backgroundColor = Defaults.colors.textInputBackground;
    } else {
      this.grid.opacity = Defaults.colors.colorPickerNullGridOpacity;
      this.overlay.opacity = 0;
      return this.backgroundColor = Defaults.colors.colorPickerNullBackground;
    }
  };

  return ColorInput;

})(Layer);



},{"./../Defaults":1,"./../widgets/Lock":32,"./ComboTextInput":12}],12:[function(require,module,exports){
var Defaults, TextInput,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

TextInput = require("./TextInput").TextInput;

exports.ComboTextInput = (function(superClass) {
  extend(ComboTextInput, superClass);

  function ComboTextInput(options) {
    if (options == null) {
      options = {};
    }
    ComboTextInput.__super__.constructor.call(this, _.defaults(options, {
      width: 120
    }));
    this.inputElement.style["margin-right"] = "23px";
    this.inputElement.style["-webkit-text-fill-color"] = Defaults.colors.stringColor;
  }

  return ComboTextInput;

})(TextInput);



},{"./../Defaults":1,"./TextInput":20}],13:[function(require,module,exports){
var Defaults,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

exports.DialInput = (function(superClass) {
  extend(DialInput, superClass);

  function DialInput(options) {
    if (options == null) {
      options = {};
    }
    this.render = bind(this.render, this);
    this.handleDrag = bind(this.handleDrag, this);
    this.handlePropertyValueChange = bind(this.handlePropertyValueChange, this);
    DialInput.__super__.constructor.call(this, options = _.defaults(options, {
      borderWidth: 1,
      borderColor: Defaults.colors.dialInputBorder,
      backgroundColor: Defaults.colors.dialInputBackground,
      width: 18,
      height: 18,
      clip: false
    }));
    this.property = options.property;
    this.property.on("change:value", this.handlePropertyValueChange);
    this.borderRadius = this.width / 2;
    this.indicator = new Layer({
      parent: this,
      backgroundColor: Defaults.colors.dialInputIndicator,
      width: options.width / 3,
      height: options.width / 3,
      borderRadius: options.width / 6,
      x: options.width / 3 - 1,
      y: -1,
      originY: 1.5
    });
    this.dragger = new Layer({
      parent: this,
      width: this.width,
      height: this.height,
      backgroundColor: null
    });
    this.dragger.draggable.enabled = true;
    this.dragger.draggable.momentum = false;
    this.dragger.draggable.constraints = {
      x: 0,
      y: 0,
      width: this.width,
      height: this.height
    };
    this.dragger.on(Events.DragStart, (function(_this) {
      return function(event) {
        _this.property.emit("request", {
          type: "drag:start"
        });
        _this.rotationNormalizer = Utils.rotationNormalizer();
        _this.mouseStart = {
          x: event.offsetX - (_this.width / 2),
          y: event.offsetY - (_this.height / 2)
        };
        _this.rotationStart = _this.property.value;
        return _this.rotationNormalizer(_this.rotationStart);
      };
    })(this));
    this.dragger.on(Events.Drag, this.handleDrag);
    this.dragger.on(Events.DragEnd, (function(_this) {
      return function() {
        return _this.property.emit("request", {
          type: "drag:end"
        });
      };
    })(this));
    this.render();
  }

  DialInput.prototype.destroy = function() {
    this.dragger.off(Events.Drag, this.handleDrag);
    return DialInput.__super__.destroy.call(this);
  };

  DialInput.prototype.handlePropertyValueChange = function() {
    return this.render();
  };

  DialInput.prototype.handleDrag = function(event) {
    var angle, angle1, angle2, currentpoint, rotation;
    currentpoint = {
      x: event.offsetX - (this.width / 2),
      y: event.offsetY - (this.height / 2)
    };
    angle1 = Math.atan2(this.mouseStart.y, this.mouseStart.x);
    angle2 = Math.atan2(currentpoint.y, currentpoint.x);
    angle = angle1 - angle2;
    angle = angle * 180 / Math.PI;
    rotation = this.rotationStart - angle;
    rotation = this.rotationNormalizer(rotation);
    return this.property.value = rotation;
  };

  DialInput.prototype.render = function() {
    var unit, value;
    if ((this.property.settings != null) && this.property.settings.disabled) {
      this.visible = false;
      return;
    } else {
      this.visible = true;
    }
    if (this.property.value != null) {
      value = this.property.value;
    } else {
      value = this.property["default"] || 0;
    }
    unit = this.property.unit || 1;
    return this.indicator.rotation = value * (360 / unit);
  };

  return DialInput;

})(Layer);



},{"./../Defaults":1}],14:[function(require,module,exports){
var Defaults, Label, Lock,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

Label = require("./../widgets/Label").Label;

Lock = require("./../widgets/Lock").Lock;

exports.ImageInput = (function(superClass) {
  extend(ImageInput, superClass);

  function ImageInput(options) {
    if (options == null) {
      options = {};
    }
    this.updateDisabledState = bind(this.updateDisabledState, this);
    this.handleClick = bind(this.handleClick, this);
    this.property = options.property;
    ImageInput.__super__.constructor.call(this, _.defaults(options, {
      clip: true,
      width: Defaults.metrics.textInputWidth,
      height: Defaults.metrics.textInputHeight,
      backgroundColor: Defaults.colors.textInputBackground,
      borderColor: Defaults.colors.textInputBorder,
      borderWidth: 1,
      borderRadius: 3
    }));
    this.onMouseDown(this.handleClick);
    this.label = new Label({
      parent: this,
      textStyle: Defaults.textStyles.imageInputLabel,
      caption: this.property.caption || "Untitled"
    });
    this.label.center();
    this.label.x = Math.round(this.label.x);
    this.label.y = Math.round(this.label.y);
    this.property = options.property;
    this.property.on("change:value", this.updateDisabledState);
    this.property.on("change:default", this.updateDisabledState);
    this.property.on("change:enabled", this.updateDisabledState);
    this.property.on("reset", this.updateDisabledState);
    this.lock = new Lock({
      size: this.size,
      parent: this
    });
    this.lock.onClick(this.property.lockClicked);
  }

  ImageInput.prototype.destroy = function() {
    this.off(Events.MouseDown, this.handleClick);
    this.label.off(Events.MouseDown, this.handleClick);
    this.property.off("change:value", this.updateDisabledState);
    this.property.off("change:default", this.updateDisabledState);
    this.property.off("change:enabled", this.updateDisabledState);
    return this.property.off("reset", this.updateDisabledState);
  };

  ImageInput.prototype.handleClick = function(event) {
    var frame;
    if (!this.enabled) {
      return;
    }
    frame = this.screenFrame;
    return this.property.emit("request", {
      type: "image",
      dataPath: this.property.dataPath,
      value: this.property.valueAsString(),
      at: frame
    });
  };

  ImageInput.prototype.updateDisabledState = function() {
    var ref, ref1;
    if ((this.property.settings != null) && this.property.settings.disabled) {
      this.enabled = false;
      if ((ref = this.lock) != null) {
        ref.visible = true;
      }
      return this.label.visible = false;
    } else {
      this.enabled = true;
      if ((ref1 = this.lock) != null) {
        ref1.visible = false;
      }
      return this.label.visible = true;
    }
  };

  return ImageInput;

})(Layer);



},{"./../Defaults":1,"./../widgets/Label":31,"./../widgets/Lock":32}],15:[function(require,module,exports){
var Defaults, TextInput,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

TextInput = require("./TextInput").TextInput;

exports.NumberInput = (function(superClass) {
  extend(NumberInput, superClass);

  function NumberInput(options) {
    if (options == null) {
      options = {};
    }
    this.unfocus = bind(this.unfocus, this);
    this.focus = bind(this.focus, this);
    this.handleStep = bind(this.handleStep, this);
    this.handleStepDown = bind(this.handleStepDown, this);
    this.handleStepUp = bind(this.handleStepUp, this);
    NumberInput.__super__.constructor.call(this, _.defaults(options, {}));
    this.property = options.property;
    this.step = this.property.step != null ? this.property.step : 1;
    this._element.addEventListener("keydown", this.handleKeyDown = (function(_this) {
      return function(event) {
        if (event.keyCode === 38) {
          _this.handleStepUp(event);
          event.stopImmediatePropagation();
          return event.preventDefault();
        } else if (event.keyCode === 40) {
          _this.handleStepDown(event);
          event.stopImmediatePropagation();
          return event.preventDefault();
        }
      };
    })(this));
    this.inputElement.style["-webkit-text-fill-color"] = Defaults.colors.numberColor;
  }

  NumberInput.prototype.destroy = function() {
    this._element.removeEventListener("keyup", this.handleKeyDown);
    return NumberInput.__super__.destroy.apply(this, arguments).destroy();
  };

  NumberInput.prototype.handleStepUp = function(event) {
    var step;
    step = this.step;
    if (event.shiftKey) {
      step *= 10;
    }
    return this.handleStep(step);
  };

  NumberInput.prototype.handleStepDown = function(event) {
    var step;
    step = this.step;
    if (event.shiftKey) {
      step *= 10;
    }
    return this.handleStep(-step);
  };

  NumberInput.prototype.handleStep = function(step) {
    if ((this.property.value == null) || isNaN(this.property.value)) {
      if (parseFloat(this.property["default"]) == null) {
        this.property.value = 0;
      } else {
        this.property.value = parseFloat(this.property["default"]);
      }
    } else {
      this.property.value += step;
    }
    return this.focus();
  };

  NumberInput.prototype.focus = function() {
    this.inputElement.focus();
    if (this.value != null) {
      return this.inputElement.setSelectionRange(0, this.value.toString().length);
    }
  };

  NumberInput.prototype.unfocus = function(event) {};

  return NumberInput;

})(TextInput);



},{"./../Defaults":1,"./TextInput":20}],16:[function(require,module,exports){
var Defaults, Label, LabeledRadioInput, Lock, RadioInput, setupStyles,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

Defaults = require('../Defaults').Defaults;

Label = require('../widgets/Label').Label;

Lock = require("./../widgets/Lock").Lock;

setupStyles = function() {
  var selectionSpacing, styleElement, styleSheet;
  styleElement = document.createElement("style");
  document.head.appendChild(styleElement);
  styleSheet = styleElement.sheet;
  styleSheet.insertRule(".FramerComponentsRadioInput {\n	display: block;\n	height: " + Defaults.metrics.radioInputSize + "px;\n	width: " + Defaults.metrics.radioInputSize + "px;\n	vertical-align: middle;\n	margin: 0;\n	border: " + Defaults.metrics.radioInputBorderWidth + "px solid " + Defaults.colors.textInputBorder + ";\n	background: " + Defaults.colors.textInputBackground + ";\n	-webkit-appearance: none;\n	border-radius:100%;\n}", 0);
  selectionSpacing = (Defaults.metrics.radioInputSize - Defaults.metrics.radioInputSelectionSize) / 2 - Defaults.metrics.radioInputBorderWidth * 2;
  styleSheet.insertRule(".FramerComponentsRadioInput:checked:before {\n	display: block;\n	height: " + Defaults.metrics.radioInputSelectionSize + "px;\n	width: " + Defaults.metrics.radioInputSelectionSize + "px;\n	position: relative;\n	left: " + (selectionSpacing + 1) + "px;\n	top: " + (selectionSpacing + 1) + "px;\n	background: " + Defaults.colors.radioInputSelectColor + ";\n	border-radius: 100%;\n	border: " + Defaults.metrics.radioInputBorderWidth + "px solid " + Defaults.colors.radioInputSelectBorderColor + ";\n	content: '';\n	}", 0);
  styleSheet.insertRule(".FramerComponentsRadioInput.DefaultOption:before {\n	display: block;\n	height: " + Defaults.metrics.radioInputSelectionSize + "px;\n	width: " + Defaults.metrics.radioInputSelectionSize + "px;\n	position: relative;\n	left: " + selectionSpacing + "px;\n	top: " + selectionSpacing + "px;\n	background: " + Defaults.colors.inputPlaceholderColor + ";\n	border-radius: 100%;\n	border: " + Defaults.metrics.radioInputBorderWidth + "px solid " + Defaults.colors.textInputBackground + ";\n	content: '';\n	}", 0);
  styleSheet.insertRule(".FramerComponentsRadioInput:disabled {\n	opacity: .6;\n}", 0);
  return styleSheet.insertRule(".FramerComponentsRadioInput:focus {\n	outline: 0;\n}", 0);
};

setupStyles();

RadioInput = (function(superClass) {
  extend(RadioInput, superClass);

  RadioInput.define('enabled', {
    set: function(enabled) {
      if (enabled) {
        return this.inputElement.removeAttribute("disabled");
      } else {
        this.inputElement.setAttribute("disabled", "true");
        return this["default"] = false;
      }
    }
  });

  RadioInput.define('checked', {
    set: function(checked) {
      return this.inputElement.checked = checked;
    }
  });

  RadioInput.define('default', {
    get: function() {
      return this.inputElement.classList.contains('DefaultOption');
    },
    set: function(isDefault) {
      if (isDefault) {
        return this.inputElement.classList.add('DefaultOption');
      } else {
        return this.inputElement.classList.remove('DefaultOption');
      }
    }
  });

  function RadioInput(options) {
    if (options == null) {
      options = {};
    }
    RadioInput.__super__.constructor.call(this, _.defaults(options, {
      width: Defaults.metrics.radioInputSize,
      height: Defaults.metrics.radioInputSize,
      backgroundColor: null,
      ignoreEvents: false
    }));
    this.createInputElement(options.group, options.value);
    this._element.appendChild(this.inputElement);
  }

  RadioInput.prototype.createInputElement = function(group, value) {
    this.inputElement = document.createElement("input");
    this.inputElement.setAttribute("type", "radio");
    this.inputElement.setAttribute("tabindex", "1");
    this.inputElement.name = group;
    this.inputElement.value = value;
    return this.inputElement.className = "FramerComponentsRadioInput";
  };

  return RadioInput;

})(Layer);

LabeledRadioInput = (function(superClass) {
  extend(LabeledRadioInput, superClass);

  LabeledRadioInput.define('default', {
    set: function(isDefault) {
      return this.radio["default"] = isDefault;
    }
  });

  LabeledRadioInput.define('checked', {
    set: function(checked) {
      this.radio.checked = checked;
      if (checked) {
        return this.label.color = Defaults.colors.radioInputSelectColor;
      } else {
        return this.label.color = Defaults.colors.radioInputLabelColor;
      }
    }
  });

  LabeledRadioInput.define('enabled', {
    get: function() {
      var ref;
      return (ref = this._enabled) != null ? ref : true;
    },
    set: function(newValue) {
      this._enabled = newValue;
      this.lock.visible = !this._enabled;
      this.radio.enabled = this._enabled;
      if (!this._enabled) {
        return this.checked = false;
      }
    }
  });

  function LabeledRadioInput(options) {
    var lockMargin;
    LabeledRadioInput.__super__.constructor.call(this, _.defaults(options, {
      backgroundColor: null
    }));
    this.value = options.value;
    this.radio = new RadioInput({
      group: options.group,
      value: options.value,
      parent: this
    });
    lockMargin = 20;
    this.radio.inputElement.addEventListener("change", (function(_this) {
      return function() {
        return _this.emit("change:value", _this, _this.radio.inputElement.value);
      };
    })(this));
    this.height = this.radio.height;
    this.label = new Label({
      parent: this,
      x: this.radio.width + Defaults.metrics.radioInputTextMargin,
      caption: options.name,
      color: Defaults.colors.radioInputLabelColor,
      textStyle: Defaults.textStyles.rowLabel
    });
    this.width = this.label.maxX + Defaults.metrics.radioInputTextMargin;
    this.label.centerY();
    this.lock = new Lock({
      x: Defaults.metrics.radioInputLockMarginLeft,
      y: Defaults.metrics.radioInputLockMarginTop,
      width: this.width - Defaults.metrics.radioInputLockMarginLeft,
      height: this.height - Defaults.metrics.radioInputLockMarginTop,
      parent: this,
      property: this.property
    });
  }

  LabeledRadioInput.prototype.highlight = function() {
    var animation, highlight, margin;
    margin = 5;
    highlight = new Layer({
      parent: this,
      width: this.width + margin,
      height: this.height + margin,
      x: -margin / 2,
      y: -margin / 2,
      borderColor: Defaults.colors.highlightColor,
      borderWidth: 2,
      backgroundColor: null
    });
    animation = highlight.animate({
      properties: {
        opacity: 0
      }
    });
    return animation.onAnimationEnd(function() {
      return highlight.destroy();
    });
  };

  return LabeledRadioInput;

})(Layer);

exports.RadioSelectInput = (function(superClass) {
  extend(RadioSelectInput, superClass);

  function RadioSelectInput(options) {
    this.updateDisabledState = bind(this.updateDisabledState, this);
    this.enable = bind(this.enable, this);
    this.disable = bind(this.disable, this);
    this.handlePropertyReset = bind(this.handlePropertyReset, this);
    this.handleDefaultValueChange = bind(this.handleDefaultValueChange, this);
    this.handlePropertyValueChange = bind(this.handlePropertyValueChange, this);
    var count, height, labeledRadio, name, value, width;
    RadioSelectInput.__super__.constructor.call(this, _.defaults(options, {
      backgroundColor: null
    }));
    this.property = options.property;
    count = 0;
    options = this.property.availableOptions;
    height = 0;
    width = 0;
    this.radios = [];
    for (value in options) {
      name = options[value];
      labeledRadio = new LabeledRadioInput({
        parent: this,
        y: count * 20 + Defaults.metrics.radioInputSelectTop,
        group: this.property.dataPath,
        name: name,
        value: value,
        property: this.property
      });
      labeledRadio.on("change:value", (function(_this) {
        return function(radio, value) {
          return _this.selectRadio(radio);
        };
      })(this));
      this.radios.push(labeledRadio);
      labeledRadio.onClick((function(_this) {
        return function(event, clickedRadio) {
          if (clickedRadio.enabled) {
            return _this.selectRadio(clickedRadio);
          }
        };
      })(this));
      count++;
      height = labeledRadio.maxY;
      width = Math.max(width, labeledRadio.maxX);
    }
    this.height = height;
    this.width = width;
    this.disabled = false;
    this.updateDisabledState();
    this.onMouseDown((function(_this) {
      return function() {
        if (_this.disabled) {
          return _this.property.emit("request", {
            type: "click:lock",
            name: _this.property.dataPath
          });
        }
      };
    })(this));
    this.updateValue(this.property.value);
    this.handleDefaultValueChange();
    this.property.on("change:value", this.handlePropertyValueChange);
    this.property.on("change:default", this.handleDefaultValueChange);
    this.property.on("change:enabled", this.updateDisabledState);
    this.property.on("reset", this.handlePropertyReset);
  }

  RadioSelectInput.prototype.destroy = function() {
    this.property.off("change:value", this.handlePropertyValueChange);
    this.property.off("change:default", this.handleDefaultValueChange);
    this.property.off("change:enabled", this.updateDisabledState);
    this.property.off("reset", this.handlePropertyReset);
    return RadioSelectInput.__super__.destroy.apply(this, arguments).destroy();
  };

  RadioSelectInput.prototype.selectRadio = function(radio) {
    var value;
    value = radio.value;
    this.property.setValue(value);
    return this.updateValue(value);
  };

  RadioSelectInput.prototype.handlePropertyValueChange = function() {
    this.updateDisabledState();
    return this.updateValue(this.property.valueAsString());
  };

  RadioSelectInput.prototype.handleDefaultValueChange = function() {
    var i, len, radio, ref, results;
    if (this.property.value == null) {
      ref = this.radios;
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        radio = ref[i];
        results.push(radio["default"] = radio.value === this.property["default"]);
      }
      return results;
    }
  };

  RadioSelectInput.prototype.handlePropertyReset = function(newValue) {
    if (newValue == null) {
      newValue = null;
    }
    this.updateDisabledState();
    return this.updateValue(newValue);
  };

  RadioSelectInput.prototype.updateValue = function(value) {
    var i, len, radio, ref, results;
    ref = this.radios;
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      radio = ref[i];
      if (value != null) {
        radio["default"] = false;
      }
      if (radio.enabled) {
        results.push(radio.checked = value === radio.value);
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  RadioSelectInput.prototype.highlight = function(value) {
    var i, len, radio, ref, results;
    ref = this.radios;
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      radio = ref[i];
      if (value === radio.value) {
        results.push(radio.highlight());
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  RadioSelectInput.prototype.disable = function() {
    this.disabled = true;
    return this.radios.map(function(radio) {
      return radio.enabled = false;
    });
  };

  RadioSelectInput.prototype.enable = function() {
    this.disabled = false;
    return this.radios.map(function(radio) {
      return radio.enabled = true;
    });
  };

  RadioSelectInput.prototype.updateDisabledState = function() {
    if (this.property.settings == null) {
      if (this.disabled) {
        this.enable();
      }
      return;
    }
    if (this.property.settings.disabled && !this.disabled) {
      return this.disable();
    } else if (this.disabled && !this.property.settings.disabled) {
      return this.enable();
    }
  };

  return RadioSelectInput;

})(Layer);



},{"../Defaults":1,"../widgets/Label":31,"./../widgets/Lock":32}],17:[function(require,module,exports){
var Defaults, Label, Segment,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

Defaults = require('../Defaults').Defaults;

Label = require('../widgets/Label').Label;

Segment = (function(superClass) {
  extend(Segment, superClass);

  function Segment(options) {
    if (options == null) {
      options = {};
    }
    Object.defineProperty(this, "selected", {
      get: function() {
        return this._selected;
      },
      set: function(value) {
        if (value) {
          return this.select();
        } else {
          return this.deselect();
        }
      }
    });
    Segment.__super__.constructor.call(this, _.defaults(options, {
      caption: "",
      selected: false
    }));
    this.label = new Label({
      parent: this,
      caption: options.caption,
      point: Align.center
    });
    this.label.center();
    this.selected = options.selected;
    this.value = options.value;
  }

  Segment.prototype.select = function() {
    this._selected = true;
    this.backgroundColor = Defaults.colors.segmentSelectedBackground;
    return this.label.color = Defaults.colors.segmentSelectedText;
  };

  Segment.prototype.deselect = function() {
    this._selected = false;
    this.backgroundColor = Defaults.colors.segmentDeselectedBackground;
    return this.label.color = Defaults.colors.segmentDeselectedText;
  };

  return Segment;

})(Layer);

exports.SegmentedInput = (function(superClass) {
  extend(SegmentedInput, superClass);

  function SegmentedInput(options) {
    var count, divider, option, segment, segmentWidth, value;
    if (options == null) {
      options = {};
    }
    this.selectSegment = bind(this.selectSegment, this);
    this.handlePropertyReset = bind(this.handlePropertyReset, this);
    this.handlePropertyValueChange = bind(this.handlePropertyValueChange, this);
    SegmentedInput.__super__.constructor.call(this, _.defaults(options, {
      width: Defaults.metrics.segmentedInputWidth,
      height: Defaults.metrics.segmentedInputHeight,
      backgroundColor: Defaults.colors.textInputBackground,
      borderColor: Defaults.colors.textInputBorder,
      borderWidth: 1,
      borderRadius: 3,
      clip: true
    }));
    this.property = options.property;
    this.segments = {};
    count = 0;
    options = this.property.availableOptions;
    segmentWidth = (this.width - 2) / Object.keys(options).length;
    for (value in options) {
      option = options[value];
      segment = new Segment({
        height: this.height - 2,
        width: segmentWidth,
        caption: option,
        parent: this,
        x: segmentWidth * count,
        selected: count === 0,
        value: value
      });
      segment.onClick(this.selectSegment);
      this.segments[value] = segment;
      if (count > 0) {
        divider = new Layer({
          height: this.height,
          width: 1,
          x: count * segmentWidth,
          backgroundColor: Defaults.colors.textInputBorder,
          parent: this
        });
      }
      count++;
    }
    this.updateValue(this.property.value);
    this.property.on("change:value", this.handlePropertyValueChange);
    this.property.on("change:default", this.handlePropertyValueChange);
    this.property.on("reset", this.handlePropertyReset);
  }

  SegmentedInput.prototype.destroy = function() {
    this.property.off("change:value", this.handlePropertyValueChange);
    this.property.off("change:default", this.handlePropertyValueChange);
    this.property.off("reset", this.handlePropertyReset);
    return SegmentedInput.__super__.destroy.apply(this, arguments).destroy();
  };

  SegmentedInput.prototype.handlePropertyValueChange = function() {
    return this.updateValue(this.property.valueAsString());
  };

  SegmentedInput.prototype.handlePropertyReset = function(newValue) {
    if (newValue == null) {
      newValue = null;
    }
    return this.updateValue(newValue);
  };

  SegmentedInput.prototype.updateValue = function(newValue) {
    var ref, results, segment, value;
    ref = this.segments;
    results = [];
    for (value in ref) {
      segment = ref[value];
      if (value === newValue) {
        results.push(segment.selected = true);
      } else {
        results.push(segment.selected = false);
      }
    }
    return results;
  };

  SegmentedInput.prototype.selectSegment = function(event, selectedSegment) {
    var value;
    value = selectedSegment.value;
    this.property.setValue(value);
    return this.updateValue(value);
  };

  return SegmentedInput;

})(Layer);



},{"../Defaults":1,"../widgets/Label":31}],18:[function(require,module,exports){
var Defaults, TextInput, setupStyles,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require('../Defaults').Defaults;

TextInput = require('./TextInput').TextInput;

setupStyles = function() {
  var fontrules, key, ref, styleElement, styleSheet, value;
  styleElement = document.createElement("style");
  document.head.appendChild(styleElement);
  styleSheet = styleElement.sheet;
  fontrules = "";
  ref = Defaults.textStyles.selectInput;
  for (key in ref) {
    value = ref[key];
    fontrules += key + ": " + value + ";";
  }
  styleSheet.insertRule(".FramerComponentsSelectInput {\n  -webkit-transform: translatez(0);\n  position: absolute;\n  display: block;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  padding-left: " + Defaults.metrics.selectInputLeft + "px;\n  padding-right: " + Defaults.metrics.selectInputRight + "px;\n  padding-top: " + Defaults.metrics.selectInputTop + "px;\n  padding-bottom: " + Defaults.metrics.selectInputBottom + "px;\n  background: " + Defaults.colors.selectInputBackground + ";\n  -webkit-appearance: none;\n  -webkit-box-reflect: unset;\n  -webkit-mask: none;\n  -webkit-user-select: text;\n   outline: none;\n  border: 0;\n  " + fontrules + "\n}", 0);
  styleSheet.insertRule(".FramerComponentsSelectInput[disabled=true] {\n  display: none;\n}", 0);
  styleSheet.insertRule(".FramerComponentsSelectInput.default {\n  -webkit-text-fill-color: " + Defaults.colors.inputPlaceholderColor + ";\n}", 0);
  return styleSheet.insertRule(".FramerComponentsSelectInput:focus {\n  outline: none;\n}", 0);
};

setupStyles();

exports.SelectInput = (function(superClass) {
  extend(SelectInput, superClass);

  function SelectInput(options) {
    if (options == null) {
      options = {};
    }
    this.handlePropertyReset = bind(this.handlePropertyReset, this);
    this.handlePropertyValueChange = bind(this.handlePropertyValueChange, this);
    this.enable = bind(this.enable, this);
    this.disable = bind(this.disable, this);
    SelectInput.__super__.constructor.call(this, _.defaults(options, {
      width: Defaults.metrics.selectInputWidth,
      height: Defaults.metrics.selectInputHeight,
      backgroundColor: Defaults.colors.selectInputBackground,
      ignoreEvents: false
    }));
    this.chevron = new Layer({
      parent: this,
      x: this.width - 8 - 8,
      y: 8,
      width: 7,
      height: 4,
      image: "images/icon-select-chevron.pdf"
    });
  }

  SelectInput.prototype.createInputElement = function() {
    var currentValue, name, option, ref, value;
    this.inputElement = document.createElement("select");
    this.inputElement.className = "FramerComponentsSelectInput";
    this.inputElement.setAttribute("tabindex", "1");
    this.options = {};
    ref = this.property.availableOptions;
    for (value in ref) {
      name = ref[value];
      option = document.createElement("option");
      option.value = value;
      option.innerHTML = name;
      this.options[value] = option;
      this.inputElement.appendChild(option);
    }
    currentValue = this.property.valueAsString();
    return this.updateValue(currentValue);
  };

  SelectInput.prototype.disable = function() {
    SelectInput.__super__.disable.apply(this, arguments);
    return this.chevron.visible = false;
  };

  SelectInput.prototype.enable = function() {
    SelectInput.__super__.enable.apply(this, arguments);
    return this.chevron.visible = true;
  };

  SelectInput.prototype.updateValue = function(newValue) {
    var defaultOption, option, ref, selectedOption, value;
    selectedOption = null;
    defaultOption = null;
    ref = this.options;
    for (value in ref) {
      option = ref[value];
      option.selected = false;
      if (value === newValue) {
        selectedOption = option;
      }
      if ((this.property["default"] != null) && value === this.property["default"]) {
        defaultOption = option;
      }
    }
    if (!this.disabled) {
      if (selectedOption != null) {
        selectedOption.selected = true;
      }
      if (selectedOption === null) {
        if (defaultOption != null) {
          defaultOption.selected = true;
        }
        return this.inputElement.classList.add("default");
      } else {
        return this.inputElement.classList.remove("default");
      }
    }
  };

  SelectInput.prototype.handlePropertyValueChange = function() {
    var newValue;
    this.updateDisabledState();
    newValue = this.property.valueAsString();
    return this.updateValue(newValue);
  };

  SelectInput.prototype.handlePropertyReset = function(newValue) {
    if (newValue == null) {
      newValue = null;
    }
    this.updateDisabledState();
    return this.updateValue(newValue);
  };

  return SelectInput;

})(TextInput);



},{"../Defaults":1,"./TextInput":20}],19:[function(require,module,exports){
var Defaults, TextInput,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

TextInput = require("./TextInput").TextInput;

exports.SliderInput = (function(superClass) {
  extend(SliderInput, superClass);

  function SliderInput(options) {
    var max, min, ref, ref1;
    if (options == null) {
      options = {};
    }
    this.updateEnabledState = bind(this.updateEnabledState, this);
    this.handlePropertyValueChange = bind(this.handlePropertyValueChange, this);
    this.handleSliderValueChange = bind(this.handleSliderValueChange, this);
    this.property = options.property;
    this.transform = (ref = this.property.sliderTransform) != null ? ref : function(x) {
      return x;
    };
    this.inverseTransform = (ref1 = this.property.sliderInverseTransform) != null ? ref1 : function(x) {
      return x;
    };
    min = this.property.sliderMin != null ? this.property.sliderMin : this.property.min;
    max = this.property.sliderMax != null ? this.property.sliderMax : this.property.max;
    SliderInput.__super__.constructor.call(this, _.defaults(options, {
      width: 56,
      height: 2,
      min: this.inverseTransform(min),
      max: this.inverseTransform(max),
      style: {
        "margin-top": "9px"
      },
      backgroundColor: "#000",
      hitArea: 18,
      constrained: true
    }));
    this.knobSize = 8;
    this.knob.backgroundColor = "#585858";
    this.knob.draggable.momentum = false;
    this.knob.constrained = true;
    this.knob.style.boxShadow = "0 0 0 1px rgba(0,0,0,0.1), 0 1px 1px rgba(0,0,0,0.2)";
    this.fill.backgroundColor = "#323232";
    this.handlePropertyValueChange(this.property.value);
    this.on("change:value", this.handleSliderValueChange);
    this.property.on("change:value", this.handlePropertyValueChange);
    this.property.on("change:default", this.handlePropertyValueChange);
    this.knob.on(Events.DragStart, (function(_this) {
      return function() {
        _this.isDragging = true;
        return _this.property.emit("request", {
          type: "drag:start"
        });
      };
    })(this));
    this.knob.on(Events.DragEnd, (function(_this) {
      return function() {
        _this.property.emit("request", {
          type: "drag:end"
        });
        return _this.isDragging = false;
      };
    })(this));
  }

  SliderInput.prototype.destroy = function() {
    this.property.off("change:value", this.handlePropertyValueChange);
    this.property.off("change:default", this.handlePropertyValueChange);
    return SliderInput.__super__.destroy.apply(this, arguments).destroy();
  };

  SliderInput.prototype.handleSliderValueChange = function() {
    if (!this.disablePropertyChange) {
      return this.property.value = this.transform(this.value);
    }
  };

  SliderInput.prototype.handlePropertyValueChange = function(newValue) {
    this.disablePropertyChange = true;
    if ((newValue != null) && !isNaN(newValue)) {
      this.value = this.inverseTransform(newValue);
    } else {
      if (this.property["default"] != null) {
        this.value = this.inverseTransform(this.property["default"]);
      } else {
        this.value = this.min;
      }
    }
    this.disablePropertyChange = false;
    return this.updateEnabledState();
  };

  SliderInput.prototype.updateEnabledState = function() {
    if ((this.property.settings != null) && this.property.settings.disabled) {
      return this.visible = false;
    } else {
      return this.visible = true;
    }
  };

  return SliderInput;

})(SliderComponent);



},{"./../Defaults":1,"./TextInput":20}],20:[function(require,module,exports){
var Defaults, Label, Lock, setupStyles,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

Label = require("./../widgets/Label").Label;

Lock = require("./../widgets/Lock").Lock;

setupStyles = function() {
  var fontrules, key, ref, styleElement, styleSheet, value;
  styleElement = document.createElement("style");
  document.head.appendChild(styleElement);
  styleSheet = styleElement.sheet;
  fontrules = "";
  ref = Defaults.textStyles.textInput;
  for (key in ref) {
    value = ref[key];
    fontrules += key + ": " + value + ";";
  }
  styleSheet.insertRule(".FramerComponentsTextInput {\n  -webkit-transform: translatez(0);\n  position: absolute;\n  display: block;\n  top: " + Defaults.metrics.textInputTop + ";\n  left: " + Defaults.metrics.textInputLeft + ";\n  right: " + Defaults.metrics.textInputRight + ";\n  bottom: " + Defaults.metrics.textInputBottom + ";\n  background: " + Defaults.colors.textInputBackground + ";\n  text-decoration: none;\n  -webkit-appearance: none;\n  -webkit-box-reflect: unset;\n  -webkit-mask: none;\n  -webkit-user-select: text\n  outline: 0;\n  border: 0;\n  padding: 0;\n  margin: 0;\n  color: " + Defaults.colors.inputCursorColor + ";\n  border-radius: 3px;\n  " + fontrules + "\n}", 0);
  styleSheet.insertRule(".FramerComponentsTextInput::selection {\n  outline: 0;\n  border: 0;\n  background-color: " + Defaults.colors.textInputSelectionBackground + ";\n}", 0);
  styleSheet.insertRule("::-webkit-input-placeholder {\n  -webkit-text-fill-color: " + Defaults.colors.inputPlaceholderColor + ";\n}", 0);
  return styleSheet.insertRule(".FramerComponentsTextInput:focus {\n  outline: 0;\n  border: 0;\n}", 0);
};

setupStyles();

exports.TextInput = (function(superClass) {
  extend(TextInput, superClass);

  function TextInput(options) {
    if (options == null) {
      options = {};
    }
    this.updateCaption = bind(this.updateCaption, this);
    this.updateDisabledState = bind(this.updateDisabledState, this);
    this.enable = bind(this.enable, this);
    this.disable = bind(this.disable, this);
    this.handlePropertyReset = bind(this.handlePropertyReset, this);
    this.handlePropertyValueChange = bind(this.handlePropertyValueChange, this);
    TextInput.__super__.constructor.call(this, _.defaults(options, {
      width: Defaults.metrics.textInputWidth,
      height: Defaults.metrics.textInputHeight,
      backgroundColor: Defaults.colors.textInputBackground,
      borderColor: Defaults.colors.textInputBorder,
      borderWidth: 1,
      borderRadius: 3,
      ignoreEvents: false
    }));
    this.property = options.property;
    this.createInputElement();
    this._element.appendChild(this.inputElement);
    this.lock = new Lock({
      size: this.size,
      parent: this
    });
    this.lock.onClick(this.property.lockClicked);
    this.disabled = false;
    this.updateDisabledState();
    this.label = new Label({
      parent: this,
      caption: this.property.caption,
      y: Defaults.metrics.textInputLabelY,
      visible: this.property.caption != null
    });
    this.on("change:width", this.handleWidthChange = (function(_this) {
      return function() {
        return _this.label.maxX = (parseInt(_this.width)) - Defaults.metrics.textInputLabelRHSPadding;
      };
    })(this));
    this.handleWidthChange();
    this.inputElement.addEventListener("change", this.handleInputElementChange = (function(_this) {
      return function() {
        _this.property.setValue(_this.inputElement.value);
        return _this.inputElement.value = _this.property.valueAsString();
      };
    })(this));
    this.inputElement.addEventListener("keyup", this.handleInputElementKeypress = (function(_this) {
      return function() {
        return _this.updateCaption();
      };
    })(this));
    this.property.on("change:value", this.handlePropertyValueChange);
    this.property.on("change:default", this.handlePropertyValueChange);
    this.property.on("change:enabled", this.updateDisabledState);
    this.property.on("reset", this.handlePropertyReset);
    this._element.addEventListener("focusin", this.focus);
    this._element.addEventListener("focusout", this.unfocus);
    this.updateCaption();
  }

  TextInput.prototype.createInputElement = function() {
    this.inputElement = document.createElement("input");
    this.inputElement.setAttribute("type", "text");
    this.inputElement.setAttribute("autocorrect", "off");
    this.inputElement.setAttribute("autocapitalize", "off");
    this.inputElement.setAttribute("spellcheck", "false");
    this.inputElement.setAttribute("tabindex", "1");
    if (this.property["default"] != null) {
      this.inputElement.placeholder = this.property.defaultAsString();
    }
    this.inputElement.value = this.property.valueAsString();
    this.inputElement.className = "FramerComponentsTextInput";
    this.inputElement.setAttribute("autocorrect", "off");
    this.inputElement.setAttribute("autocapitalize", "off");
    return this.inputElement.setAttribute("spellcheck", "false");
  };

  TextInput.prototype.destroy = function() {
    this.off("change:width", this.handleWidthChange);
    this.inputElement.removeEventListener("change", this.handleInputElementChange);
    this.inputElement.removeEventListener("keyup", this.handleInputElementKeypress);
    this.property.off("change:value", this.handlePropertyValueChange);
    this.property.off("change:default", this.handlePropertyValueChange);
    this.property.off("change:enabled", this.updateDisabledState);
    this.property.off("reset", this.handlePropertyReset);
    this._element.removeEventListener("focusin", this.focus);
    this._element.removeEventListener("focusout", this.unfocus);
    return TextInput.__super__.destroy.apply(this, arguments).destroy();
  };

  TextInput.prototype.handlePropertyValueChange = function() {
    this.updateDisabledState();
    if ((this.property["default"] != null) && !this.disabled) {
      this.inputElement.placeholder = this.property.defaultAsString();
    }
    this.inputElement.value = this.property.valueAsString();
    if (this.disabled) {
      this.inputElement.value = null;
    }
    return this.updateCaption();
  };

  TextInput.prototype.handlePropertyReset = function(newValue) {
    if (newValue == null) {
      newValue = null;
    }
    this.updateDisabledState();
    this.inputElement.value = newValue;
    this.inputElement.removeAttribute("placeholder");
    return this.updateCaption();
  };

  TextInput.prototype.focus = function() {
    return null;
  };

  TextInput.prototype.unfocus = function() {
    return null;
  };

  TextInput.prototype.disable = function() {
    this.disabled = true;
    this.lock.visible = true;
    this.inputElement.value = null;
    this.inputElement.setAttribute("disabled", "true");
    return this.inputElement.removeAttribute("placeholder");
  };

  TextInput.prototype.enable = function() {
    this.disabled = false;
    this.lock.visible = false;
    if ((this.property["default"] != null) && !this.disabled) {
      this.inputElement.placeholder = this.property.defaultAsString();
    }
    this.inputElement.value = this.property.valueAsString();
    return this.inputElement.removeAttribute("disabled");
  };

  TextInput.prototype.updateDisabledState = function() {
    if (this.property.settings == null) {
      if (this.disabled) {
        this.enable();
      }
      return;
    }
    if (this.property.settings.disabled && !this.disabled) {
      return this.disable();
    } else if (this.disabled && !this.property.settings.disabled) {
      return this.enable();
    }
  };

  TextInput.prototype.updateCaption = function() {
    var length, ref, ref1, ref2;
    length = (ref = (ref1 = this.inputElement.value) != null ? ref1.length : void 0) != null ? ref : (ref2 = this.inputElement.placeholder) != null ? ref2.length : void 0;
    try {
      if (length > 1) {
        if (length > 5) {
          this.label.caption = "";
        } else {
          this.label.caption = this.property.abbreviatedCaption || "";
        }
      } else {
        this.label.caption = this.property.caption || "";
      }
    } catch (error) {}
    this.label.maxX = (parseInt(this.width)) - Defaults.metrics.textInputLabelRHSPadding;
    return this.label.pixelAlign();
  };

  return TextInput;

})(Layer);



},{"./../Defaults":1,"./../widgets/Label":31,"./../widgets/Lock":32}],21:[function(require,module,exports){
var Defaults, PanelRow,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

PanelRow = require("./PanelRow").PanelRow;

exports.MonoInputRow = (function(superClass) {
  extend(MonoInputRow, superClass);

  function MonoInputRow(options) {
    var editorOptions, ref;
    if (options == null) {
      options = {};
    }
    if (options.property != null) {
      this.property = options.property;
    } else if (((ref = options.properties) != null ? ref.length : void 0) === 1) {
      this.property = options.properties[0];
    } else {
      throw new Error("MonoInputRow requires exactly one property set");
    }
    options.properties = [this.property];
    MonoInputRow.__super__.constructor.call(this, _.defaults(options, {}));
    editorOptions = this.property.editorOptions || {};
    this.editor = new this.property.editorType(_.defaults(editorOptions, {
      parent: this,
      property: this.property,
      x: Defaults.metrics.stereoInputLeftX,
      y: Defaults.metrics.stereoInputLeftY
    }));
    this.calculatedHeight = this.editor.maxY;
  }

  return MonoInputRow;

})(PanelRow);



},{"./../Defaults":1,"./PanelRow":24}],22:[function(require,module,exports){
var Defaults, PanelRow,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

PanelRow = require("./PanelRow").PanelRow;

exports.PairedInputRow = (function(superClass) {
  extend(PairedInputRow, superClass);

  function PairedInputRow(options) {
    var leftEditorType, ref, ref1, rightEditorType;
    if (options == null) {
      options = {};
    }
    this.property = options.property;
    if (!this.property) {
      throw new Error("PairedInputRow requires exactly one property set");
    }
    options.properties = [this.property];
    options.rightEditorInsetY || (options.rightEditorInsetY = 0);
    PairedInputRow.__super__.constructor.call(this, _.defaults(options, {}));
    if (((ref = options.editorTypes) != null ? ref.length : void 0) !== 2) {
      throw new Error("PairedInputRow requires exactly two editors set");
    }
    ref1 = options.editorTypes, leftEditorType = ref1[0], rightEditorType = ref1[1];
    this.left = new leftEditorType({
      parent: this,
      property: this.property,
      x: Defaults.metrics.stereoInputLeftX,
      y: Defaults.metrics.stereoInputLeftY
    });
    this.right = new rightEditorType({
      parent: this,
      property: this.property,
      x: this.left.maxX + Defaults.metrics.pairedInputGap,
      y: options.rightEditorInsetY + Defaults.metrics.stereoInputRightY
    });
  }

  return PairedInputRow;

})(PanelRow);



},{"./../Defaults":1,"./PanelRow":24}],23:[function(require,module,exports){
var Background, Defaults,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

Background = require("./../widgets/Background").Background;

exports.Panel = (function(superClass) {
  extend(Panel, superClass);

  function Panel(options) {
    if (options == null) {
      options = {};
    }
    this.unhideAllRows = bind(this.unhideAllRows, this);
    this.updateIsActive = bind(this.updateIsActive, this);
    this.handleRowIsActiveChange = bind(this.handleRowIsActiveChange, this);
    this.handleRowValueChange = bind(this.handleRowValueChange, this);
    this.render = bind(this.render, this);
    Panel.__super__.constructor.call(this, _.defaults(options, {
      height: 0,
      backgroundColor: Defaults.colors.panelBackground,
      clip: true
    }));
    this.calculatedHeight = 0;
    this.rows = [];
    this.on("change:width", this.render);
    this.render();
    this.properties = [];
    this.isActive = false;
  }

  Panel.prototype.destroy = function() {
    var i, len, ref, row;
    ref = this.rows;
    for (i = 0, len = ref.length; i < len; i++) {
      row = ref[i];
      row.off("change:height", this.render);
      row.off("change:value", this.handleRowValueChange);
      row.off("change:isActive", this.handleRowIsActiveChange);
    }
    return Panel.__super__.destroy.call(this);
  };

  Panel.prototype.add = function(row) {
    var ref;
    (ref = this.properties).push.apply(ref, row.properties);
    this.rows.push(row);
    row.parent = this;
    row.on("change:height", this.render);
    row.on("change:value", this.handleRowValueChange);
    row.on("change:isActive", this.handleRowIsActiveChange);
    if (typeof row.render === "function") {
      row.render();
    }
    return this.render();
  };

  Panel.prototype.render = function() {
    var i, len, offsetY, ref, row;
    offsetY = Defaults.metrics.panelPaddingTop;
    ref = this.rows;
    for (i = 0, len = ref.length; i < len; i++) {
      row = ref[i];
      if (!row.visible) {
        continue;
      }
      row.width = this.width;
      row.y = offsetY;
      offsetY += row.calculatedHeight;
    }
    this.calculatedHeight = offsetY + Defaults.metrics.panelPaddingBottom;
    if (!this.isAnimating) {
      return this.height = this.calculatedHeight;
    }
  };

  Panel.prototype.handleRowValueChange = function() {
    return this.emit("change:value", this);
  };

  Panel.prototype.handleRowIsActiveChange = function() {
    var active, i, len, ref, row;
    active = false;
    ref = this.rows;
    for (i = 0, len = ref.length; i < len; i++) {
      row = ref[i];
      if (row.isActive) {
        active = true;
        break;
      }
    }
    return this.updateIsActive(active);
  };

  Panel.prototype.updateIsActive = function(toValue) {
    if (toValue !== this.isActive) {
      this.isActive = toValue;
      return this.emit("change:isActive", this);
    }
  };

  Panel.prototype.hide = function(hide) {
    if (hide == null) {
      hide = true;
    }
    return this.visible = !hide;
  };

  Panel.prototype.unhideAllRows = function() {
    var i, len, ref, row;
    ref = this.rows;
    for (i = 0, len = ref.length; i < len; i++) {
      row = ref[i];
      row.visible = true;
    }
    return this.render();
  };

  Panel.prototype.activate = function() {
    return this.visible = true;
  };

  Panel.prototype.deactivate = function() {
    return this.visible = false;
  };

  return Panel;

})(Background);



},{"./../Defaults":1,"./../widgets/Background":29}],24:[function(require,module,exports){
var Defaults, Label,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

Label = require("./../widgets/Label").Label;

exports.PanelRow = (function(superClass) {
  extend(PanelRow, superClass);

  function PanelRow(options) {
    var i, len, property, ref, ref1;
    if (options == null) {
      options = {};
    }
    this.updateIsActive = bind(this.updateIsActive, this);
    this.handlePropertyValueChange = bind(this.handlePropertyValueChange, this);
    PanelRow.__super__.constructor.call(this, _.defaults(options, {
      height: Defaults.metrics.panelRowHeight,
      backgroundColor: null
    }));
    this.enabled = true;
    if ((ref = options.hasLabel) != null ? ref : true) {
      this.label = new Label({
        parent: this,
        textStyle: Defaults.textStyles.rowLabel,
        x: Defaults.metrics.panelRowLabelX,
        y: Defaults.metrics.panelRowLabelY,
        caption: options.caption || "Untitled"
      });
    }
    this.properties = options.properties || [];
    if (!_.isArray(this.properties)) {
      this.properties = [this.properties];
    }
    ref1 = this.properties;
    for (i = 0, len = ref1.length; i < len; i++) {
      property = ref1[i];
      property.on("change:value", this.handlePropertyValueChange);
      property.on("change:default", this.handlePropertyValueChange);
      property.on("reset", (function(_this) {
        return function() {
          _this.oldValues = null;
          return _this.handlePropertyValueChange;
        };
      })(this));
    }
    this.calculatedHeight = this.height;
    this.isActive = false;
    this.handlePropertyValueChange();
  }

  PanelRow.prototype.destroy = function() {
    var i, len, property, ref;
    ref = this.properties;
    for (i = 0, len = ref.length; i < len; i++) {
      property = ref[i];
      property.off("change:value", this.handlePropertyValueChange);
      property.off("change:default", this.handlePropertyValueChange);
      property.off("reset", this.handlePropertyValueChange);
    }
    return PanelRow.__super__.destroy.call(this);
  };

  PanelRow.prototype.disable = function() {
    var i, len, property, ref, results;
    if (!this.enabled) {
      return;
    }
    this.enabled = false;
    this.disabledLayer = new Layer({
      parent: this,
      size: this,
      backgroundColor: "#141414",
      opacity: 0.7,
      ignoreEvents: false
    });
    this.disabledLayer.onClick((function(_this) {
      return function(event) {
        return _this.emit("click:disabledLayer", event);
      };
    })(this));
    this.oldValues = {};
    ref = this.properties;
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      property = ref[i];
      if (property.dataPath != null) {
        this.oldValues[property.dataPath] = property.value;
        results.push(property.value = null);
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  PanelRow.prototype.enable = function() {
    var i, len, property, ref, ref1;
    if (this.enabled) {
      return;
    }
    this.enabled = true;
    if ((ref = this.disabledLayer) != null) {
      ref.destroy();
    }
    this.disabledLayer = null;
    ref1 = this.properties;
    for (i = 0, len = ref1.length; i < len; i++) {
      property = ref1[i];
      if ((property.dataPath != null) && (this.oldValues != null)) {
        property.value = this.oldValues[property.dataPath];
      }
    }
    return this.oldValues = null;
  };

  PanelRow.prototype.handlePropertyValueChange = function() {
    var i, isActive, len, property, ref, ref1, ref2;
    isActive = false;
    ref = this.properties;
    for (i = 0, len = ref.length; i < len; i++) {
      property = ref[i];
      if ((property.settings != null) && property.settings.disabled) {
        isActive = true;
        break;
      }
      if (property.value != null) {
        isActive = true;
        break;
      }
    }
    if (isActive) {
      if ((ref1 = this.label) != null) {
        ref1.style = Defaults.textStyles.rowLabelSelected;
      }
    } else {
      if ((ref2 = this.label) != null) {
        ref2.style = Defaults.textStyles.rowLabel;
      }
    }
    this.emit("change:value", this);
    return this.updateIsActive(isActive);
  };

  PanelRow.prototype.updateIsActive = function(toValue) {
    if (toValue !== this.isActive) {
      this.isActive = toValue;
      return this.emit("change:isActive", this);
    }
  };

  return PanelRow;

})(Layer);



},{"./../Defaults":1,"./../widgets/Label":31}],25:[function(require,module,exports){
var Defaults, PanelToggle,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

PanelToggle = require("./PanelToggle").PanelToggle;

exports.PanelStack = (function(superClass) {
  extend(PanelStack, superClass);

  function PanelStack(options) {
    if (options == null) {
      options = {};
    }
    this.handlePropertyRequest = bind(this.handlePropertyRequest, this);
    this.handlePanelVisibleChange = bind(this.handlePanelVisibleChange, this);
    this.handlePanelValueChange = bind(this.handlePanelValueChange, this);
    this.render = bind(this.render, this);
    this.getToggleStates = bind(this.getToggleStates, this);
    PanelStack.__super__.constructor.call(this, _.defaults(options, {
      width: Defaults.metrics.panelStackWidth,
      backgroundColor: Defaults.colors.panelStackBackground
    }));
    this.panels = [];
    this.properties = [];
  }

  PanelStack.prototype.destroy = function() {
    var i, j, len, len1, panel, property, ref, ref1, results;
    PanelStack.__super__.destroy.call(this);
    ref = this.panels;
    for (i = 0, len = ref.length; i < len; i++) {
      panel = ref[i];
      panel.off("change:height", this.render);
      panel.off("change:value", this.handlePanelValueChange);
    }
    ref1 = this.properties;
    results = [];
    for (j = 0, len1 = ref1.length; j < len1; j++) {
      property = ref1[j];
      results.push(property.off("request", this.handlePropertyRequest));
    }
    return results;
  };

  PanelStack.prototype.add = function(panel) {
    var i, len, property, ref, ref1;
    this.panels.push(panel);
    (ref = this.properties).push.apply(ref, panel.properties);
    ref1 = panel.properties;
    for (i = 0, len = ref1.length; i < len; i++) {
      property = ref1[i];
      property.on("request", this.handlePropertyRequest);
    }
    panel.parent = this;
    panel.on("change:height", this.render);
    panel.on("change:value", this.handlePanelValueChange);
    panel.on("change:visible", this.handlePanelVisibleChange);
    if (typeof panel.render === "function") {
      panel.render();
    }
    panel.height = panel.calculatedHeight;
    this.render();
    return panel;
  };

  PanelStack.prototype.addWithToggle = function(panel) {
    var toggle;
    toggle = this.add(new PanelToggle({
      targetPanel: panel
    }));
    this.add(panel);
    return toggle;
  };

  PanelStack.prototype.getToggleStates = function() {
    var i, isOpen, len, panel, ref, result;
    result = {};
    ref = this.panels;
    for (i = 0, len = ref.length; i < len; i++) {
      panel = ref[i];
      if (panel instanceof PanelToggle) {
        if (panel.isOpen != null) {
          isOpen = panel.isOpen;
        }
        if (panel.isOpen == null) {
          isOpen = false;
        }
        result[panel.target.caption] = isOpen;
      }
    }
    return result;
  };

  PanelStack.prototype.render = function() {
    var i, len, offsetY, panel, ref;
    offsetY = 0;
    ref = this.panels;
    for (i = 0, len = ref.length; i < len; i++) {
      panel = ref[i];
      panel.width = this.width;
      panel.y = offsetY;
      if (panel.visible == null) {
        panel.visible = true;
      }
      if (!panel.visible) {
        continue;
      }
      offsetY += panel.isAnimating ? panel.height : panel.calculatedHeight;
    }
    return this.height = offsetY;
  };

  PanelStack.prototype.handlePanelValueChange = function() {
    return this.emit("change:value", this);
  };

  PanelStack.prototype.handlePanelVisibleChange = function() {
    return this.render();
  };

  PanelStack.prototype.handlePropertyRequest = function(request) {
    return this.emit("property:request", request);
  };

  PanelStack.prototype.read = function(data, defaults, settings) {
    var i, len, property, ref, results;
    ref = this.properties;
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      property = ref[i];
      results.push(property.read(data, defaults, settings));
    }
    return results;
  };

  PanelStack.prototype.write = function(data) {
    return this.properties.reduce(function(result, property) {
      property.write(result);
      return result;
    }, data || {});
  };

  return PanelStack;

})(Layer);



},{"./../Defaults":1,"./PanelToggle":26}],26:[function(require,module,exports){
var Background, Defaults, Label,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

Background = require("./../widgets/Background").Background;

Label = require("./../widgets/Label").Label;

exports.PanelToggle = (function(superClass) {
  extend(PanelToggle, superClass);

  function PanelToggle(options) {
    var ref;
    if (options == null) {
      options = {};
    }
    this.handlePanelActiveChange = bind(this.handlePanelActiveChange, this);
    this.handleClick = bind(this.handleClick, this);
    this.applyTarget = bind(this.applyTarget, this);
    PanelToggle.__super__.constructor.call(this, options = _.defaults(options, {
      height: Defaults.metrics.panelToggleHeight,
      backgroundColor: Defaults.colors.panelToggleBackground
    }));
    this.isOpen = false;
    this.isCollapsible = true;
    this.properties = [];
    this.on(Events.MouseDown, this.handleClick);
    this.icon = new Layer({
      parent: this,
      image: Defaults.images.iconPanelOpened,
      width: Defaults.metrics.panelToggleIconWidth,
      height: Defaults.metrics.panelToggleIconHeight,
      x: Defaults.metrics.panelToggleIconX,
      y: Defaults.metrics.panelToggleIconY
    });
    this.icon.visible = this.isCollapsible;
    this.label = new Label({
      parent: this,
      textStyle: Defaults.textStyles.panelToggle,
      x: this.isCollapsible ? Defaults.metrics.panelToggleLabelX : Defaults.metrics.panelToggleLabelX - Defaults.metrics.panelToggleIconWidth,
      y: Defaults.metrics.panelToggleLabelY,
      caption: options.caption || ((ref = options.targetPanel) != null ? ref.caption : void 0) || "Untitled"
    });
    Object.defineProperty(this, "targetPanel", {
      get: function() {
        return this.target;
      },
      set: function(value) {
        return this.setTarget(value);
      }
    });
    this.calculatedHeight = this.height;
    if (options.targetPanel != null) {
      this.setTarget(options.targetPanel);
    }
  }

  PanelToggle.prototype.destroy = function() {
    if (this.target != null) {
      this.target.off("change:isActive", this.handlePanelActiveChange);
    }
    return PanelToggle.__super__.destroy.call(this);
  };

  PanelToggle.prototype.setTarget = function(target) {
    if (this.target !== target) {
      if (this.target != null) {
        this.target.off("change:isActive", this.handlePanelActiveChange);
      }
      this.target = target;
      if (this.target != null) {
        this.target.on("change:isActive", this.handlePanelActiveChange);
      }
      return this.applyTarget();
    }
  };

  PanelToggle.prototype.targetHeight = function() {
    var ref;
    return (ref = this.target) != null ? ref.calculatedHeight : void 0;
  };

  PanelToggle.prototype.toggle = function() {
    if (!this.isCollapsible) {
      return;
    }
    if (this.isOpen) {
      return this.close();
    } else {
      return this.open();
    }
  };

  PanelToggle.prototype.open = function(animate) {
    var animation;
    if (animate == null) {
      animate = true;
    }
    if (!this.isCollapsible) {
      return;
    }
    this.isOpen = true;
    if (this.target == null) {
      return;
    }
    if (!this.target.visible) {
      this.target.height = 0;
      this.target.visible = true;
    }
    if (animate) {
      animation = this.target.animate(_.extend({
        properties: {
          height: this.targetHeight()
        }
      }, Defaults.animations.panelOpen));
      animation.on(Events.AnimationEnd, (function(_this) {
        return function() {
          return _this.applyTarget();
        };
      })(this));
      return animation.start();
    } else {
      return this.applyTarget();
    }
  };

  PanelToggle.prototype.close = function(animate) {
    var animation;
    if (animate == null) {
      animate = true;
    }
    if (!this.isCollapsible) {
      return;
    }
    this.isOpen = false;
    if (this.target == null) {
      return;
    }
    this.target.visible = true;
    if (animate) {
      animation = this.target.animate(_.extend({
        properties: {
          height: 0
        }
      }, Defaults.animations.panelClose));
      animation.on(Events.AnimationEnd, (function(_this) {
        return function() {
          return _this.applyTarget();
        };
      })(this));
      return animation.start();
    } else {
      return this.applyTarget();
    }
  };

  PanelToggle.prototype.applyTarget = function() {
    this.target.animateStop();
    if (this.isOpen || !this.isCollapsible) {
      this.target.visible = true;
      this.target.height = this.targetHeight();
      return this.icon.image = Defaults.images.iconPanelOpened;
    } else {
      this.target.visible = false;
      this.target.height = 0;
      return this.icon.image = Defaults.images.iconPanelClosed;
    }
  };

  PanelToggle.prototype.handleClick = function() {
    if (!this.isCollapsible) {
      return;
    }
    return this.toggle();
  };

  PanelToggle.prototype.handlePanelActiveChange = function() {
    if (!this.isCollapsible) {
      return;
    }
    if (this.targetPanel.isActive) {
      return this.label.style = Defaults.textStyles.panelToggle;
    } else {
      return this.label.style = Defaults.textStyles.panelToggle;
    }
  };

  PanelToggle.prototype.hide = function(hide) {
    if (hide == null) {
      hide = true;
    }
    this.visible = !hide;
    return this.target.visible = !hide && this.isActive;
  };

  return PanelToggle;

})(Background);



},{"./../Defaults":1,"./../widgets/Background":29,"./../widgets/Label":31}],27:[function(require,module,exports){
var Defaults, PanelRow,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

PanelRow = require("./PanelRow").PanelRow;

exports.StereoInputRow = (function(superClass) {
  extend(StereoInputRow, superClass);

  function StereoInputRow(options) {
    var propertyA, propertyB, ref, ref1;
    if (options == null) {
      options = {};
    }
    StereoInputRow.__super__.constructor.call(this, _.defaults(options, {}));
    if (((ref = this.properties) != null ? ref.length : void 0) !== 2) {
      throw new Error("StereoInputRow requires exactly two properties set");
    }
    ref1 = this.properties, propertyA = ref1[0], propertyB = ref1[1];
    this.left = new propertyA.editorType({
      parent: this,
      property: propertyA,
      x: Defaults.metrics.stereoInputLeftX,
      y: Defaults.metrics.stereoInputLeftY
    });
    this.right = new propertyB.editorType({
      parent: this,
      property: propertyB,
      x: this.left.maxX + Defaults.metrics.stereoInputGap,
      y: Defaults.metrics.stereoInputRightY
    });
  }

  return StereoInputRow;

})(PanelRow);



},{"./../Defaults":1,"./PanelRow":24}],28:[function(require,module,exports){
var Defaults, PanelRow,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

PanelRow = require("./PanelRow").PanelRow;

exports.WidgetRow = (function(superClass) {
  extend(WidgetRow, superClass);

  function WidgetRow(options) {
    if (options == null) {
      options = {};
    }
    WidgetRow.__super__.constructor.call(this, _.defaults(options, {
      hasLabel: false
    }));
    if (!options.widgetType) {
      throw new Error("WidgetRow requires a widgetType");
    }
    this.widget = new options.widgetType({
      parent: this,
      property: this.property,
      x: Defaults.metrics.widgetX,
      y: Defaults.metrics.widgetY
    });
    this.height = this.widget.height + Defaults.metrics.widgetSpacingBottom;
    this.calculatedHeight = this.height;
  }

  return WidgetRow;

})(PanelRow);



},{"./../Defaults":1,"./PanelRow":24}],29:[function(require,module,exports){
var Defaults,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

exports.Background = (function(superClass) {
  extend(Background, superClass);

  function Background(options) {
    if (options == null) {
      options = {};
    }
    Background.__super__.constructor.call(this, _.defaults(options, {
      backgroundColor: Defaults.colors.panelBackground,
      style: {
        "box-sizing": "border-box",
        "border-bottom": Defaults.borders.panelSegmentBottom
      }
    }));
  }

  return Background;

})(Layer);



},{"./../Defaults":1}],30:[function(require,module,exports){
var Defaults,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

exports.Curve = (function(superClass) {
  extend(Curve, superClass);

  function Curve(options) {
    var ref;
    if (options == null) {
      options = {};
    }
    Curve.__super__.constructor.call(this, _.defaults(options, {
      backgroundColor: Defaults.colors.curveWidgetBackground,
      width: 190,
      height: 120,
      x: 90,
      y: 20,
      borderRadius: 2,
      borderWidth: 1,
      borderColor: Defaults.colors.textInputBorder
    }));
    this.canvasWidth = this.width - 2 * this.borderWidth;
    this.canvasHeight = this.height - 2 * this.borderWidth;
    this.factor = (ref = options.factor) != null ? ref : 1;
    this.xLine = new Layer({
      backgroundColor: Defaults.colors.curveWidgetAxis,
      height: 1,
      x: 1,
      width: this.canvasWidth,
      parent: this
    });
    this.xLine.centerY();
    this.xLine.pixelAlign();
    this.yLine = new Layer({
      backgroundColor: Defaults.colors.curveWidgetAxis,
      y: 1,
      width: 1,
      height: this.canvasHeight,
      parent: this
    });
    this.yLine.centerX();
    this.yLine.pixelAlign();
    this.canvasLayer = new Layer({
      width: this.width,
      height: this.height,
      point: this.borderWidth,
      parent: this,
      backgroundColor: null
    });
    this.canvas = document.createElement("canvas");
    this.canvas.width = this.canvasWidth * 2;
    this.canvas.height = this.canvasHeight * 2;
    this.canvas.style.width = this.canvasWidth + "px";
    this.canvas.style.height = this.canvasHeight + "px";
    this.canvasLayer._element.appendChild(this.canvas);
    this.ctx = this.canvas.getContext("2d");
    this.ctx.scale(2, 2);
    this.ctx.strokeStyle = Defaults.colors.curveWidgetLine;
    this.ctx.lineWidth = 1;
    this.values = 0;
  }

  Curve.prototype.reset = function() {
    return this.ctx.clearRect(0, 0, this.width, this.height);
  };

  Curve.prototype.render = function(animator, time) {
    var adjustedValues, dx, fps, i, index, len, limit, value, values, x, y;
    this.reset();
    if (animator == null) {
      return;
    }
    this.ctx.beginPath();
    if (time != null) {
      limit = this.canvas.width;
      fps = limit / time;
    } else {
      limit = 10000;
      fps = 120;
    }
    this.values = animator.values(1 / fps, limit);
    adjustedValues = [];
    values = this.values;
    dx = this.canvasWidth / (values.length - 1);
    for (index = i = 0, len = values.length; i < len; index = ++i) {
      value = values[index];
      x = index * dx;
      y = (1 - (value * this.factor)) * this.canvasHeight;
      this.ctx.lineTo(x, y);
    }
    return this.ctx.stroke();
  };

  return Curve;

})(Layer);



},{"./../Defaults":1}],31:[function(require,module,exports){
var Defaults,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

Defaults = require("./../Defaults").Defaults;

exports.Label = (function(superClass) {
  extend(Label, superClass);

  function Label(options) {
    if (options == null) {
      options = {};
    }
    Label.__super__.constructor.call(this, options = _.defaults(options, {
      backgroundColor: null,
      textStyle: Defaults.textStyles.textInputHint,
      style: {
        cursor: "default"
      }
    }));
    this.textStyle = options.textStyle;
    Object.defineProperty(this, "caption", {
      get: function() {
        return this._caption;
      },
      set: function(value) {
        return this.setCaption(value);
      }
    });
    this.setCaption(options.caption);
  }

  Label.prototype.setCaption = function(value) {
    var ref;
    if (value !== this._caption) {
      this._caption = value;
      ref = Utils.textSize(value, this.textStyle), this.width = ref.width, this.height = ref.height;
      this.html = value;
      return this.style = this.textStyle;
    }
  };

  Label.prototype.focus = function() {};

  Object.defineProperty(Label, "color", {
    get: function() {
      return this.textStyle.color;
    },
    set: function(value) {
      this.textStyle.color = value;
      return this.style = this.textStyle;
    }
  });

  return Label;

})(Layer);



},{"./../Defaults":1}],32:[function(require,module,exports){
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

exports.Lock = (function(superClass) {
  extend(Lock, superClass);

  function Lock(options) {
    Lock.__super__.constructor.call(this, _.defaults(options, {
      visible: false,
      backgroundColor: null
    }));
    this.lockIcon = new Layer({
      parent: this,
      x: 7,
      y: 5,
      width: 7,
      height: 9,
      image: "images/icon-locked-property.pdf"
    });
    this.onMouseOver((function(_this) {
      return function() {
        return _this.lockIcon.image = "images/icon-locked-property-hover.pdf";
      };
    })(this));
    this.onMouseOut((function(_this) {
      return function() {
        return _this.lockIcon.image = "images/icon-locked-property.pdf";
      };
    })(this));
    this.onMouseUp((function(_this) {
      return function() {
        return _this.lockIcon.image = "images/icon-locked-property-hover.pdf";
      };
    })(this));
    this.onMouseDown((function(_this) {
      return function() {
        _this.lockIcon.image = "images/icon-locked-property-click.pdf";
        return _this.emit(Events.Click);
      };
    })(this));
  }

  return Lock;

})(Layer);



},{}]},{},[10])