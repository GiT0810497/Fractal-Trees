import os
import commands

PATH = os.path.dirname(os.path.abspath(__file__))
BUILD_PATH = PATH
NODE_VERSION = "v6.9.2"
ARCHIVE_NAME = "node-{}-darwin-x64".format(NODE_VERSION)

NODE_URL = "https://nodejs.org/dist/{}/{}.tar.gz".format(NODE_VERSION, ARCHIVE_NAME)

# Make sure you throw out the old io.js by hand

def run(command):
	print command
	os.system(command)

def create_dir(path):
	print path
	if os.path.isdir(path):
		return
	os.mkdir(path)

def main():

	create_dir(BUILD_PATH)

	node_path = os.path.join(os.path.join(BUILD_PATH, "nodejs"))
	node_archive_path = os.path.join(BUILD_PATH, "node.tar.gz")
	run("curl -o '{}' '{}'".format(node_archive_path, NODE_URL))
	run("cd {}; tar -zxvf '{}'".format(BUILD_PATH, node_archive_path))
	run("cd {}; rm -rf '{}'".format(BUILD_PATH, node_path))
	run("cd {}; mv '{}' '{}'".format(BUILD_PATH, ARCHIVE_NAME, node_path))
	run("cd {}; rm *.tar.gz".format(BUILD_PATH))

main()
