
Framer.Device = new Framer.DeviceView()
Framer.Device.setupContext()