/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(global) {module.exports = global["Inferencer"] = __webpack_require__(1);

	/* WEBPACK VAR INJECTION */}.call(exports, (function() { return this; }())))

/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	var AST, ASTVisitor, FramerLayerTypeGenerator, GLOBAL, InfoVisitor, ScopeVisitor, SourceMap, Traverser, Type, Utils, cs2data, cs2js, defaultOptions, defaultOptionsEx, instrumentAnimations, instrumentNewInstanceAssignments, instrumentWhiles;

	SourceMap = __webpack_require__(2);

	Utils = __webpack_require__(3);

	GLOBAL = __webpack_require__(4).GLOBAL;

	ScopeVisitor = __webpack_require__(5).ScopeVisitor;

	ASTVisitor = __webpack_require__(6).ASTVisitor;

	AST = __webpack_require__(7).AST;

	InfoVisitor = __webpack_require__(8).InfoVisitor;

	Traverser = __webpack_require__(9).Traverser;

	Type = __webpack_require__(10).Type;

	FramerLayerTypeGenerator = __webpack_require__(11).FramerLayerTypeGenerator;

	CoffeeScript.helpers.updateSyntaxError = function(error, code, filename) {
	  return error;
	};

	instrumentWhiles = function(data, options, optionsEx) {
	  var i, len, maxloop, node, orgCompileNode, ref, results;
	  maxloop = 2000;
	  ref = data.info.whileNodes;
	  results = [];
	  for (i = 0, len = ref.length; i < len; i++) {
	    node = ref[i];
	    orgCompileNode = node.compileNode;
	    results.push(node.compileNode = function(o) {
	      var ivar, orgConditionCompile;
	      ivar = o.scope.freeVariable('__iter');
	      orgConditionCompile = this.condition.compileNode;
	      this.condition.compileNode = function(o) {
	        var result;
	        result = orgConditionCompile.call(this, o);
	        result.push(this.makeCode(" && ((" + ivar + "|=0,++" + ivar + " < " + maxloop + ") || (function(){throw new Error('Maximum loop iterations exceeded (" + maxloop + ").')})())"));
	        return result;
	      };
	      return orgCompileNode.call(this, o);
	    });
	  }
	  return results;
	};

	instrumentNewInstanceAssignments = function(data, options, optionsEx) {
	  var i, j, len, len1, newedInstances, node, orgCompileToFragments, property, ref, ref1, ref2, ref3, untitledName;
	  newedInstances = (ref = data.scope) != null ? ref.getNewedInstances() : void 0;
	  if ((optionsEx.framerInstanceInfo == null) || (newedInstances == null) || newedInstances.length === 0) {
	    return "";
	  }
	  untitledName = "Untitled";
	  for (i = 0, len = newedInstances.length; i < len; i++) {
	    node = newedInstances[i];
	    orgCompileToFragments = node.compileToFragments;
	    node.__name = void 0;
	    if (node.assignedTo != null) {
	      node.__name = node.assignedTo.base.value;
	      if (node.assignedTo.properties != null) {
	        ref1 = node.assignedTo.properties;
	        for (j = 0, len1 = ref1.length; j < len1; j++) {
	          property = ref1[j];
	          node.__name = ((ref2 = property.index) != null ? (ref3 = ref2.base) != null ? ref3.value : void 0 : void 0) || void 0;
	        }
	      }
	    }
	    node.__loc = Utils.locationToString(node.locationData);
	    if (node.__name != null) {
	      node.__name = node.__name.replace(/\"|\'/g, "");
	      node.__name = "\"" + node.__name + "\"";
	    }
	    node.compileToFragments = function(options, level) {
	      var result;
	      result = orgCompileToFragments.call(this, options, level);
	      result.unshift(this.makeCode("window.__framerNew(" + this.__name + ", \"" + this.__loc + "\", \"" + this.typeHash + "\","));
	      result.push(this.makeCode(")"));
	      delete this.__name;
	      delete this.__loc;
	      return result;
	    };
	  }
	  return "window.__framerNew = function (n,loc,th,i){if (i == null) { return i };i.__framerInstanceInfo = _.defaults({name:n,location:loc,hash:th},i.__framerInstanceInfo);_.defaults(i.__framerInstanceInfo,{name:\"" + untitledName + "\"});return i;};";
	};

	instrumentAnimations = function(data, options, optionsEx) {
	  var animationReturningFunctions, i, len, node, orgCompileToFragments, ref;
	  animationReturningFunctions = (ref = data.scope) != null ? ref.getAnimationReturningFunctions() : void 0;
	  if ((optionsEx.framerInstanceInfo == null) || (animationReturningFunctions == null) || animationReturningFunctions.length === 0) {
	    return "";
	  }
	  for (i = 0, len = animationReturningFunctions.length; i < len; i++) {
	    node = animationReturningFunctions[i];
	    orgCompileToFragments = node.compileToFragments;
	    node.compileToFragments = function(options, level) {
	      var result;
	      result = orgCompileToFragments.call(this, options, level);
	      result.unshift(this.makeCode("window.__framerAnimation(\"" + this.typeHash + "\","));
	      result.push(this.makeCode(")"));
	      return result;
	    };
	  }
	  return "window.__framerAnimation = function (th,a){if (a.isNoop === true) {return a;};var l = a.layer;if (l == null) { return a; };if (l.__framerAnimationInfo == null) {l.__framerAnimationInfo = {};};l.__framerAnimationInfo[th] = {originalState:a._originalState, destinationProperties: a.properties, destinationOptions: a.options};return a;};";
	};

	exports.options = defaultOptions = {
	  sourceMap: false
	};

	exports.optionsEx = defaultOptionsEx = {
	  returnAST: true,
	  returnScope: true,
	  returnGlobals: false,
	  returnInfo: true,
	  framerInstanceInfo: true
	};

	exports.getGlobals = function() {
	  return GLOBAL;
	};

	exports.cs2ast = function(code, options, optionsEx) {
	  var block, key, value, visitor;
	  if (options == null) {
	    options = {};
	  }
	  if (optionsEx == null) {
	    optionsEx = {};
	  }
	  for (key in defaultOptions) {
	    value = defaultOptions[key];
	    if (options[key] == null) {
	      options[key] = value;
	    }
	  }
	  for (key in defaultOptionsEx) {
	    value = defaultOptionsEx[key];
	    if (optionsEx[key] == null) {
	      optionsEx[key] = value;
	    }
	  }
	  block = CoffeeScript.nodes(code, options);
	  visitor = new ASTVisitor();
	  Traverser.traverse(block, [visitor]);
	  return visitor.ast;
	};

	exports.cs2scope = function(code, options, optionsEx) {
	  var block, key, value, visitor;
	  if (options == null) {
	    options = {};
	  }
	  if (optionsEx == null) {
	    optionsEx = {};
	  }
	  for (key in defaultOptions) {
	    value = defaultOptions[key];
	    if (options[key] == null) {
	      options[key] = value;
	    }
	  }
	  for (key in defaultOptionsEx) {
	    value = defaultOptionsEx[key];
	    if (optionsEx[key] == null) {
	      optionsEx[key] = value;
	    }
	  }
	  block = CoffeeScript.nodes(code, options);
	  visitor = new ScopeVisitor({
	    code: code,
	    variables: Utils.extend(optionsEx.variables || {}, GLOBAL)
	  });
	  Traverser.traverse(block, [visitor]);
	  if (!optionsEx.returnGlobals) {
	    for (key in GLOBAL) {
	      delete visitor.scope.variables[key];
	    }
	  }
	  return visitor.scope;
	};

	exports.cs2data = cs2data = function(code, options, optionsEx) {
	  var astVisitor, block, hash, infoVisitor, key, name, ref, scopeVisitor, start, token, tokens, value, variables;
	  if (options == null) {
	    options = {};
	  }
	  if (optionsEx == null) {
	    optionsEx = {};
	  }
	  for (key in defaultOptions) {
	    value = defaultOptions[key];
	    if (options[key] == null) {
	      options[key] = value;
	    }
	  }
	  for (key in defaultOptionsEx) {
	    value = defaultOptionsEx[key];
	    if (optionsEx[key] == null) {
	      optionsEx[key] = value;
	    }
	  }
	  start = new Date();
	  tokens = CoffeeScript.tokens(code, options);
	  options.referencedVars = (function() {
	    var i, len, results;
	    results = [];
	    for (i = 0, len = tokens.length; i < len; i++) {
	      token = tokens[i];
	      if (token.variable) {
	        results.push(token[1]);
	      }
	    }
	    return results;
	  })();
	  block = CoffeeScript.nodes(tokens, options);
	  variables = optionsEx.variables || {};
	  if (optionsEx.predefinedLayers != null) {
	    ref = optionsEx.predefinedLayers;
	    for (name in ref) {
	      hash = ref[name];
	      variables[name] = FramerLayerTypeGenerator(hash);
	    }
	  }
	  Utils.extend(variables, GLOBAL);
	  scopeVisitor = new ScopeVisitor({
	    code: code,
	    variables: variables
	  });
	  astVisitor = new ASTVisitor();
	  infoVisitor = new InfoVisitor();
	  Traverser.traverse(block, [scopeVisitor, astVisitor, infoVisitor]);
	  if (!optionsEx.returnGlobals) {
	    for (key in GLOBAL) {
	      delete scopeVisitor.scope.variables[key];
	    }
	  }
	  return {
	    ast: astVisitor.ast,
	    scope: scopeVisitor.scope,
	    info: infoVisitor.info,
	    duration: new Date() - start,
	    block: optionsEx.returnBlock ? block : void 0
	  };
	};

	exports.cs2js = cs2js = function(code, options, optionsEx) {
	  var answer, currentColumn, currentLine, data, error, fragment, fragments, framerAnimateJS, framerNewJS, i, js, len, map, newLines;
	  if (options == null) {
	    options = {};
	  }
	  if (optionsEx == null) {
	    optionsEx = {};
	  }
	  answer = {};
	  js = [];
	  try {
	    if (options.sourceMap == null) {
	      options.sourceMap = defaultOptionsEx.sourceMap;
	    }
	    optionsEx.returnBlock = true;
	    data = cs2data(code, options, optionsEx);
	    if (options.sourceMap) {
	      map = new SourceMap;
	    }
	    framerNewJS = instrumentNewInstanceAssignments(data, options, optionsEx);
	    framerAnimateJS = instrumentAnimations(data, options, optionsEx);
	    instrumentWhiles(data, options, optionsEx);
	    fragments = data.block.compileToFragments(options);
	    currentLine = 0;
	    if (options.header) {
	      currentLine += 1;
	    }
	    if (options.shiftLine) {
	      currentLine += 1;
	    }
	    currentColumn = 0;
	    js.push(framerNewJS, framerAnimateJS);
	    for (i = 0, len = fragments.length; i < len; i++) {
	      fragment = fragments[i];
	      if (options.sourceMap) {
	        if (fragment.locationData && !/^[;\s]*$/.test(fragment.code)) {
	          map.add([fragment.locationData.first_line, fragment.locationData.first_column], [currentLine, currentColumn], {
	            noReplace: true
	          });
	        }
	        newLines = CoffeeScript.helpers.count(fragment.code, "\n");
	        currentLine += newLines;
	        if (newLines) {
	          currentColumn = fragment.code.length - (fragment.code.lastIndexOf("\n") + 1);
	        } else {
	          currentColumn += fragment.code.length;
	        }
	      }
	      js.push(fragment.code);
	    }
	    if (options.header) {
	      js.push("// Generated by CoffeeScript " + this.VERSION + "\n");
	    }
	  } catch (_error) {
	    error = _error;
	    answer.error = {
	      message: error.message || error,
	      location: error.location,
	      filename: error.filename
	    };
	  }
	  answer.js = js.join("");
	  if (optionsEx.returnScope) {
	    answer.scope = data != null ? data.scope : void 0;
	  }
	  if (optionsEx.returnAST) {
	    answer.ast = data != null ? data.ast : void 0;
	  }
	  if (optionsEx.returnInfo) {
	    answer.info = data != null ? data.info : void 0;
	  }
	  if (options.sourceMap) {
	    answer.sourceMap = map;
	    answer.v3SourceMap = map != null ? map.generate(options, code) : void 0;
	  }
	  return answer;
	};

	exports.cs2js_json = function(code, options, optionsEx) {
	  var ref, ref1, ref2, result;
	  if (options == null) {
	    options = {};
	  }
	  if (optionsEx == null) {
	    optionsEx = {};
	  }
	  result = cs2js(code, options, optionsEx);
	  result.scope = (ref = result.scope) != null ? ref.toJSON() : void 0;
	  result.ast = (ref1 = result.ast) != null ? ref1.toJSON() : void 0;
	  result.info = (ref2 = result.info) != null ? ref2.toJSON() : void 0;
	  return result;
	};


/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	var LineMap, SourceMap;

	LineMap = (function() {
	  function LineMap(line1) {
	    this.line = line1;
	    this.columns = [];
	  }

	  LineMap.prototype.add = function(column, arg, options) {
	    var sourceColumn, sourceLine;
	    sourceLine = arg[0], sourceColumn = arg[1];
	    if (options == null) {
	      options = {};
	    }
	    if (this.columns[column] && options.noReplace) {
	      return;
	    }
	    return this.columns[column] = {
	      line: this.line,
	      column: column,
	      sourceLine: sourceLine,
	      sourceColumn: sourceColumn
	    };
	  };

	  LineMap.prototype.sourceLocation = function(column) {
	    var mapping;
	    while (!((mapping = this.columns[column]) || (column <= 0))) {
	      column--;
	    }
	    return mapping && [mapping.sourceLine, mapping.sourceColumn];
	  };

	  return LineMap;

	})();

	SourceMap = (function() {
	  var BASE64_CHARS, VLQ_CONTINUATION_BIT, VLQ_SHIFT, VLQ_VALUE_MASK;

	  function SourceMap() {
	    this.lines = [];
	  }

	  SourceMap.prototype.add = function(sourceLocation, generatedLocation, options) {
	    var base, column, line, lineMap;
	    if (options == null) {
	      options = {};
	    }
	    line = generatedLocation[0], column = generatedLocation[1];
	    lineMap = ((base = this.lines)[line] || (base[line] = new LineMap(line)));
	    return lineMap.add(column, sourceLocation, options);
	  };

	  SourceMap.prototype.sourceLocation = function(arg) {
	    var column, line, lineMap;
	    line = arg[0], column = arg[1];
	    while (!((lineMap = this.lines[line]) || (line <= 0))) {
	      line--;
	    }
	    return lineMap && lineMap.sourceLocation(column);
	  };

	  SourceMap.prototype.generate = function(options, code) {
	    var buffer, i, j, lastColumn, lastSourceColumn, lastSourceLine, len, len1, lineMap, lineNumber, mapping, needComma, ref, ref1, v3, writingline;
	    if (options == null) {
	      options = {};
	    }
	    if (code == null) {
	      code = null;
	    }
	    writingline = 0;
	    lastColumn = 0;
	    lastSourceLine = 0;
	    lastSourceColumn = 0;
	    needComma = false;
	    buffer = "";
	    ref = this.lines;
	    for (lineNumber = i = 0, len = ref.length; i < len; lineNumber = ++i) {
	      lineMap = ref[lineNumber];
	      if (lineMap) {
	        ref1 = lineMap.columns;
	        for (j = 0, len1 = ref1.length; j < len1; j++) {
	          mapping = ref1[j];
	          if (!(mapping)) {
	            continue;
	          }
	          while (writingline < mapping.line) {
	            lastColumn = 0;
	            needComma = false;
	            buffer += ";";
	            writingline++;
	          }
	          if (needComma) {
	            buffer += ",";
	            needComma = false;
	          }
	          buffer += this.encodeVlq(mapping.column - lastColumn);
	          lastColumn = mapping.column;
	          buffer += this.encodeVlq(0);
	          buffer += this.encodeVlq(mapping.sourceLine - lastSourceLine);
	          lastSourceLine = mapping.sourceLine;
	          buffer += this.encodeVlq(mapping.sourceColumn - lastSourceColumn);
	          lastSourceColumn = mapping.sourceColumn;
	          needComma = true;
	        }
	      }
	    }
	    v3 = {
	      version: 3,
	      file: options.generatedFile || '',
	      sourceRoot: options.sourceRoot || '',
	      sources: options.sourceFiles || [''],
	      names: [],
	      mappings: buffer
	    };
	    if (options.inline) {
	      v3.sourcesContent = [code];
	    }
	    return JSON.stringify(v3, null, 2);
	  };

	  VLQ_SHIFT = 5;

	  VLQ_CONTINUATION_BIT = 1 << VLQ_SHIFT;

	  VLQ_VALUE_MASK = VLQ_CONTINUATION_BIT - 1;

	  SourceMap.prototype.encodeVlq = function(value) {
	    var answer, nextChunk, signBit, valueToEncode;
	    answer = '';
	    signBit = value < 0 ? 1 : 0;
	    valueToEncode = (Math.abs(value) << 1) + signBit;
	    while (valueToEncode || !answer) {
	      nextChunk = valueToEncode & VLQ_VALUE_MASK;
	      valueToEncode = valueToEncode >> VLQ_SHIFT;
	      if (valueToEncode) {
	        nextChunk |= VLQ_CONTINUATION_BIT;
	      }
	      answer += this.encodeBase64(nextChunk);
	    }
	    return answer;
	  };

	  BASE64_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

	  SourceMap.prototype.encodeBase64 = function(value) {
	    return BASE64_CHARS[value] || (function() {
	      throw new Error("Cannot Base64 encode value: " + value);
	    })();
	  };

	  return SourceMap;

	})();

	module.exports = SourceMap;


/***/ },
/* 3 */
/***/ function(module, exports, __webpack_require__) {

	var Utils, flatten;

	Utils = {};

	Utils.merge = function(target, source) {
	  var member;
	  for (member in source) {
	    if (target[member] === void 0) {
	      target[member] = source[member];
	    }
	  }
	  return target;
	};

	Utils.extend = function(target, source) {
	  var member;
	  for (member in source) {
	    if (source[member] !== void 0) {
	      target[member] = source[member];
	    }
	  }
	  return target;
	};

	Utils.lowerCaseFirstChar = function(value) {
	  if (value) {
	    return value.charAt(0).toLocaleLowerCase() + value.slice(1);
	  } else {
	    return "";
	  }
	};

	Utils.isFunction = function(value) {
	  return typeof value === "function" && {}.toString.call(value) === "[object Function]";
	};

	Utils.isString = function(value) {
	  return (typeof value) === "string";
	};

	Utils.locationToString = function(location, widthOfNumber) {
	  if (location != null) {
	    return (location.first_line + ":" + location.first_column + "-") + (location.last_line + ":" + location.last_column);
	  } else {
	    return "No location data";
	  }
	};

	Utils.locationToStringEx = function(location, widthForInt, padUsing) {
	  var i, pad, padding, ref;
	  if (widthForInt == null) {
	    widthForInt = 5;
	  }
	  if (padUsing == null) {
	    padUsing = " ";
	  }
	  if (location != null) {
	    padding = "";
	    for (i = 0, ref = widthForInt; 0 <= ref ? i < ref : i > ref; 0 <= ref ? i++ : i--) {
	      padding += padUsing;
	    }
	    pad = function(x) {
	      return (padding + x).slice(-widthForInt);
	    };
	    return ((pad(location.first_line)) + ":" + (pad(location.first_column)) + "-") + ((pad(location.last_line)) + ":" + (pad(location.last_column)));
	  } else {
	    return "No location data";
	  }
	};

	Utils.locationFromString = function(location) {
	  var match, result;
	  result = {};
	  if (location != null) {
	    match = location.match(/^(\d+):(\d+)-(\d+):(\d+)$/);
	    if (match != null) {
	      result.first_line = parseInt(match[1]);
	      result.first_column = parseInt(match[2]);
	      result.last_line = parseInt(match[3]);
	      result.last_column = parseInt(match[4]);
	    }
	  }
	  return result;
	};

	Utils.isObject = function(value) {
	  return (value != null) && typeof value === 'object';
	};

	Utils.getTypeForId = function(id, range, scope) {
	  var child, i, len, ref, result;
	  if (Utils.isLocationContainedIn(range, scope.location)) {
	    ref = scope.children;
	    for (i = 0, len = ref.length; i < len; i++) {
	      child = ref[i];
	      result = Utils.getTypeForId(id, range, child);
	      if (result != null) {
	        return result;
	      }
	    }
	    return scope.variables[id];
	  }
	  return null;
	};

	Utils.isLocationContainedIn = function(a, in_b) {
	  if (Utils.isString(a)) {
	    a = Utils.locationFromString(a);
	  }
	  if (Utils.isString(in_b)) {
	    in_b = Utils.locationFromString(in_b);
	  }
	  if (a.first_line < in_b.first_line || a.last_line > in_b.last_line) {
	    return false;
	  }
	  if (a.first_line === in_b.first_line && a.first_column < in_b.first_column) {
	    return false;
	  }
	  if (a.last_line === in_b.last_line && a.last_column > in_b.last_column) {
	    return false;
	  }
	  return true;
	};

	Utils.location = function(first_line, first_column, last_line, last_column) {
	  if (last_line == null) {
	    last_line = first_line;
	  }
	  if (last_column == null) {
	    last_column = first_column;
	  }
	  return {
	    first_line: first_line,
	    first_column: first_column,
	    last_line: last_line,
	    last_column: last_column
	  };
	};

	Utils.console = (typeof window !== "undefined" && window !== null) || (typeof __context__ !== "undefined" && __context__ !== null) ? {
	  bold: function(text) {
	    return "" + text;
	  },
	  green: function(text) {
	    return "" + text;
	  },
	  red: function(text) {
	    return "" + text;
	  },
	  cyan: function(text) {
	    return "" + text;
	  }
	} : {
	  bold: function(text) {
	    return "\x1b[1m" + text + "\x1b[0m";
	  },
	  green: function(text) {
	    return "\x1b[32m" + text + "\x1b[0m";
	  },
	  red: function(text) {
	    return "\x1b[31m" + text + "\x1b[0m";
	  },
	  cyan: function(text) {
	    return "\x1b[33m" + text + "\x1b[0m";
	  }
	};

	Utils.flatten = flatten = function(array) {
	  var element, flattened, i, len;
	  flattened = [];
	  for (i = 0, len = array.length; i < len; i++) {
	    element = array[i];
	    if (element instanceof Array) {
	      flattened = flattened.concat(flatten(element));
	    } else {
	      flattened.push(element);
	    }
	  }
	  return flattened;
	};

	Utils.padding = function(length, char) {
	  var i, results;
	  if (char == null) {
	    char = " ";
	  }
	  if (length > 0) {
	    return ((function() {
	      results = [];
	      for (var i = 0; 0 <= length ? i < length : i > length; 0 <= length ? i++ : i--){ results.push(i); }
	      return results;
	    }).apply(this).map(function() {
	      return " ";
	    })).join("");
	  } else {
	    return "";
	  }
	};

	Utils.merge(exports, Utils);


/***/ },
/* 4 */
/***/ function(module, exports, __webpack_require__) {

	var exportTypeSignature, exportTypeSignatures, g, key, ref, ref1, ref10, ref11, ref12, ref13, ref14, ref15, ref16, ref17, ref18, ref19, ref2, ref20, ref21, ref22, ref23, ref24, ref25, ref26, ref27, ref28, ref29, ref3, ref4, ref5, ref6, ref7, ref8, ref9, value;

	g = exports.GLOBAL = {};

	ref = __webpack_require__(12).JS;
	for (key in ref) {
	  value = ref[key];
	  g[key] = value;
	}

	ref1 = __webpack_require__(13).JS;
	for (key in ref1) {
	  value = ref1[key];
	  g[key] = value;
	}

	ref2 = __webpack_require__(14).JS;
	for (key in ref2) {
	  value = ref2[key];
	  g[key] = value;
	}

	ref3 = __webpack_require__(15).JS;
	for (key in ref3) {
	  value = ref3[key];
	  g[key] = value;
	}

	ref4 = __webpack_require__(16).JS;
	for (key in ref4) {
	  value = ref4[key];
	  g[key] = value;
	}

	ref5 = __webpack_require__(17).JS;
	for (key in ref5) {
	  value = ref5[key];
	  g[key] = value;
	}

	ref6 = __webpack_require__(18).JS;
	for (key in ref6) {
	  value = ref6[key];
	  g[key] = value;
	}

	ref7 = __webpack_require__(19).JS;
	for (key in ref7) {
	  value = ref7[key];
	  g[key] = value;
	}

	ref8 = __webpack_require__(20).FJS;
	for (key in ref8) {
	  value = ref8[key];
	  g[key] = value;
	}

	ref9 = __webpack_require__(21).FJS;
	for (key in ref9) {
	  value = ref9[key];
	  g[key] = value;
	}

	ref10 = __webpack_require__(22).FJS;
	for (key in ref10) {
	  value = ref10[key];
	  g[key] = value;
	}

	ref11 = __webpack_require__(23).FJS;
	for (key in ref11) {
	  value = ref11[key];
	  g[key] = value;
	}

	ref12 = __webpack_require__(24).FJS;
	for (key in ref12) {
	  value = ref12[key];
	  g[key] = value;
	}

	ref13 = __webpack_require__(25).FJS;
	for (key in ref13) {
	  value = ref13[key];
	  g[key] = value;
	}

	ref14 = __webpack_require__(11).FJS;
	for (key in ref14) {
	  value = ref14[key];
	  g[key] = value;
	}

	ref15 = __webpack_require__(26).FJS;
	for (key in ref15) {
	  value = ref15[key];
	  g[key] = value;
	}

	ref16 = __webpack_require__(27).FJS;
	for (key in ref16) {
	  value = ref16[key];
	  g[key] = value;
	}

	ref17 = __webpack_require__(28).FJS;
	for (key in ref17) {
	  value = ref17[key];
	  g[key] = value;
	}

	ref18 = __webpack_require__(29).FJS;
	for (key in ref18) {
	  value = ref18[key];
	  g[key] = value;
	}

	ref19 = __webpack_require__(30).FJS;
	for (key in ref19) {
	  value = ref19[key];
	  g[key] = value;
	}

	ref20 = __webpack_require__(31).FJS;
	for (key in ref20) {
	  value = ref20[key];
	  g[key] = value;
	}

	ref21 = __webpack_require__(32).FJS;
	for (key in ref21) {
	  value = ref21[key];
	  g[key] = value;
	}

	ref22 = __webpack_require__(33).FJS;
	for (key in ref22) {
	  value = ref22[key];
	  g[key] = value;
	}

	ref23 = __webpack_require__(34).FJS;
	for (key in ref23) {
	  value = ref23[key];
	  g[key] = value;
	}

	ref24 = __webpack_require__(35).FJS;
	for (key in ref24) {
	  value = ref24[key];
	  g[key] = value;
	}

	ref25 = __webpack_require__(36).FJS;
	for (key in ref25) {
	  value = ref25[key];
	  g[key] = value;
	}

	ref26 = __webpack_require__(37).FJS;
	for (key in ref26) {
	  value = ref26[key];
	  g[key] = value;
	}

	ref27 = __webpack_require__(38).FJS;
	for (key in ref27) {
	  value = ref27[key];
	  g[key] = value;
	}

	ref28 = __webpack_require__(39).FJS;
	for (key in ref28) {
	  value = ref28[key];
	  g[key] = value;
	}

	ref29 = __webpack_require__(40).FJS;
	for (key in ref29) {
	  value = ref29[key];
	  g[key] = value;
	}

	exportTypeSignature = function(value) {
	  var args, ref30, returnType;
	  switch (value != null ? value.id : void 0) {
	    case "object":
	      return exportTypeSignatures(value.members);
	    case "func":
	      args = ((ref30 = value.paramTypes) != null ? ref30.map(exportTypeSignature).join(", ") : void 0) || "";
	      returnType = exportTypeSignature(value.returns);
	      return "(" + args + ") -> " + returnType;
	    case "enum":
	      return value.values.join(" | ");
	    default:
	      return value != null ? value.toString() : void 0;
	  }
	};

	exportTypeSignatures = function(collection, appendTo) {
	  if (appendTo == null) {
	    appendTo = {};
	  }
	  for (key in collection) {
	    value = collection[key];
	    key = key.replace("__reserved__", "");
	    appendTo[key] = exportTypeSignature(value);
	  }
	  return appendTo;
	};


/***/ },
/* 5 */
/***/ function(module, exports, __webpack_require__) {

	var NodesMap, Scope, ScopeVisitor, Type, Utils, Visitor,
	  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
	  hasProp = {}.hasOwnProperty;

	Type = __webpack_require__(10).Type;

	Visitor = __webpack_require__(9).Visitor;

	Scope = __webpack_require__(41).Scope;

	NodesMap = __webpack_require__(42);

	Utils = __webpack_require__(3);

	ScopeVisitor = exports.ScopeVisitor = (function(superClass) {
	  extend(ScopeVisitor, superClass);

	  function ScopeVisitor(scopeOptions) {
	    var ref;
	    this.scopeOptions = scopeOptions != null ? scopeOptions : {};
	    this.lines = ((ref = this.scopeOptions.code) != null ? ref.split("\n") : void 0) || [];
	    ScopeVisitor.__super__.constructor.call(this);
	  }

	  ScopeVisitor.prototype.visit = function(node, name) {
	    var handlerName, l, lastColumn, lastExpression, lastLine, ref, ref1, ref2;
	    lastColumn = (ref = node.locationData) != null ? ref.last_column : void 0;
	    lastLine = (ref1 = node.locationData) != null ? ref1.last_line : void 0;
	    if ((lastColumn != null) && (lastLine != null)) {
	      node.locationData.last_column = Math.max(0, Math.min(this.lines[lastLine].length - 1, lastColumn));
	    }
	    if (!this.scope) {
	      this.addChildScope(node);
	    }
	    handlerName = NodesMap.handlerNameForNode(node, this.post);
	    if (typeof this[handlerName] === "function") {
	      this[handlerName](node);
	    }
	    if (this.scope && (this.scope.parent == null)) {
	      l = ((ref2 = node.expressions) != null ? ref2.length : void 0) || 0;
	      if (l !== 0) {
	        lastExpression = node.expressions[l - 1];
	        this.scope.location.last_line = lastExpression.locationData.last_line;
	        return this.scope.location.last_column = lastExpression.locationData.last_column;
	      }
	    }
	  };

	  ScopeVisitor.prototype.addChildScope = function(node) {
	    if (this.scope == null) {
	      this.scopeOptions.location = node.locationData;
	      this.scope = new Scope(this.scopeOptions);
	    } else {
	      this.scope = this.scope.addChildScope(node.locationData);
	    }
	    return this.scope;
	  };

	  ScopeVisitor.prototype.$class = function(node) {
	    var ctorOptions, expression, expressions, instOptions, j, len, parentType, ref, ref1, ref2, results;
	    this.scope = this.addChildScope(node);
	    ctorOptions = {
	      isConstructor: true,
	      dynamic: true
	    };
	    if (node.parent != null) {
	      parentType = (ref = Type.resolveNodeProperties(node.parent, this.scope)) != null ? ref.type : void 0;
	    }
	    instOptions = {
	      dynamic: true,
	      xtends: parentType != null ? parentType.returns : void 0,
	      members: {}
	    };
	    node.ctorType = Type.func(ctorOptions);
	    node.instType = Type.object(instOptions);
	    this.scope.setVariableType("this", node.ctorType, node, true);
	    expressions = (ref1 = node.body) != null ? ref1.expressions : void 0;
	    results = [];
	    for (j = 0, len = expressions.length; j < len; j++) {
	      expression = expressions[j];
	      results.push((ref2 = expression.base) != null ? ref2.classInstance = node.instType : void 0);
	    }
	    return results;
	  };

	  ScopeVisitor.prototype.$class_post = function(node) {
	    var name, ref;
	    if (this.scope.parent != null) {
	      this.scope = this.scope.parent;
	    }
	    name = (ref = node.variable.base) != null ? ref.value : void 0;
	    node.instType.dynamic = false;
	    node.instType.name = name[0].toLowerCase() + name.slice(1);
	    node.ctorType.dynamic = false;
	    if (name != null) {
	      node.ctorType.name = name;
	    }
	    node.type = node.ctorType;
	    node.type.returns = this.scope.addToTypeDict(node.instType);
	    node.typeHash = this.scope.addToTypeDict(node.type);
	    if (name) {
	      return this.scope.setVariableType(name, node.type, node.variable);
	    }
	  };

	  ScopeVisitor.prototype.$code = function(node) {
	    var funcType, i, j, k, len, len1, param, ref, ref1, ref2, type;
	    this.scope = this.addChildScope(node);
	    if ((funcType = node.expectedType) != null) {
	      if (!Type.isFunc(funcType)) {
	        funcType = this.scope.getVariableType(funcType, node);
	      }
	      if (Type.isFunc(funcType) && (funcType.paramTypes != null)) {
	        i = 0;
	        ref = funcType.paramTypes;
	        for (j = 0, len = ref.length; j < len; j++) {
	          type = ref[j];
	          if (node.params.length <= i) {
	            break;
	          }
	          param = node.params[i];
	          if (funcType.bindCalleeLayer && (node.calleeLayerType != null) && type === "@Layer") {
	            type = this.scope.addToTypeDict(node.calleeLayerType);
	          }
	          this.scope.setVariableType(param.name.value, type, param, true);
	          i++;
	        }
	      }
	    } else {
	      ref1 = node.params;
	      for (k = 0, len1 = ref1.length; k < len1; k++) {
	        param = ref1[k];
	        this.scope.setVariableType(param.name.value, ((ref2 = param.value) != null ? ref2.type : void 0) || param.expectedType || "?", param, true);
	      }
	    }
	    node.type = Type.func({
	      returns: Type.DYNAMIC
	    });
	    return node.typeHash = this.scope.addToTypeDict(node.type);
	  };

	  ScopeVisitor.prototype.$code_post = function(node) {
	    if (this.scope.parent != null) {
	      return this.scope = this.scope.parent;
	    }
	  };

	  ScopeVisitor.prototype.$for = function(node) {};

	  ScopeVisitor.prototype.$for_post = function(node) {
	    var indexType, ref;
	    if (node.range && (node.name != null)) {
	      this.scope.setVariableType((ref = node.name) != null ? ref.value : void 0, Type.NUMBER, node, false);
	    } else {
	      if ((node.index != null)) {
	        indexType = node.object ? Type.STRING : Type.NUMBER;
	        if (node.index != null) {
	          this.scope.setVariableType(node.index.value, indexType, node.index, false);
	        }
	      }
	    }
	    if (this.scope.parent != null) {
	      return this.scope = this.scope.parent;
	    }
	  };

	  ScopeVisitor.prototype.$block_post = function(node) {
	    if (node.expressions.length) {
	      node.type = node.expressions[node.expressions.length - 1].type;
	      return node.typeHash = this.scope.addToTypeDict(node.type);
	    }
	  };

	  ScopeVisitor.prototype.$assign = function(node) {
	    var assignType, ref;
	    if (node.variable != null) {
	      assignType = Type.resolveNodeProperties(node.variable, this.scope).type;
	    }
	    if (assignType != null) {
	      if (typeof assignType === "string") {
	        return node.value.expectedType = assignType;
	      } else {
	        return node.value.expectedType = (ref = assignType.type) != null ? ref : assignType.xtends;
	      }
	    }
	  };

	  ScopeVisitor.prototype.$assign_post = function(node) {
	    if (node.variable.base == null) {
	      return;
	    }
	    node.type = Type.processAssignment(node, this.scope);
	    node.typeHash = this.scope.addToTypeDict(node.type);
	    return node.value.assignedTo = node.variable;
	  };

	  ScopeVisitor.prototype.$parens_post = function(node) {
	    if (!node.body.type && NodesMap.nameForNode(node.body) === "Block") {
	      this.$block_post(node.body);
	    }
	    node.type = node.body.type;
	    return node.typeHash = this.scope.addToTypeDict(node.type);
	  };

	  ScopeVisitor.prototype.$obj = function(node) {
	    var j, k, key, len, len1, memberType, object, ref, ref1, ref2, ref3, ref4, ref5, results, results1, type, typeHash;
	    if (node.expectedType != null) {
	      type = Type.resolveType({
	        type: node.expectedType,
	        scope: this.scope,
	        node: node
	      });
	      if (Type.isObject(type)) {
	        if ((type.asDictOfType != null) && (type.asDictOfPropertyGeneratedType == null)) {
	          typeHash = this.scope.addToTypeDict(type.asDictOfType);
	          ref = node.objects;
	          results = [];
	          for (j = 0, len = ref.length; j < len; j++) {
	            object = ref[j];
	            results.push((ref1 = object.value.base) != null ? ref1.expectedType = typeHash : void 0);
	          }
	          return results;
	        } else {
	          ref2 = node.objects;
	          results1 = [];
	          for (k = 0, len1 = ref2.length; k < len1; k++) {
	            object = ref2[k];
	            key = (ref3 = object.variable) != null ? (ref4 = ref3.base) != null ? ref4.value : void 0 : void 0;
	            if ((key != null) && (memberType = type.members[key])) {
	              results1.push((ref5 = object.value.base) != null ? ref5.expectedType = memberType : void 0);
	            } else {
	              results1.push(void 0);
	            }
	          }
	          return results1;
	        }
	      }
	    }
	  };

	  ScopeVisitor.prototype.$obj_post = function(node) {
	    var j, key, len, name, obj, ref, results, typeObj, value;
	    typeObj = {};
	    ref = node.objects;
	    for (j = 0, len = ref.length; j < len; j++) {
	      obj = ref[j];
	      name = obj.variable != null ? obj.variable.base.value : obj.base.value;
	      typeObj[name] = obj.type || Type.UNKNOWN;
	    }
	    if (node.classInstance == null) {
	      node.type = Type.object({
	        members: typeObj,
	        dynamic: true
	      });
	      return node.typeHash = this.scope.addToTypeDict(node.type);
	    } else {
	      results = [];
	      for (key in typeObj) {
	        value = typeObj[key];
	        if (key !== "this") {
	          results.push(node.classInstance.members[key] = value);
	        } else {
	          results.push(void 0);
	        }
	      }
	      return results;
	    }
	  };

	  ScopeVisitor.prototype.$value = function(node) {
	    if ((node.expectedType != null) && (node.base != null)) {
	      return node.base.expectedType = node.expectedType;
	    }
	  };

	  ScopeVisitor.prototype.$value_post = function(node) {
	    var alias, containingLayer, forLoopValueType, index, j, keyPath, len, loopedTypes, property, ref, ref1, ref2, resolvedType, reversedPropertyKeys, reversedTypePath, sourceType, tStates, type, valueType;
	    node.type = Type.resolveNodeProperties(node, this.scope).type;
	    node.typeHash = this.scope.addToTypeDict(node.type);
	    if (node.expectedType == null) {
	      node.expectedType = (ref = node.base) != null ? ref.expectedType : void 0;
	    }
	    if (node.__name__ === "source" && node.__parentName__ === "For") {
	      node = node.__parent__;
	      if ((node.name != null)) {
	        sourceType = Type.resolveNodeProperties(node.source, this.scope).type;
	        if (sourceType != null) {
	          valueType = Type.getCollectionMemberType(sourceType);
	        }
	        if (valueType != null) {
	          if (Type.isObject(valueType) || valueType === "@Layer") {
	            if (Type.resolvedTypesAreEqual(valueType, "@Layer", this.scope)) {
	              tStates = Type.object({
	                name: "layer.states",
	                aliasOf: "@States"
	              });
	              forLoopValueType = Type.object({
	                aliasOf: "@Layer",
	                dynamic: false,
	                members: {
	                  states: tStates
	                },
	                annotations: {
	                  location: Utils.locationToString(node.name.locationData)
	                }
	              });
	              tStates.getHash = function() {
	                return (forLoopValueType.getHash()) + ";@States";
	              };
	            } else {
	              alias = this.scope.addToTypeDict(valueType);
	              forLoopValueType = Type.object({
	                name: 'forLoopValue',
	                aliasOf: alias,
	                dynamic: false,
	                annotations: {
	                  location: Utils.locationToString(node.name.locationData)
	                }
	              });
	            }
	            switch (NodesMap.nameForNode(node.source.base)) {
	              case "Arr":
	                loopedTypes = node.source.base.type.annotations.arrayTypes;
	                break;
	              case "Literal":
	                if (((ref1 = node.source.type.annotations) != null ? ref1.arrayTypes : void 0) != null) {
	                  loopedTypes = (ref2 = node.source.type.annotations) != null ? ref2.arrayTypes : void 0;
	                } else if ((node.source.typePath != null) && (node.source.properties != null)) {
	                  reversedTypePath = ((function() {
	                    var j, len, ref3, results;
	                    ref3 = node.source.typePath;
	                    results = [];
	                    for (j = 0, len = ref3.length; j < len; j++) {
	                      type = ref3[j];
	                      results.push(type);
	                    }
	                    return results;
	                  })()).reverse();
	                  reversedPropertyKeys = ((function() {
	                    var j, len, ref3, results;
	                    ref3 = node.source.properties;
	                    results = [];
	                    for (j = 0, len = ref3.length; j < len; j++) {
	                      property = ref3[j];
	                      results.push(property.name.value);
	                    }
	                    return results;
	                  })()).reverse();
	                  keyPath = [];
	                  for (index = j = 0, len = reversedTypePath.length; j < len; index = ++j) {
	                    type = reversedTypePath[index];
	                    resolvedType = Type.resolveType({
	                      type: type,
	                      scope: this.scope
	                    });
	                    if (resolvedType.xtends === "@Layer") {
	                      containingLayer = type;
	                    } else if (reversedPropertyKeys[index] != null) {
	                      keyPath.push(reversedPropertyKeys[index]);
	                    }
	                  }
	                  forLoopValueType.annotations.loopedTypeLookup = {
	                    source: containingLayer,
	                    keyPath: keyPath
	                  };
	                }
	            }
	            forLoopValueType.annotations.loopedTypes = loopedTypes;
	            valueType = forLoopValueType;
	          }
	        } else {
	          valueType = Type.UNKNOWN;
	        }
	        if (node.name != null) {
	          return this.scope.setVariableType(node.name.value, valueType, node.name, false);
	        }
	      }
	    }
	  };

	  ScopeVisitor.prototype.$arr_post = function(node) {
	    var arrayType, type, typeHashes;
	    type = Type.getCommonNodeType(node.objects, this.scope);
	    arrayType = Type.array(type);
	    if (Type.isObject(type)) {
	      typeHashes = node.objects.map(function(value) {
	        return value.typeHash;
	      });
	      arrayType.annotations = {
	        location: Utils.locationToString(node.locationData),
	        arrayTypes: typeHashes
	      };
	    }
	    node.type = arrayType;
	    return node.typeHash = this.scope.addToTypeDict(arrayType);
	  };

	  ScopeVisitor.prototype.$op_post = function(node) {
	    var a, b;
	    a = node.first;
	    b = node.second;
	    switch (node.operator) {
	      case "new":
	        node.type = this.wrapConstructorReturnType(a.type, node);
	        node.typeHash = this.scope.addToTypeDict(node.type);
	        return this.scope.getNewedInstances().push(node);
	      case "+":
	      case "-":
	      case "/":
	      case "*":
	        node.type = Type.sum(a, b);
	        return node.typeHash = this.scope.addToTypeDict(node.type);
	    }
	  };

	  ScopeVisitor.prototype.$call = function(node) {
	    var arg, calleeLayerType, funcType, i, j, k, lastTypePathIndex, len, len1, m, ref, ref1, ref2, ref3, ref4, results, type, typeInPath;
	    ref = node.args;
	    for (j = 0, len = ref.length; j < len; j++) {
	      arg = ref[j];
	      if (this.scope.variables[(ref1 = arg.name) != null ? ref1.value : void 0] != null) {
	        arg.expectedType = this.scope.addToTypeDict(this.scope.variables[(ref2 = arg.name) != null ? ref2.value : void 0]);
	      }
	    }
	    if (node.variable != null) {
	      funcType = Type.resolveNodeProperties(node.variable, this.scope).type;
	    }
	    if (!Type.isFunc(funcType)) {
	      funcType = this.scope.getVariableType(funcType, node);
	    }
	    if (Type.isFunc(funcType)) {
	      node.callType = this.scope.addToTypeDict(funcType);
	      if (funcType.paramTypes != null) {
	        if (funcType != null ? funcType.bindCalleeLayer : void 0) {
	          lastTypePathIndex = node.variable.typePath.length - 1;
	          for (i = k = ref3 = lastTypePathIndex; ref3 <= 0 ? k <= 0 : k >= 0; i = ref3 <= 0 ? ++k : --k) {
	            typeInPath = node.variable.typePath[i];
	            if (Type.isSubTypeOf(typeInPath, "@Layer", this.scope)) {
	              calleeLayerType = typeInPath;
	              break;
	            }
	          }
	        }
	        i = 0;
	        ref4 = funcType.paramTypes;
	        results = [];
	        for (m = 0, len1 = ref4.length; m < len1; m++) {
	          type = ref4[m];
	          if (node.args.length <= i) {
	            break;
	          }
	          node.args[i].expectedType = this.scope.addToTypeDict(type);
	          node.args[i].calleeLayerType = calleeLayerType;
	          results.push(i++);
	        }
	        return results;
	      }
	    }
	  };

	  ScopeVisitor.prototype.$call_post = function(node) {
	    var lastProperty, ref, ref1, ref2, ref3;
	    node.type = Type.getFunctionReturnType((ref = node.variable) != null ? ref.type : void 0, node, this.scope) || Type.UNKNOWN;
	    node.typeHash = this.scope.addToTypeDict(node.type);
	    if (node.type === "@Animation" || node.type.aliasOf === "@Animation") {
	      this.scope.getAnimationReturningFunctions().push(node);
	    }
	    if (node.isNew) {
	      this.scope.getNewedInstances().push(node);
	    }
	    if ((ref1 = node.variable) != null ? ref1.properties : void 0) {
	      ref2 = node.variable.properties, lastProperty = ref2[ref2.length - 1];
	      if ((lastProperty != null ? (ref3 = lastProperty.name) != null ? ref3.value : void 0 : void 0) === "copy") {
	        return this.scope.getNewedInstances().push(node);
	      }
	    }
	  };

	  ScopeVisitor.prototype.$literal = function(node) {
	    node.type = Type.typeFromStringValue(node.value);
	    return node.typeHash = this.scope.addToTypeDict(node.type);
	  };

	  ScopeVisitor.prototype.$bool = function(node) {
	    node.type = Type.BOOLEAN;
	    return node.typeHash = this.scope.addToTypeDict(node.type);
	  };

	  ScopeVisitor.prototype.$undefined = function(node) {
	    node.type = Type.UNDEFINED;
	    return node.typeHash = this.scope.addToTypeDict(node.type);
	  };

	  ScopeVisitor.prototype.wrapConstructorReturnType = function(funcType, node) {
	    var returnType;
	    if (funcType != null) {
	      returnType = Type.getFunctionReturnType(funcType, node, this.scope);
	      if ((returnType != null) && funcType.isConstructor && funcType.aliasInstances) {
	        returnType = Type.object({
	          aliasOf: returnType
	        });
	      }
	      return returnType;
	    } else {
	      return void 0;
	    }
	  };

	  return ScopeVisitor;

	})(Visitor);


/***/ },
/* 6 */
/***/ function(module, exports, __webpack_require__) {

	var AST, ASTVisitor, Type, Utils, Visitor,
	  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
	  hasProp = {}.hasOwnProperty;

	Visitor = __webpack_require__(9).Visitor;

	AST = __webpack_require__(7).AST;

	Utils = __webpack_require__(3);

	Type = __webpack_require__(10).Type;

	ASTVisitor = exports.ASTVisitor = (function(superClass) {
	  extend(ASTVisitor, superClass);

	  function ASTVisitor() {
	    return ASTVisitor.__super__.constructor.apply(this, arguments);
	  }

	  ASTVisitor.prototype.visit = function(node, name, prop, propIndex) {
	    var ast, location, parentLocation;
	    if (!this.post) {
	      ast = this.astFromNode(node, name);
	      if (this.ast) {
	        ast.parent = this.ast;
	        if (propIndex != null) {
	          if (this.ast[prop] == null) {
	            this.ast[prop] = [];
	            this.ast.children.push(prop);
	          }
	          this.ast[prop][propIndex] = ast;
	          ast.propIndex = propIndex;
	        } else {
	          this.ast.children.push(prop);
	          this.ast[prop] = ast;
	        }
	      }
	      return this.ast = ast;
	    } else {
	      this.dataFromNode(node);
	      if (this.ast.parent) {
	        parentLocation = this.ast.parent.location;
	        location = this.ast.location;
	        if (location.last_line > parentLocation.last_line) {
	          parentLocation.last_line = location.last_line;
	          parentLocation.last_column = location.last_column;
	        } else if (location.last_line === parentLocation.last_line) {
	          parentLocation.last_column = Math.max(location.last_column, parentLocation.last_column);
	        }
	        return this.ast = this.ast.parent;
	      }
	    }
	  };

	  ASTVisitor.prototype.astFromNode = function(node, name) {
	    var ast;
	    return ast = new AST({
	      location: node.locationData,
	      type: name
	    });
	  };

	  ASTVisitor.prototype.dataFromNode = function(node) {
	    var base, base1, base2, base3, dataToAdd, i, j, k, len, literal, literalType, nrOfProperties, parentData, property, ref, ref1, ref2, ref3;
	    if (node.typeHash != null) {
	      this.ast.typeHash = node.typeHash;
	    }
	    dataToAdd = {};
	    switch (this.ast.type) {
	      case "Bool":
	        dataToAdd.primitive = "boolean";
	        break;
	      case "Literal":
	        dataToAdd.value = node.value;
	        if ((node.type != null) && node.type !== "literal") {
	          literalType = (function() {
	            switch (node.type) {
	              case Type.NUMBER:
	                return "number";
	              case Type.STRING:
	                return "string";
	            }
	          })();
	          if (literalType != null) {
	            dataToAdd.primitive = literalType;
	          }
	        }
	        break;
	      case "Access":
	        if ((node.name != null) && node.name.type === "literal") {
	          parentData = (ref = this.ast.parent) != null ? ref.data != null ? ref.data : ref.data = {} : void 0;
	          if (parentData.accessors == null) {
	            parentData.accessors = [];
	          }
	          parentData.accessors.push(node.name.value);
	        }
	        break;
	      case "Op":
	        dataToAdd.operator = node.operator;
	        break;
	      case "Call":
	        if (node.isNew) {
	          dataToAdd.isNew = true;
	        }
	        break;
	      case "Value":
	        if (node.typePath != null) {
	          dataToAdd.typePath = node.typePath;
	          if (node.typePath.length > 0) {
	            this.ast.base.typeHash = node.typePath[0];
	          }
	          nrOfProperties = Math.min(node.typePath.length, node.properties.length);
	          if (nrOfProperties > 0) {
	            for (i = j = 1, ref1 = nrOfProperties; 1 <= ref1 ? j <= ref1 : j >= ref1; i = 1 <= ref1 ? ++j : --j) {
	              this.ast.properties[i - 1].typeHash = node.typePath[i];
	            }
	          }
	        }
	        if (node.expectedType != null) {
	          dataToAdd.expectedType = node.expectedType;
	        }
	        break;
	      case "Assign":
	        if (this.ast.variable.typeHash != null) {
	          if ((base = this.ast.value).data == null) {
	            base.data = {};
	          }
	          if ((base1 = this.ast.value.data).expectedType == null) {
	            base1.expectedType = this.ast.variable.typeHash;
	          }
	        }
	        if (node.variable.base.typeHash === "literal") {
	          if ((base2 = this.ast.value).data == null) {
	            base2.data = {};
	          }
	          this.ast.value.data.assignee = node.variable.base.value;
	          ref2 = node.variable.properties;
	          for (k = 0, len = ref2.length; k < len; k++) {
	            property = ref2[k];
	            if ((literal = (ref3 = property.name) != null ? ref3.value : void 0) != null) {
	              this.ast.value.data.assignee += "." + literal;
	            } else {
	              break;
	            }
	          }
	        }
	    }
	    if ((dataToAdd != null) && Object.keys(dataToAdd).length) {
	      if ((base3 = this.ast).data == null) {
	        base3.data = {};
	      }
	      this.ast.data = Utils.extend(this.ast.data, dataToAdd);
	    }
	    return this.ast.data;
	  };

	  return ASTVisitor;

	})(Visitor);


/***/ },
/* 7 */
/***/ function(module, exports, __webpack_require__) {

	var AST, Utils;

	Utils = __webpack_require__(3);

	AST = exports.AST = (function() {
	  AST.prototype.OPTIONS = function() {
	    return {
	      parent: void 0,
	      children: [],
	      location: {},
	      type: "Unknown"
	    };
	  };

	  function AST(options) {
	    if (options == null) {
	      options = {};
	    }
	    Utils.merge(options, this.OPTIONS());
	    Utils.extend(this, options);
	  }

	  AST.prototype.nodeByLocation = function(location) {
	    var child, i, len, r, ref, result;
	    if (this.holdsLocation(location)) {
	      result = this;
	    }
	    if (result != null) {
	      ref = this.childNodes();
	      for (i = 0, len = ref.length; i < len; i++) {
	        child = ref[i];
	        r = child.nodeByLocation(location);
	        if (r != null) {
	          result = r;
	          break;
	        }
	      }
	    }
	    return result;
	  };

	  AST.prototype.holdsLocation = function(location) {
	    return Utils.isLocationContainedIn(location, this.location);
	  };

	  AST.prototype.childNodes = function() {
	    var i, len, name, nodes, ref;
	    nodes = [];
	    ref = this.children;
	    for (i = 0, len = ref.length; i < len; i++) {
	      name = ref[i];
	      nodes = nodes.concat(this[name]);
	    }
	    return nodes;
	  };

	  AST.prototype.toJSON = function() {
	    var child, childValue, i, len, ref, result;
	    result = {
	      location: this.location
	    };
	    if (this.children.length) {
	      result.children = this.children;
	    }
	    ref = this.children;
	    for (i = 0, len = ref.length; i < len; i++) {
	      child = ref[i];
	      childValue = this[child];
	      if (childValue instanceof Array) {
	        result[child] = childValue.map(function(item) {
	          return item.toJSON();
	        });
	      } else {
	        result[child] = childValue.toJSON();
	      }
	    }
	    result.type = this.type;
	    if (this.data != null) {
	      result.data = this.data;
	    }
	    if (this.typeHash != null) {
	      result.typeHash = this.typeHash;
	    }
	    if (this.propIndex != null) {
	      result.propIndex = this.propIndex;
	    }
	    return result;
	  };

	  AST.prototype.toInspect = function(indent) {
	    var child, children, cons, data, datas, descriptor, grandChild, i, info, j, key, len, len1, location, locationPadding, name, padding, ref, ref1, type, typeHash, value;
	    if (indent == null) {
	      indent = 0;
	    }
	    cons = Utils.console;
	    padding = Utils.padding(indent);
	    locationPadding = Utils.padding(18);
	    location = cons.green("[" + (Utils.locationToStringEx(this.location, 3)) + "]");
	    type = this.type;
	    if (this.data != null) {
	      data = this.data;
	      if (typeof this.data === "object") {
	        datas = [];
	        for (key in data) {
	          value = data[key];
	          datas.push(key + ": " + value);
	        }
	        data = datas.join(" ");
	      }
	      data = cons.bold(cons.red(data));
	    }
	    typeHash = this.typeHash != null ? " [type-hash: " + this.typeHash + "]" : "";
	    descriptor = location + " " + padding + type + (data != null ? ' ' + data : '') + typeHash;
	    info = [];
	    if (this.info != null) {
	      ref = this.info;
	      for (key in ref) {
	        value = ref[key];
	        info.push(key + ": " + value);
	      }
	    }
	    children = [];
	    ref1 = this.children;
	    for (i = 0, len = ref1.length; i < len; i++) {
	      name = ref1[i];
	      child = this[name];
	      children.push("" + locationPadding + padding + "  " + (cons.cyan(name + ":")));
	      if (!(child instanceof Array)) {
	        child = [child];
	      }
	      for (j = 0, len1 = child.length; j < len1; j++) {
	        grandChild = child[j];
	        children.push(grandChild != null ? grandChild.toInspect(indent + 4) : void 0);
	      }
	    }
	    return [descriptor].concat(info.map(function(line) {
	      return "" + locationPadding + padding + line;
	    }), children).join("\n");
	  };

	  return AST;

	})();


/***/ },
/* 8 */
/***/ function(module, exports, __webpack_require__) {

	var AST, Info, InfoVisitor, Utils, Visitor, removeStateSuffix,
	  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
	  hasProp = {}.hasOwnProperty,
	  indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

	Visitor = __webpack_require__(9).Visitor;

	Info = __webpack_require__(43).Info;

	AST = __webpack_require__(7).AST;

	Utils = __webpack_require__(3);

	removeStateSuffix = function(string) {
	  var statesSuffix;
	  statesSuffix = ";@States";
	  if (string.substring(string.length - statesSuffix.length) === statesSuffix) {
	    string = string.substring(0, string.length - statesSuffix.length);
	  }
	  return string;
	};

	InfoVisitor = exports.InfoVisitor = (function(superClass) {
	  extend(InfoVisitor, superClass);

	  function InfoVisitor() {
	    return InfoVisitor.__super__.constructor.apply(this, arguments);
	  }

	  InfoVisitor.prototype.visit = function(node, name) {
	    var assign, base, base1, i, layerHash, len, names, property, ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, results, typePathLength;
	    if (this.info == null) {
	      this.info = new Info();
	    }
	    if (this.post) {
	      if (name === "While") {
	        return this.info.whileNodes.push(node);
	      } else if (name === "Assign") {
	        typePathLength = (ref = node.variable.typePath) != null ? ref.length : void 0;
	        if (((ref1 = node.variable) != null ? (ref2 = ref1.type) != null ? ref2.xtends : void 0 : void 0) === "@States") {
	          if (typePathLength > 1) {
	            layerHash = node.variable.typePath[typePathLength - 1];
	            layerHash = removeStateSuffix(layerHash);
	            names = (base = this.info.stateNames)[layerHash] != null ? base[layerHash] : base[layerHash] = [];
	            if (((ref3 = node.value.base) != null ? ref3.properties : void 0) != null) {
	              ref4 = node.value.base.properties;
	              results = [];
	              for (i = 0, len = ref4.length; i < len; i++) {
	                assign = ref4[i];
	                results.push(names.push(assign.variable.base.value));
	              }
	              return results;
	            }
	          }
	        } else if (((ref5 = node.variable) != null ? (ref6 = ref5.typePath) != null ? ref6[typePathLength - 1] : void 0 : void 0) === "@State") {
	          if (typePathLength > 2) {
	            layerHash = node.variable.typePath[typePathLength - 2];
	            layerHash = removeStateSuffix(layerHash);
	            names = (base1 = this.info.stateNames)[layerHash] != null ? base1[layerHash] : base1[layerHash] = [];
	            property = (ref7 = node.variable.properties) != null ? ref7[node.variable.properties.length - 1] : void 0;
	            if ((property != null) && (property.name != null)) {
	              name = property.name.value;
	              if (!(indexOf.call(names, name) >= 0)) {
	                return names.push(name);
	              }
	            }
	          }
	        }
	      }
	    }
	  };

	  return InfoVisitor;

	})(Visitor);


/***/ },
/* 9 */
/***/ function(module, exports, __webpack_require__) {

	var AST, NodesMap, Scope, Traverser, Type, Utils, Visitor;

	Utils = __webpack_require__(3);

	AST = __webpack_require__(7).AST;

	Type = __webpack_require__(10).Type;

	Scope = __webpack_require__(41).Scope;

	NodesMap = __webpack_require__(42);

	Visitor = exports.Visitor = (function() {
	  function Visitor() {}

	  Visitor.prototype.visit = function(node, name) {
	    throw new Error("'visit' must be overridden by subclass");
	  };

	  return Visitor;

	})();

	Traverser = exports.Traverser = (function() {
	  var traverse;

	  function Traverser() {}

	  Traverser.traverse = traverse = function(node, visitors, childName, index) {
	    var child, childNode, children, flattenedChildren, i, j, k, l, len, len1, len2, len3, nodeName, results, visitor;
	    nodeName = NodesMap.nameForNode(node);
	    if (!nodeName) {
	      console.warn("Unrecognized Node type " + node.constructor.name);
	    }
	    for (i = 0, len = visitors.length; i < len; i++) {
	      visitor = visitors[i];
	      visitor.post = false;
	      visitor.visit(node, nodeName, childName, index);
	    }
	    children = node.children;
	    if (nodeName === "For") {
	      children = ['source', 'guard', 'body'];
	    }
	    if (children && children.length > 0) {
	      for (j = 0, len1 = children.length; j < len1; j++) {
	        childName = children[j];
	        if (childNode = node[childName]) {
	          if (!(childNode instanceof Array)) {
	            if (childName === "source" && nodeName === "For") {
	              childNode.__name__ = childName;
	              childNode.__parentName__ = nodeName;
	              childNode.__parent__ = node;
	            }
	            traverse(childNode, visitors, childName, void 0);
	          } else {
	            flattenedChildren = Utils.flatten(childNode);
	            for (index = k = 0, len2 = flattenedChildren.length; k < len2; index = ++k) {
	              child = flattenedChildren[index];
	              traverse(child, visitors, childName, index);
	            }
	          }
	        }
	      }
	    }
	    results = [];
	    for (l = 0, len3 = visitors.length; l < len3; l++) {
	      visitor = visitors[l];
	      visitor.post = true;
	      results.push(visitor.visit(node, nodeName, childName, index));
	    }
	    return results;
	  };

	  return Traverser;

	})();


/***/ },
/* 10 */
/***/ function(module, exports, __webpack_require__) {

	var TArray, TComplex, TEnum, TFunc, TObject, Type, Utils,
	  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
	  hasProp = {}.hasOwnProperty,
	  indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; },
	  slice = [].slice;

	Utils = __webpack_require__(3);

	Type = (function() {
	  function Type(id) {
	    this.id = id;
	  }

	  return Type;

	})();

	TComplex = (function() {
	  function TComplex(id) {
	    this.id = id;
	  }

	  TComplex.prototype.getHash = function() {
	    var hash, i, j, jsonString, ref;
	    if (this.hash != null) {
	      return this.hash;
	    }
	    jsonString = JSON.stringify(this);
	    hash = 0;
	    for (i = j = 0, ref = jsonString.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
	      hash = ((hash << 5) - hash) + jsonString.charCodeAt(i);
	      hash |= 0;
	    }
	    return this.hash = '#' + (0xFFFFFFFF + hash + 1).toString(16);
	  };

	  return TComplex;

	})();

	TObject = (function(superClass) {
	  extend(TObject, superClass);

	  function TObject(options) {
	    if (options.hasOwnProperty("aliasOf")) {
	      this.aliasOf = options.aliasOf;
	      this.xtends = options.aliasOf;
	    } else {
	      this.xtends = options.xtends || "@Object";
	    }
	    if (options.name != null) {
	      this.name = options.name;
	    }
	    if (options.hasOwnProperty("members")) {
	      this.members = options.members;
	    }
	    this.dynamic = options.dynamic;
	    this.ctor = options.ctor;
	    this.asDictOfType = options.asDictOfType;
	    this.asDictOfPropertyGeneratedType = options.asDictOfPropertyGeneratedType;
	    this.annotations = options.annotations;
	    TObject.__super__.constructor.call(this, "object");
	  }

	  TObject.prototype.toString = function() {
	    var key, ref, value;
	    Type = [];
	    ref = this.members;
	    for (key in ref) {
	      value = ref[key];
	      Type.push(key + ":" + value);
	    }
	    if (this.asDictOfType != null) {
	      return "{*:" + this.asDictOfType + "}";
	    } else {
	      return "{" + (Type.join(",")) + "}";
	    }
	  };

	  TObject.prototype.toJSON = function(includeHash, visited, key) {
	    var ref, result, value;
	    if (includeHash == null) {
	      includeHash = false;
	    }
	    if (visited == null) {
	      visited = [];
	    }
	    if (key == null) {
	      key = null;
	    }
	    if (indexOf.call(visited, this) >= 0) {
	      throw {
	        message: "Cyclic type definition (for value with key '" + key + "')"
	      };
	    }
	    visited.push(this);
	    result = {
	      id: this.id
	    };
	    if (this.name != null) {
	      result.name = this.name;
	    }
	    if (this.xtends != null) {
	      result.xtends = this.xtends;
	    }
	    if (this.dynamic != null) {
	      result.dynamic = this.dynamic;
	    }
	    if (this.ctor != null) {
	      result.ctor = this.ctor;
	    }
	    if (this.asDictOfType != null) {
	      result.asDictOfType = this.asDictOfType;
	    }
	    if (this.asDictOfPropertyGeneratedType != null) {
	      result.asDictOfPropertyGeneratedType = this.asDictOfPropertyGeneratedType;
	    }
	    if (this.aliasOf != null) {
	      result.aliasOf = this.aliasOf;
	    }
	    if (this.members != null) {
	      result.members = {};
	      ref = this.members;
	      for (key in ref) {
	        value = ref[key];
	        result.members[key] = (value != null ? typeof value.toJSON === "function" ? value.toJSON(includeHash, visited, key) : void 0 : void 0) || value;
	      }
	    }
	    if (this.annotations != null) {
	      result.annotations = this.annotations;
	    }
	    if ((this.hash != null) && includeHash) {
	      result.hash = this.hash;
	    }
	    visited.pop();
	    return result;
	  };

	  TObject.prototype.getHash = function() {
	    if (this.dynamic) {
	      this.hash = void 0;
	    }
	    return TObject.__super__.getHash.call(this);
	  };

	  return TObject;

	})(TComplex);

	TFunc = (function(superClass) {
	  extend(TFunc, superClass);

	  function TFunc(options) {
	    var key, params, value;
	    TFunc.__super__.constructor.call(this, options);
	    this.id = "func";
	    if (options.params != null) {
	      params = options.params;
	    }
	    if (options.returns != null) {
	      this.returns = options.returns;
	    }
	    if (options.isConstructor != null) {
	      this.isConstructor = options.isConstructor;
	    }
	    if (options.bindCalleeLayer != null) {
	      this.bindCalleeLayer = options.bindCalleeLayer;
	    }
	    if (params != null) {
	      this.paramTypes = [];
	      this.paramNames = [];
	      for (key in params) {
	        value = params[key];
	        this.paramTypes.push(value);
	        this.paramNames.push(key);
	      }
	    }
	  }

	  TFunc.prototype.toString = function() {
	    var index, members, params, ref, value;
	    params = [];
	    if (this.paramTypes) {
	      ref = this.paramTypes;
	      for (index in ref) {
	        value = ref[index];
	        params.push(this.paramNames[index] + ":" + value);
	      }
	    }
	    members = "";
	    if ((this.members != null) && Object.keys(this.members).length > 0) {
	      members = " " + TFunc.__super__.toString.call(this);
	    }
	    return "(" + (params.join(",")) + ")->" + this.returns + members;
	  };

	  TFunc.prototype.toJSON = function() {
	    var args, r;
	    args = 1 <= arguments.length ? slice.call(arguments, 0) : [];
	    r = TFunc.__super__.toJSON.apply(this, arguments);
	    if (this.paramTypes) {
	      r.paramTypes = this.paramTypes;
	    }
	    if (this.paramNames) {
	      r.paramNames = this.paramNames;
	    }
	    if (this.returns) {
	      r.returns = this.returns;
	    }
	    if (this.isConstructor === true) {
	      r.isConstructor = this.isConstructor;
	    }
	    return r;
	  };

	  return TFunc;

	})(TObject);

	TArray = (function(superClass) {
	  extend(TArray, superClass);

	  function TArray(options) {
	    if (options == null) {
	      options = {};
	    }
	    if (!options.hasOwnProperty("xtend")) {
	      options.xtends = "@Array";
	    }
	    if (!options.hasOwnProperty("ctor")) {
	      options.ctor = "Array";
	    }
	    TArray.__super__.constructor.call(this, options);
	    this.id = "array";
	    if (options.type != null) {
	      this.type = options.type;
	    }
	  }

	  TArray.prototype.toString = function() {
	    return "[" + (this.type || "") + "]";
	  };

	  TArray.prototype.toJSON = function() {
	    var r;
	    r = TArray.__super__.toJSON.call(this);
	    if (this.type) {
	      r.type = this.type;
	    }
	    return r;
	  };

	  return TArray;

	})(TObject);

	TEnum = (function(superClass) {
	  extend(TEnum, superClass);

	  function TEnum(type1, values1) {
	    this.type = type1;
	    this.values = values1;
	    TEnum.__super__.constructor.call(this, "enum");
	    if (!this.values.length > 0) {
	      throw new TypeError("An enumeration must have at least a single value");
	    }
	  }

	  TEnum.prototype.toString = function() {
	    return "(" + (this.values.join("|") || "") + "):" + this.type;
	  };

	  TEnum.prototype.toJSON = function() {
	    return {
	      id: this.id,
	      type: this.type,
	      values: this.values ? this.values : void 0
	    };
	  };

	  return TEnum;

	})(TComplex);

	exports.Type = (function() {
	  function Type() {}

	  Type.UNKNOWN = "?";

	  Type.DYNAMIC = "*";

	  Type.UNDEFINED = "undefined";

	  Type.NULL = "null";

	  Type.NUMBER = "@Number";

	  Type.STRING = "@String";

	  Type.BOOLEAN = "@Boolean";

	  Type.LITERAL = "literal";

	  Type.RE_NUMBER = /^(0x\d+|-?(\d+(\.\d+)?|\.\d+))$/;

	  Type.RE_STRING = /^("|')(.|\n)*\1$/;

	  Type.RE_ARRAY_TYPE = /^\[(.*)\]$/;

	  Type.object = function(options) {
	    if (options == null) {
	      options = {};
	    }
	    if (options.members == null) {
	      options.members = {};
	    }
	    if (options.dynamic == null) {
	      options.dynamic = false;
	    }
	    return new TObject(options);
	  };

	  Type.func = function(options) {
	    if (options == null) {
	      options = {};
	    }
	    if (options.params == null) {
	      options.params = null;
	    }
	    if (options.returns == null) {
	      options.returns = this.DYNAMIC;
	    }
	    if (options.isConstructor == null) {
	      options.isConstructor = false;
	    }
	    return new TFunc(options);
	  };

	  Type.array = function(type, options) {
	    if (options == null) {
	      options = {};
	    }
	    if (type != null) {
	      options.type = type;
	    }
	    return new TArray(options);
	  };

	  Type["enum"] = function(type, values) {
	    return new TEnum(type, values);
	  };

	  Type.sum = function(nodeOrTypeA, nodeOrTypeB) {
	    var a, b;
	    a = this.getInferredTypeFromNode(nodeOrTypeA);
	    if (nodeOrTypeB == null) {
	      return a;
	    }
	    b = this.getInferredTypeFromNode(nodeOrTypeB);
	    if ((a === b) && (a !== this.UNKNOWN)) {
	      return a;
	    } else if ((a === this.STRING) || (b === this.STRING)) {
	      return this.STRING;
	    } else {
	      return this.DYNAMIC;
	    }
	  };

	  Type.copyObjectType = function() {
	    var copyMembers, j, key, len, object, objects, predicate, ref, value;
	    predicate = arguments[0], objects = 2 <= arguments.length ? slice.call(arguments, 1) : [];
	    copyMembers = {};
	    for (j = 0, len = objects.length; j < len; j++) {
	      object = objects[j];
	      ref = object.members;
	      for (key in ref) {
	        value = ref[key];
	        if (predicate(value)) {
	          copyMembers[key] = value;
	        }
	      }
	    }
	    return this.object({
	      members: copyMembers
	    });
	  };

	  Type.options = function(forType, superOptions, filter) {
	    var exclude, inherited, keys, ref, t;
	    t = this;
	    if (filter == null) {
	      filter = function(name, value) {
	        return t.isFunc(value);
	      };
	    }
	    keys = Object.keys(forType.members);
	    exclude = keys.filter(function(key) {
	      return filter(key, forType.members[key]);
	    });
	    inherited = superOptions != null ? (ref = superOptions.annotations) != null ? ref.excludeInherited : void 0 : void 0;
	    if (inherited != null) {
	      exclude = exclude.concat(inherited);
	    }
	    return this.object({
	      name: forType.name + "Options",
	      xtends: "@" + forType.ctor,
	      annotations: {
	        asLiteral: true,
	        excludeInherited: exclude
	      }
	    });
	  };

	  Type.getHash = function(type) {
	    if (this.isComplex(type)) {
	      return type.getHash();
	    } else {
	      return type;
	    }
	  };

	  Type.getInferredTypeFromNode = function(node) {
	    if (Utils.isString(node)) {
	      return node;
	    } else {
	      return node.type || this.UNKNOWN;
	    }
	  };

	  Type.getFunctionReturnType = function(type, callNode, scope) {
	    type = this.resolveType({
	      type: type,
	      scope: scope,
	      node: callNode
	    });
	    if ((type != null ? type.returns : void 0) != null) {
	      if (Utils.isFunction(type.returns)) {
	        return type.returns(callNode, scope);
	      } else {
	        return type.returns;
	      }
	    } else {
	      return type;
	    }
	  };

	  Type.typeFromStringValue = function(value) {
	    if (value === void 0 || value === null) {
	      return this.UNKNOWN;
	    } else if (typeof value === "number" || value.match(this.RE_NUMBER)) {
	      return this.NUMBER;
	    } else if (value.match(this.RE_STRING)) {
	      return this.STRING;
	    } else {
	      return this.LITERAL;
	    }
	  };

	  Type.isComplex = function(type) {
	    return type instanceof TComplex;
	  };

	  Type.isObjectDerived = function(type) {
	    return type instanceof TObject;
	  };

	  Type.isObject = function(type) {
	    return type instanceof TObject && type.id === "object";
	  };

	  Type.isFunc = function(type) {
	    return type instanceof TFunc;
	  };

	  Type.isArray = function(type) {
	    return type instanceof TArray;
	  };

	  Type.isEnum = function(type) {
	    return type instanceof TEnum;
	  };

	  Type.isCoercible = function(type) {
	    type === null || type === void 0 || type === this.UNKNOWN || type === this.DYNAMIC;
	    return type === this.UNDEFINED;
	  };

	  Type.typeHierarchy = function(type, scope) {
	    var result, superHierarchy, superType;
	    result = [];
	    if (type == null) {
	      return result;
	    }
	    if (typeof type === "string") {
	      type = this.resolveType({
	        type: type,
	        scope: scope
	      });
	    }
	    if (type == null) {
	      return result;
	    }
	    result.push(type);
	    if (type.xtends != null) {
	      superType = this.resolveType({
	        type: type.xtends,
	        scope: scope
	      });
	      superHierarchy = this.typeHierarchy(superType, scope);
	      result = superHierarchy.concat(result);
	    }
	    return result;
	  };

	  Type.sharedSuperType = function(a, b, scope) {
	    var hashA, hashB, hierarchyOfA, hierarchyOfB, index, j, len, shared, typeA, typeB;
	    hashA = scope.addToTypeDict(a);
	    hashB = scope.addToTypeDict(b);
	    if (hashA === hashB) {
	      return a;
	    }
	    hierarchyOfA = this.typeHierarchy(a, scope);
	    hierarchyOfB = this.typeHierarchy(b, scope);
	    shared = null;
	    for (index = j = 0, len = hierarchyOfA.length; j < len; index = ++j) {
	      typeA = hierarchyOfA[index];
	      typeB = hierarchyOfB[index];
	      if (Type.areEqual(typeA, typeB)) {
	        shared = typeA;
	      } else {
	        break;
	      }
	    }
	    return shared;
	  };

	  Type.isSubTypeOf = function(child, parent, scope) {
	    if (typeof child === "string") {
	      child = this.resolveType({
	        type: child,
	        scope: scope
	      });
	    }
	    if (child.xtends != null) {
	      if (child.xtends === parent) {
	        return true;
	      } else {
	        this.isSubTypeOf(child.xtends, parent, scope);
	      }
	    }
	    return false;
	  };

	  Type.resolvedTypesAreEqual = function(a, b, scope) {
	    if (typeof a === "string") {
	      a = this.resolveType({
	        type: a,
	        scope: scope
	      });
	    }
	    if (typeof b === "string") {
	      b = this.resolveType({
	        type: b,
	        scope: scope
	      });
	    }
	    return this.areEqual(a, b, scope);
	  };

	  Type.areEqual = function(a, b, scope) {
	    var hashA, hashB;
	    if (!((a != null) || (b != null))) {
	      return true;
	    }
	    if (!((a != null) && (b != null))) {
	      return false;
	    }
	    if (typeof a === "string" || typeof b === "string") {
	      return a === b;
	    }
	    if (a.type === b.type) {
	      if (scope != null) {
	        hashA = scope.addToTypeDict(a);
	        hashB = scope.addToTypeDict(b);
	      } else {
	        hashA = "";
	        hashB = "";
	      }
	      return hashA === hashB && JSON.stringify(a) === JSON.stringify(b);
	    }
	    return false;
	  };

	  Type.getTypeOfArray = function(type) {
	    if (type instanceof TArray) {
	      return type.type;
	    }
	  };

	  Type.getCollectionMemberType = function(type) {
	    if (type instanceof TArray) {
	      return type.type;
	    }
	    if (type.asDictOfType != null) {
	      return type.asDictOfType;
	    }
	    return this.UNKNOWN;
	  };

	  Type.resolveType = function(options) {
	    var key, keys, node, scope, type;
	    type = options.type, scope = options.scope, keys = options.keys, node = options.node;
	    if (keys == null) {
	      keys = [];
	    } else {
	      keys = (function() {
	        var j, len, results;
	        results = [];
	        for (j = 0, len = keys.length; j < len; j++) {
	          key = keys[j];
	          results.push(key);
	        }
	        return results;
	      })();
	    }
	    while (typeof type === "string") {
	      if (type === this.UNKNOWN || type === this.DYNAMIC || type === this.UNDEFINED || type === this.NULL || type === this.LITERAL) {
	        return type;
	      }
	      if (indexOf.call(keys, type) >= 0) {
	        console.warn("Cyclic type definition: " + keys);
	        break;
	      }
	      keys.push(type);
	      type = type.indexOf("#") === 0 ? scope.getTypeDict().get(type) : scope.getVariableType(type, node);
	    }
	    return type;
	  };

	  Type.resolveNodeProperties = function(node, scope) {
	    var hash, j, keys, len, nrOfProperties, path, properties, property, propertyIndex, ref, type;
	    type = (ref = node.base) != null ? ref.type : void 0;
	    path = [];
	    if (node.base == null) {
	      return {
	        type: type,
	        path: path
	      };
	    }
	    properties = node.properties;
	    if (type === this.LITERAL || type === void 0) {
	      type = scope.getVariableType(node.base.value, node.base);
	    }
	    if (properties) {
	      nrOfProperties = properties.length;
	    }
	    if (nrOfProperties == null) {
	      nrOfProperties = 0;
	    }
	    if (nrOfProperties === 0) {
	      hash = scope.addToTypeDict(type);
	      if (hash != null) {
	        node.typePath = [hash];
	      }
	      return {
	        type: type,
	        path: path
	      };
	    }
	    keys = [];
	    type = this.resolveType({
	      type: type,
	      scope: scope,
	      keys: keys,
	      node: node
	    });
	    node.typePath = [scope.getTypeDict().add(type)];
	    if (!Utils.isObject(type)) {
	      return {
	        type: this.UNKNOWN,
	        path: path
	      };
	    }
	    for (propertyIndex = j = 0, len = properties.length; j < len; propertyIndex = ++j) {
	      property = properties[propertyIndex];
	      path.push(type);
	      type = this.resolvePropertyType({
	        baseType: type,
	        property: property,
	        scope: scope,
	        resolveAlias: nrOfProperties !== (propertyIndex + 1),
	        keys: keys,
	        node: property
	      });
	      node.typePath.push(scope.addToTypeDict(type));
	    }
	    return {
	      type: type,
	      path: path
	    };
	  };

	  Type.resolvePropertyType = function(options) {
	    var baseType, baseTypeSuper, key, keys, node, property, ref, ref1, resolveAlias, scope, type;
	    ref = options || {}, baseType = ref.baseType, property = ref.property, scope = ref.scope, resolveAlias = ref.resolveAlias, keys = ref.keys, node = ref.node;
	    if (resolveAlias == null) {
	      resolveAlias = true;
	    }
	    if (keys == null) {
	      keys = [];
	    }
	    type = this.UNKNOWN;
	    if (this.isArray(baseType)) {
	      type = baseType.type || this.DYNAMIC;
	    } else if (this.isObjectDerived(baseType)) {
	      if ((baseType.asDictOfType != null) && (baseType.asDictOfPropertyGeneratedType == null)) {
	        type = baseType.asDictOfType;
	      } else if (typeof baseType.asDictOfPropertyGeneratedType === "function") {
	        type = baseType.asDictOfPropertyGeneratedType(property);
	      } else if (key = this.resolvePropertySelector(property)) {
	        if ((ref1 = baseType.members) != null ? ref1.hasOwnProperty(key) : void 0) {
	          type = baseType.members[key];
	        } else if (baseType.xtends != null) {
	          if (baseType.xtends === "@States") {
	            type = "@State";
	          } else {
	            baseTypeSuper = this.resolveType({
	              type: baseType.xtends,
	              scope: scope,
	              keys: keys,
	              node: property
	            });
	            type = this.resolvePropertyType({
	              baseType: baseTypeSuper,
	              property: property,
	              scope: scope,
	              resolveAlias: resolveAlias,
	              keys: keys,
	              node: key
	            });
	          }
	        }
	      } else if ((baseType.xtends != null) && baseType.xtends === "@States") {
	        type = "@State";
	      }
	    }
	    if (resolveAlias) {
	      type = this.resolveType({
	        type: type,
	        scope: scope,
	        keys: keys,
	        node: node
	      });
	    }
	    return type;
	  };

	  Type.resolvePropertySelector = function(property) {
	    var ref, ref1, ref2, selector;
	    selector = property.name || property.index || property.base;
	    if (selector == null) {
	      return null;
	    }
	    if (selector.type === this.LITERAL) {
	      return selector.value;
	    } else if (selector.asKey && ((ref = selector.base) != null ? ref.type : void 0) === "literal") {
	      return selector.base.value;
	    } else if (selector.type === this.STRING && (((ref1 = selector.base) != null ? ref1.value : void 0) != null) && ((ref2 = selector.base) != null ? ref2.type : void 0) === this.STRING) {
	      return selector.base.value.substr(1, selector.base.value.length - 2);
	    } else if (typeof selector.value === "string") {
	      return selector.value;
	    }
	    return null;
	  };

	  Type.processAssignment = function(node, scope) {
	    var baseType, context, lastLiteral, nrOfProperties, ref, ref1, resolvedProps, value, variable;
	    variable = node.variable;
	    value = node.value;
	    context = node.context;
	    if (variable.base.objects && this.isObject(value.type)) {
	      return this.processDestructuringObjectAssignment(variable, value.type, scope, context);
	    }
	    if (this.isArray(variable.type)) {
	      return this.processDestructuringArrayAssignment(variable, value.type, scope, context);
	    }
	    nrOfProperties = ((ref = variable.properties) != null ? ref.length : void 0) || 0;
	    if (nrOfProperties === 0) {
	      if ((ref1 = variable.base) != null ? ref1.value : void 0) {
	        if (context !== "object") {
	          scope.setVariableType(variable.base.value, value.type || "?", variable);
	        }
	      }
	    } else if (variable != null) {
	      resolvedProps = this.resolveNodeProperties(variable, scope);
	      if (resolvedProps.path.length === nrOfProperties) {
	        baseType = resolvedProps.path.pop();
	        if ((resolvedProps.type == null) || resolvedProps.type === Type.UNKNOWN) {
	          if ((baseType != null ? baseType.dynamic : void 0)) {
	            lastLiteral = Type.resolvePropertySelector(variable.properties[nrOfProperties - 1]);
	            baseType.members || (baseType.members = {});
	            if (lastLiteral != null) {
	              baseType.members[lastLiteral] = value.type;
	            }
	          }
	        } else {
	          if (!Type.areEqual(resolvedProps.type, value.type, scope)) {
	            scope.warnings.push("Type " + resolvedProps.type + " expected at: " + (Utils.locationToString(value.locationData)));
	          }
	        }
	      }
	    }
	    return value.type;
	  };

	  Type.processDestructuringObjectAssignment = function(variable, type, scope) {
	    var j, len, memberType, object, ref, results, selector;
	    ref = variable.base.objects;
	    results = [];
	    for (j = 0, len = ref.length; j < len; j++) {
	      object = ref[j];
	      selector = this.resolvePropertySelector(object);
	      memberType = typeof type.asDictOfPropertyGeneratedType === "function" ? type.asDictOfPropertyGeneratedType(object) : type.asDictOfType != null ? type.asDictOfType : selector != null ? type.members[selector] : void 0;
	      if ((selector != null) && (memberType != null)) {
	        results.push(scope.setVariableType(selector, memberType, object));
	      } else {
	        if (object.variable != null) {
	          selector = this.resolvePropertySelector(object.variable);
	        }
	        memberType = type.asDictOfType ? type.asDictOfType : selector != null ? type.members[selector] : void 0;
	        if (this.isObject(memberType)) {
	          results.push(this.processDestructuringObjectAssignment(object.value, memberType, scope));
	        } else {
	          results.push(scope.setVariableType(selector, this.UNKNOWN, object));
	        }
	      }
	    }
	    return results;
	  };

	  Type.processDestructuringArrayAssignment = function(variable, type, scope) {
	    return null;
	  };

	  Type.getCommonNodeType = function(nodes, scope) {
	    var j, len, node, type;
	    type = null;
	    for (j = 0, len = nodes.length; j < len; j++) {
	      node = nodes[j];
	      if (type === null) {
	        type = node.type;
	      }
	      type = this.sharedSuperType(type, node.type, scope);
	      if (type === null) {
	        break;
	      }
	    }
	    return type;
	  };

	  return Type;

	})();


/***/ },
/* 11 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, FramerImporterLoadReturnTypeGenerator, FramerLayerTypeGenerator, Obj, ObjMembers, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Obj = (__webpack_require__(17)).JS;

	ObjMembers = Object.keys(Obj["@Object"].members).map(function(name) {
	  return name.replace("__reserved__", "");
	});

	FJS = exports.FJS = {};

	FramerLayerTypeGenerator = exports.FramerLayerTypeGenerator = function(hash, annotations) {
	  var tStates, type;
	  if (annotations == null) {
	    annotations = {};
	  }
	  tStates = t.object({
	    name: "layer.states",
	    aliasOf: "@States"
	  });
	  type = t.object({
	    name: "layer",
	    aliasOf: "@Layer",
	    dynamic: false,
	    annotations: annotations,
	    members: {
	      states: tStates
	    }
	  });
	  type.getHash = function() {
	    return this.hash = hash;
	  };
	  tStates.getHash = function() {
	    return (type.getHash()) + ";@States";
	  };
	  return type;
	};

	FramerImporterLoadReturnTypeGenerator = function(callNode) {
	  var path, ref, result;
	  if (callNode == null) {
	    return t.object({
	      asDictOfType: "@Layer",
	      dynamic: true
	    });
	  } else {
	    path = (ref = callNode.args[0]) != null ? ref.base.value : void 0;
	    result = t.object({
	      asDictOfType: "@Layer",
	      asDictOfPropertyGeneratedType: ((function(_this) {
	        return function(propertyNode) {
	          var key, type;
	          key = t.resolvePropertySelector(propertyNode);
	          type = FramerLayerTypeGenerator("#il|" + ((path != null ? path.replace(/\"|\'/g, "") : void 0) || '?') + "|" + key, {
	            importedLayersPath: path,
	            layer: key
	          });
	          return type;
	        };
	      })(this)),
	      dynamic: true,
	      annotations: {
	        importedLayersPath: path
	      }
	    });
	    result.getHash = function() {
	      return this.hash = "#ils|" + (path != null ? path.replace(/\"|\'/g, "") : void 0);
	    };
	    return result;
	  }
	};

	FJS["@Context"] = t.object({
	  members: {
	    width: t.NUMBER,
	    height: t.NUMBER,
	    point: "@Point",
	    size: "@Size",
	    frame: "@Frame",
	    run: t.func({
	      params: {
	        "function": t.func()
	      }
	    }),
	    layers: t.array("@Layer"),
	    perspective: t.NUMBER,
	    perspectiveOriginX: t.NUMBER,
	    perspectiveOriginY: t.NUMBER,
	    canvasFrame: "@Frame",
	    index: t.NUMBER
	  }
	});

	FJS.Framer = t.object({
	  members: {
	    Importer: t.object({
	      members: {
	        load: t.func({
	          params: {
	            path: t.STRING
	          },
	          returns: FramerImporterLoadReturnTypeGenerator
	        })
	      }
	    }),
	    Curves: t.object({
	      members: {
	        Spring: "@Spring",
	        Bezier: "@Bezier"
	      },
	      annotations: {
	        asLiteral: true
	      }
	    }),
	    Defaults: t.object({
	      members: {
	        Layer: "@LayerOptions",
	        Animation: "@AnimationOptions",
	        Hints: t.object({
	          members: {
	            color: t.STRING
	          },
	          annotations: {
	            asLiteral: true,
	            excludeInherited: ObjMembers
	          }
	        })
	      },
	      annotations: {
	        asLiteral: true,
	        excludeInherited: ObjMembers
	      }
	    }),
	    Device: t.object({
	      name: "Device",
	      members: {
	        customize: t.func({
	          params: {
	            options: "@DeviceOptions"
	          }
	        }),
	        Type: t.object({
	          members: {
	            Tablet: t.STRING,
	            Phone: t.STRING,
	            Computer: t.STRING
	          },
	          annotations: {
	            asLiteral: true,
	            excludeInherited: ObjMembers
	          }
	        }),
	        deviceType: t.STRING,
	        fullScreen: t.BOOLEAN,
	        deviceScale: t.NUMBER,
	        setDeviceScale: t.func({
	          params: {
	            scale: t.NUMBER,
	            animate: t.BOOLEAN
	          }
	        }),
	        contentScale: t.NUMBER,
	        setContentScale: t.func({
	          params: {
	            scale: t.NUMBER,
	            animate: t.BOOLEAN
	          }
	        }),
	        orientation: t["enum"](t.NUMBER, [0, 90]),
	        setOrientation: t.func({
	          params: {
	            orientation: t["enum"](t.NUMBER, [0, 90], {
	              animate: t.BOOLEAN
	            })
	          }
	        }),
	        orientationName: t["enum"](t.STRING, ["landscape", "portrait"]),
	        rotateLeft: t.func(),
	        rotateRight: t.func()
	      },
	      annotations: {
	        asLiteral: true,
	        excludeInherited: ObjMembers
	      }
	    }),
	    Context: "@Context",
	    CurrentContext: "@Context",
	    DefaultContext: "@Context",
	    Version: t.object({
	      members: {
	        date: t.NUMBER,
	        branch: t.STRING,
	        hash: t.STRING,
	        build: t.NUMBER,
	        version: t.NUMBER
	      }
	    }),
	    Extras: t.object({
	      members: {
	        Hints: t.object({
	          members: {
	            enable: t.func(),
	            disable: t.func(),
	            showHints: t.func()
	          }
	        }),
	        Preloader: t.object({
	          members: {
	            enable: t.func(),
	            disable: t.func(),
	            addImage: t.func({
	              params: {
	                url: t.STRING
	              }
	            }),
	            setLogo: t.func({
	              params: {
	                url: t.STRING
	              }
	            })
	          }
	        }),
	        ErrorDisplay: t.object({
	          members: {
	            enable: t.func(),
	            disable: t.func()
	          }
	        })
	      }
	    })
	  }
	});

	FJS["@DeviceOptions"] = t.object({
	  members: {
	    deviceType: t.STRING,
	    screenWidth: t.NUMBER,
	    screenHeight: t.NUMBER,
	    deviceImageWidth: t.NUMBER,
	    deviceImageHeight: t.NUMBER,
	    deviceImage: t.STRING
	  },
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});


/***/ },
/* 12 */
/***/ function(module, exports, __webpack_require__) {

	var JS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	JS = exports.JS = {};

	JS["Array"] = t.func({
	  name: "Array",
	  isConstructor: true,
	  returns: function(callNode, scope) {
	    var ref, type;
	    type = null;
	    if ((callNode != null) && ((ref = callNode.args) != null ? ref.length : void 0) > 1) {
	      type = t.getCommonNodeType(callNode.args, scope);
	    }
	    return t.array(type, {
	      ctor: "Array"
	    });
	  },
	  members: {
	    length: t.NUMBER,
	    isArray: t.func({
	      params: {
	        obj: t.DYNAMIC
	      },
	      returns: t.BOOLEAN
	    })
	  }
	});

	JS["@Array"] = t.func({
	  name: "array",
	  ctor: "Array",
	  xtends: "@Object",
	  members: {
	    pop: t.func({
	      returns: t.DYNAMIC
	    }),
	    push: t.func({
	      returns: t.NUMBER
	    }),
	    reverse: t.func(),
	    shift: t.func({
	      returns: t.DYNAMIC
	    }),
	    sort: t.func({
	      returns: t.array()
	    }),
	    splice: t.func(),
	    unshift: t.func({
	      returns: t.NUMBER
	    }),
	    concat: t.func({
	      returns: t.array()
	    }),
	    join: t.func({
	      returns: t.STRING
	    }),
	    slice: t.func({
	      returns: t.array()
	    }),
	    toLocaleString: t.func({
	      returns: t.STRING
	    }),
	    indexOf: t.func({
	      returns: t.NUMBER
	    }),
	    lastIndexOf: t.func({
	      returns: t.NUMBER
	    }),
	    forEach: t.func(),
	    every: t.func({
	      returns: t.BOOLEAN
	    }),
	    some: t.func({
	      returns: t.BOOLEAN
	    }),
	    filter: t.func({
	      returns: t.array()
	    }),
	    map: t.func({
	      returns: t.array()
	    }),
	    reduce: t.func({
	      returns: t.DYNAMIC
	    }),
	    reduceRight: t.func({
	      returns: t.DYNAMIC
	    })
	  }
	});


/***/ },
/* 13 */
/***/ function(module, exports, __webpack_require__) {

	var JS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	JS = exports.JS = {};

	JS["Boolean"] = t.func({
	  name: "Boolean",
	  returns: t.BOOLEAN,
	  isConstructor: true,
	  members: {
	    length: t.NUMBER
	  }
	});

	JS["@Boolean"] = t.object({
	  name: "boolean",
	  ctor: "Boolean",
	  xtends: "@Object"
	});


/***/ },
/* 14 */
/***/ function(module, exports, __webpack_require__) {

	var JS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	JS = exports.JS = {};

	JS["Infinity"] = t.NUMBER;

	JS["NaN"] = t.NUMBER;

	JS["undefined"] = t.UNDEFINED;

	JS["isFinite"] = t.func({
	  params: {
	    value: t.NUMBER
	  },
	  returns: t.BOOLEAN
	});

	JS["isNaN"] = t.func({
	  params: {
	    value: t.NUMBER
	  },
	  returns: t.BOOLEAN
	});

	JS["decodeURI"] = t.func({
	  params: {
	    encodedURI: t.STRING
	  },
	  returns: t.STRING
	});

	JS["decodeURIComponent"] = t.func({
	  params: {
	    encodedURI: t.STRING
	  },
	  returns: t.STRING
	});

	JS["encodeURIComponent"] = t.func({
	  params: {
	    str: t.STRING
	  },
	  returns: t.STRING
	});

	JS["escape"] = t.func({
	  params: {
	    str: t.STRING
	  },
	  returns: t.STRING
	});

	JS["unescape"] = t.func({
	  params: {
	    str: t.STRING
	  },
	  returns: t.STRING
	});

	JS["parseFloat"] = t.func({
	  params: {
	    value: t.STRING
	  },
	  returns: t.NUMBER
	});

	JS["parseInt"] = t.func({
	  params: {
	    value: t.STRING,
	    radix: t.NUMBER
	  },
	  returns: t.NUMBER
	});


/***/ },
/* 15 */
/***/ function(module, exports, __webpack_require__) {

	var JS, Obj, ObjMembers, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Obj = (__webpack_require__(17)).JS;

	ObjMembers = Object.keys(Obj["@Object"].members).map(function(name) {
	  return name.replace("__reserved__", "");
	});

	JS = exports.JS = {};

	JS.Math = t.object({
	  name: "Math",
	  members: {
	    random: t.func({
	      returns: t.NUMBER
	    }),
	    min: t.func({
	      returns: t.NUMBER
	    }),
	    max: t.func({
	      returns: t.NUMBER
	    }),
	    round: t.func({
	      returns: t.NUMBER
	    }),
	    ceil: t.func({
	      returns: t.NUMBER
	    }),
	    floor: t.func({
	      returns: t.NUMBER
	    }),
	    abs: t.func({
	      returns: t.NUMBER
	    }),
	    acos: t.func({
	      returns: t.NUMBER
	    }),
	    asin: t.func({
	      returns: t.NUMBER
	    }),
	    atan: t.func({
	      returns: t.NUMBER
	    }),
	    atan2: t.func({
	      returns: t.NUMBER
	    }),
	    cos: t.func({
	      returns: t.NUMBER
	    }),
	    sin: t.func({
	      returns: t.NUMBER
	    }),
	    tan: t.func({
	      returns: t.NUMBER
	    }),
	    exp: t.func({
	      returns: t.NUMBER
	    }),
	    log: t.func({
	      returns: t.NUMBER
	    }),
	    pow: t.func({
	      returns: t.NUMBER
	    }),
	    sqrt: t.func({
	      returns: t.NUMBER
	    }),
	    E: t.NUMBER,
	    PI: t.NUMBER
	  },
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});


/***/ },
/* 16 */
/***/ function(module, exports, __webpack_require__) {

	var JS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	JS = exports.JS = {};

	JS["Number"] = t.func({
	  name: "Number",
	  returns: t.NUMBER,
	  isConstructor: true,
	  members: {
	    MAX_VALUE: t.NUMBER,
	    MIN_VALUE: t.NUMBER,
	    NaN: t.NUMBER,
	    NEGATIVE_INFINITY: t.NUMBER,
	    POSITIVE_INFINITY: t.NUMBER
	  }
	});

	JS["@Number"] = t.object({
	  name: "number",
	  ctor: "Number",
	  xtends: "@Object",
	  members: {
	    toExponential: t.func({
	      returns: t.STRING
	    }),
	    toFixed: t.func({
	      returns: t.STRING
	    }),
	    toLocaleString: t.func({
	      returns: t.STRING
	    }),
	    toPrecision: t.func({
	      returns: t.STRING
	    })
	  }
	});


/***/ },
/* 17 */
/***/ function(module, exports, __webpack_require__) {

	var JS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	JS = exports.JS = {};

	JS["Object"] = t.func({
	  name: "Object",
	  isConstructor: true,
	  returns: t.object({
	    ctor: "Object",
	    dynamic: true
	  }),
	  members: {
	    __reserved__prototype: "@Object",
	    __reserved__length: t.NUMBER,
	    __reserved__create: t.func(),
	    __reserved__defineProperty: t.func(),
	    __reserved__defineProperties: t.func(),
	    __reserved__freeze: t.func(),
	    __reserved__getOwnPropertyDescriptor: t.func(),
	    __reserved__getOwnPropertyNames: t.func(),
	    __reserved__getPrototypeOf: t.func(),
	    __reserved__isExtensible: t.func(),
	    __reserved__isFrozen: t.func(),
	    __reserved__isSealed: t.func(),
	    __reserved__keys: t.func(),
	    __reserved__preventExtensions: t.func(),
	    __reserved__seal: t.func()
	  }
	});

	JS["@Object"] = t.object({
	  name: "object",
	  members: {
	    __reserved__hasOwnProperty: t.func({
	      returns: t.BOOLEAN
	    }),
	    __reserved__isPrototypeOf: t.func({
	      returns: t.BOOLEAN
	    }),
	    __reserved__propertyIsEnumerable: t.func({
	      returns: t.BOOLEAN
	    }),
	    __reserved__toLocaleString: t.func({
	      returns: t.STRING
	    }),
	    __reserved__toString: t.func({
	      returns: t.STRING
	    }),
	    __reserved__valueOf: t.func({
	      returns: t.DYNAMIC
	    })
	  }
	});

	delete JS["@Object"].xtends;


/***/ },
/* 18 */
/***/ function(module, exports, __webpack_require__) {

	var JS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	JS = exports.JS = {};

	JS["String"] = t.func({
	  name: "String",
	  params: {
	    value: t.DYNAMIC
	  },
	  returns: t.STRING,
	  isConstructor: true,
	  members: {
	    fromCharCode: t.func({
	      returns: t.STRING
	    })
	  }
	});

	JS["@String"] = t.object({
	  name: "string",
	  ctor: "String",
	  xtends: "@Object",
	  members: {
	    charAt: t.func({
	      returns: t.STRING,
	      params: {
	        index: t.NUMBER
	      }
	    }),
	    charCodeAt: t.func({
	      returns: t.NUMBER,
	      params: {
	        index: t.NUMBER
	      }
	    }),
	    concat: t.func({
	      returns: t.STRING
	    }),
	    indexOf: t.func({
	      returns: t.NUMBER,
	      params: {
	        value: t.STRING
	      }
	    }),
	    lastIndexOf: t.func({
	      returns: t.NUMBER,
	      params: {
	        value: t.STRING
	      }
	    }),
	    localeCompare: t.func({
	      returns: t.NUMBER
	    }),
	    match: t.func({
	      returns: t.array()
	    }),
	    replace: t.func({
	      returns: t.STRING
	    }),
	    search: t.func({
	      returns: t.NUMBER
	    }),
	    slice: t.func({
	      returns: t.STRING
	    }),
	    split: t.func({
	      returns: t.array(t.STRING)
	    }),
	    substr: t.func({
	      returns: t.STRING
	    }),
	    substring: t.func({
	      returns: t.STRING
	    }),
	    toLocaleLowerCase: t.func({
	      returns: t.STRING
	    }),
	    toLocaleUpperCase: t.func({
	      returns: t.STRING
	    }),
	    toUpperCase: t.func({
	      returns: t.STRING
	    }),
	    toLowerCase: t.func({
	      returns: t.STRING
	    }),
	    trim: t.func({
	      returns: t.STRING
	    })
	  }
	});


/***/ },
/* 19 */
/***/ function(module, exports, __webpack_require__) {

	var JS, t;

	t = (__webpack_require__(10)).Type;

	JS = exports.JS = {};

	JS["Audio"] = t.func({
	  name: "Audio",
	  returns: "@Audio",
	  isConstructor: true,
	  params: {
	    url: t.STRING
	  }
	});

	JS["@Audio"] = t.object({
	  name: "audio",
	  ctor: "Audio",
	  xtends: "@Object",
	  members: {
	    currentTime: t.NUMBER,
	    ended: t.BOOLEAN,
	    loop: t.BOOLEAN,
	    onended: t.func(),
	    onplay: t.func(),
	    pause: t.func(),
	    paused: t.BOOLEAN,
	    play: t.func(),
	    playbackRate: t.NUMBER,
	    volume: t.NUMBER
	  }
	});


/***/ },
/* 20 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Obj, ObjMembers, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Obj = (__webpack_require__(17)).JS;

	ObjMembers = Object.keys(Obj["@Object"].members).map(function(name) {
	  return name.replace("__reserved__", "");
	});

	FJS = exports.FJS = {};

	FJS["@Point"] = t.object({
	  name: "point",
	  aliasOf: t.object({
	    members: {
	      x: t.NUMBER,
	      y: t.NUMBER
	    }
	  }),
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});

	FJS["@Size"] = t.object({
	  name: "size",
	  aliasOf: t.object({
	    members: {
	      width: t.NUMBER,
	      height: t.NUMBER
	    }
	  }),
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});

	FJS["@Frame"] = t.object({
	  name: "frame",
	  aliasOf: t.object({
	    members: {
	      x: t.NUMBER,
	      y: t.NUMBER,
	      width: t.NUMBER,
	      height: t.NUMBER
	    }
	  }),
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});

	FJS["@Rect"] = t.object({
	  name: "rect",
	  aliasOf: t.object({
	    members: {
	      left: t.NUMBER,
	      top: t.NUMBER,
	      right: t.NUMBER,
	      bottom: t.NUMBER
	    }
	  }),
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});

	FJS["@Padding"] = t.object({
	  name: "padding",
	  aliasOf: t.object({
	    members: {
	      horizontal: t.NUMBER,
	      vertical: t.NUMBER,
	      top: t.NUMBER,
	      bottom: t.NUMBER,
	      left: t.NUMBER,
	      right: t.NUMBER
	    }
	  }),
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});

	FJS["@Style"] = t.object;

	FJS["@Direction"] = t["enum"](t.STRING, ["up", "down", "left", "right"]);

	FJS["@ClassList"] = t.object({
	  members: {
	    add: t.func({
	      params: {
	        className: t.String
	      }
	    }),
	    remove: t.func({
	      params: {
	        className: t.String
	      }
	    }),
	    toggle: t.func({
	      params: {
	        className: t.String
	      }
	    }),
	    contains: t.func({
	      params: {
	        className: t.String
	      },
	      returns: t.BOOLEAN
	    })
	  }
	});

	FJS["@CurveOptions"] = t.object({
	  members: {
	    preset: t.STRING,
	    curveBezierValues: t.array(t.NUMBER),
	    tension: t.NUMBER,
	    friction: t.NUMBER,
	    velocity: t.NUMBER,
	    tolerance: t.NUMBER,
	    stiffness: t.NUMBER,
	    damping: t.NUMBER,
	    mass: t.NUMBER,
	    tolerance: t.NUMBER
	  },
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});

	FJS["@MomentumOptions"] = t.object({
	  members: {
	    friction: t.NUMBER,
	    tolerance: t.NUMBER
	  },
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});

	FJS["@BounceOptions"] = t.object({
	  members: {
	    friction: t.NUMBER,
	    tension: t.NUMBER,
	    tolerance: t.NUMBER
	  },
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});


/***/ },
/* 21 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Obj, ObjMembers, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Obj = (__webpack_require__(17)).JS;

	ObjMembers = Object.keys(Obj["@Object"].members).map(function(name) {
	  return name.replace("__reserved__", "");
	});

	FJS = exports.FJS = {};

	FJS["@CurveFunction"] = t.func({
	  annotations: {
	    asLiteral: true
	  }
	});

	FJS["@Spring"] = FJS.Spring = t.func({
	  returns: "@CurveFunction",
	  params: {
	    options: t.object({
	      members: {
	        damping: t.NUMBER,
	        mass: t.NUMBER,
	        velocity: t.NUMBER,
	        tension: t.NUMBER,
	        friction: t.NUMBER,
	        tolerance: t.NUMBER
	      },
	      annotations: {
	        asLiteral: true,
	        excludeInherited: ObjMembers,
	        memberGroups: [["damping", "mass", "velocity"], ["tension", "friction", "velocity", "tolerance"]]
	      }
	    }),
	    dampingRatio: t.NUMBER,
	    mass: t.NUMBER,
	    velocity: t.NUMBER
	  },
	  annotations: {
	    asLiteral: true
	  }
	});

	FJS["@Bezier"] = FJS.Bezier = t.func({
	  returns: "@CurveFunction",
	  params: {
	    p1x: t.NUMBER,
	    p1y: t.NUMBER,
	    p2x: t.NUMBER,
	    p2y: t.NUMBER
	  },
	  members: {
	    linear: "@CurveFunction",
	    ease: "@CurveFunction",
	    easeIn: "@CurveFunction",
	    easeOut: "@CurveFunction",
	    easeInOut: "@CurveFunction"
	  },
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});


/***/ },
/* 22 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, NodesMap, Obj, ObjMembers, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Obj = (__webpack_require__(17)).JS;

	ObjMembers = Object.keys(Obj["@Object"].members).map(function(name) {
	  return name.replace("__reserved__", "");
	});

	FJS = exports.FJS = {};

	NodesMap = __webpack_require__(42);

	exports.ReturnType = function(node) {
	  var location;
	  location = node.locationData.first_line + ":" + node.locationData.first_column + ")";
	  if (NodesMap.nameForNode(node) === "Op") {
	    location = node.first.locationData.first_line + ":" + node.first.locationData.first_column + ")";
	  }
	  return t.object({
	    name: 'animation',
	    aliasOf: "@Animation",
	    dynamic: false,
	    annotations: {
	      location: location
	    }
	  });
	};

	FJS["Animation"] = t.func({
	  isConstructor: true,
	  returns: exports.ReturnType,
	  name: "Animation",
	  params: {
	    layer: "@Layer",
	    properties: "@NumericalLayerOptions",
	    options: "@AnimationOptions"
	  }
	});

	FJS["@Animation"] = t.object({
	  name: "animation",
	  ctor: "Animation",
	  members: {
	    start: t.func(),
	    stop: t.func(),
	    reverse: t.func(),
	    reset: t.func(),
	    restart: t.func(),
	    finish: t.func(),
	    onAnimationStart: t.func(),
	    onAnimationHalt: t.func(),
	    onAnimationStop: t.func(),
	    onAnimationEnd: t.func(),
	    onAnimationDidStart: t.func(),
	    onAnimationDidStop: t.func(),
	    onAnimationDidEnd: t.func()
	  }
	});

	FJS["@AnimateParameters"] = t.object({
	  name: "animation",
	  xtends: "@NumericalLayerOptions",
	  members: {
	    options: "@AnimationOptions",
	    gradient: "@GradientOptions"
	  },
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});

	FJS["@AnimationOptions"] = t.object({
	  name: "options",
	  members: {
	    curve: "@CurveFunction",
	    time: t.NUMBER,
	    repeat: t.NUMBER,
	    delay: t.NUMBER,
	    debug: t.BOOLEAN,
	    colorModel: t.STRING
	  },
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});


/***/ },
/* 23 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Obj, ObjMembers, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Obj = (__webpack_require__(17)).JS;

	ObjMembers = Object.keys(Obj["@Object"].members).map(function(name) {
	  return name.replace("__reserved__", "");
	});

	FJS = exports.FJS = {};

	FJS["Color"] = t.func({
	  isConstructor: true,
	  returns: "@Color",
	  name: "Color",
	  params: {
	    options: "@ColorOptions"
	  },
	  members: {
	    isColor: t.func({
	      params: {
	        color: "@Color"
	      },
	      returns: t.BOOL
	    }),
	    isColorObject: t.func({
	      params: {
	        color: "@Color"
	      },
	      returns: t.BOOL
	    }),
	    isColorString: t.func({
	      params: {
	        colorString: t.STRING
	      },
	      returns: t.BOOL
	    }),
	    mix: t.func({
	      params: {
	        colorA: "@Color",
	        colorB: "@Color",
	        fraction: t.NUMBER
	      },
	      returns: "@Color"
	    }),
	    random: t.func({
	      params: {
	        alpha: t.NUMBER
	      },
	      returns: "@Color"
	    }),
	    equal: t.func({
	      params: {
	        colorA: "@Color",
	        colorB: "@Color"
	      },
	      returns: t.BOOL
	    })
	  }
	});

	FJS["@Color"] = t.object({
	  name: "color",
	  ctor: "Color",
	  members: {
	    lighten: t.func({
	      params: {
	        amount: t.NUMBER
	      },
	      returns: "@Color"
	    }),
	    brighten: t.func({
	      params: {
	        amount: t.NUMBER
	      },
	      returns: "@Color"
	    }),
	    darken: t.func({
	      params: {
	        amount: t.NUMBER
	      },
	      returns: "@Color"
	    }),
	    desaturate: t.func({
	      params: {
	        amount: t.NUMBER
	      },
	      returns: "@Color"
	    }),
	    saturate: t.func({
	      params: {
	        amount: t.NUMBER
	      },
	      returns: "@Color"
	    }),
	    grayscale: t.func({
	      returns: "@Color"
	    }),
	    gray: t.func({
	      params: {
	        amount: t.NUMBER,
	        alpha: t.NUMBER
	      },
	      returns: "@Color"
	    }),
	    mix: t.func({
	      params: {
	        colorB: "@Color",
	        fraction: t.NUMBER
	      },
	      returns: "@Color"
	    }),
	    isEqual: t.func({
	      params: {
	        colorB: "@Color"
	      },
	      returns: t.BOOL
	    })
	  }
	});

	FJS["@ColorOptions"] = t.object({
	  name: "color",
	  members: {
	    r: t.NUMBER,
	    g: t.NUMBER,
	    b: t.NUMBER,
	    a: t.NUMBER
	  },
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});


/***/ },
/* 24 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	FJS = exports.FJS = {};

	FJS["@Draggable"] = t.object({
	  name: "layer.draggable",
	  members: {
	    enabled: t.BOOLEAN,
	    horizontal: t.BOOLEAN,
	    vertical: t.BOOLEAN,
	    speedX: t.NUMBER,
	    speedY: t.NUMBER,
	    constraints: "@Frame",
	    constraintsOffset: "@Point",
	    isBeyondConstraints: t.BOOLEAN,
	    overdrag: t.BOOLEAN,
	    overdragScale: t.NUMBER,
	    momentum: t.BOOLEAN,
	    momentumOptions: "@MomentumOptions",
	    bounce: t.BOOLEAN,
	    bounceOptions: "@BounceOptions",
	    velocity: "@Point",
	    direction: "@Direction",
	    angle: t.NUMBER,
	    updatePosition: t.func({
	      params: {
	        x: t.NUMBER,
	        y: t.NUMBER
	      },
	      returns: "@Point"
	    }),
	    directionLock: t.BOOLEAN,
	    directionLockThreshold: "@Point",
	    pixelAlign: t.BOOLEAN,
	    isDragging: t.BOOLEAN,
	    isAnimating: t.BOOLEAN,
	    isMoving: t.BOOLEAN,
	    offset: "@Point",
	    layerStartPoint: "@Point",
	    cursorStartPoint: "@Point",
	    layerCursorOffset: "@Point",
	    propagateEvents: t.BOOLEAN,
	    rotatable: t.BOOLEAN,
	    pinchable: t.BOOLEAN,
	    onMove: t.func(),
	    onDragStart: t.func(),
	    onDragWillMove: t.func(),
	    onDragMove: t.func(),
	    onDragDidMove: t.func(),
	    onDrag: t.func(),
	    onDragEnd: t.func(),
	    onDragAnimationDidStart: t.func(),
	    onDragAnimationDidEnd: t.func(),
	    onDirectionLockDidStart: t.func(),
	    onPinch: t.func(),
	    onRotate: t.func()
	  }
	});


/***/ },
/* 25 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	FJS = exports.FJS = {};

	FJS.Events = t.object({
	  name: "Events",
	  asDictOfType: t.STRING,
	  members: {
	    Click: t.STRING,
	    TouchStart: t.STRING,
	    TouchMove: t.STRING,
	    TouchEnd: t.STRING,
	    MouseUp: t.STRING,
	    MouseDown: t.STRING,
	    MouseOver: t.STRING,
	    MouseOut: t.STRING,
	    MouseMove: t.STRING,
	    MouseWheel: t.STRING,
	    DoubleClick: t.STRING,
	    MouseDoubleClick: t.STRING,
	    AnimationStart: t.STRING,
	    AnimationStop: t.STRING,
	    AnimationEnd: t.STRING,
	    ImageLoaded: t.STRING,
	    ImageLoadError: t.STRING,
	    Move: t.STRING,
	    DragMove: t.STRING,
	    DragStart: t.STRING,
	    Drag: t.STRING,
	    DragEnd: t.STRING,
	    DragAnimationStart: t.STRING,
	    DragAnimationEnd: t.STRING,
	    DirectionLockStart: t.STRING,
	    ScrollStart: t.STRING,
	    Scroll: t.STRING,
	    ScrollEnd: t.STRING,
	    ScrollAnimationDidStart: t.STRING,
	    ScrollAnimationDidEnd: t.STRING,
	    StateSwitchStart: t.STRING,
	    StateSwitchStop: t.STRING,
	    StateSwitchEnd: t.STRING,
	    SliderValueChange: t.STRING,
	    SliderValueChange: t.STRING,
	    SliderMinValueChange: t.STRING,
	    SliderMaxValueChange: t.STRING,
	    Tap: t.STRING,
	    TapStart: t.STRING,
	    TapEnd: t.STRING,
	    DoubleTap: t.STRING,
	    ForceTap: t.STRING,
	    ForceTapChange: t.STRING,
	    ForceTapStart: t.STRING,
	    ForceTapEnd: t.STRING,
	    LongPress: t.STRING,
	    LongPressStart: t.STRING,
	    LongPressEnd: t.STRING,
	    Swipe: t.STRING,
	    SwipeStart: t.STRING,
	    SwipeEnd: t.STRING,
	    SwipeUp: t.STRING,
	    SwipeUpStart: t.STRING,
	    SwipeUpEnd: t.STRING,
	    SwipeDown: t.STRING,
	    SwipeDownStart: t.STRING,
	    SwipeDownEnd: t.STRING,
	    SwipeLeft: t.STRING,
	    SwipeLeftStart: t.STRING,
	    SwipeLeftEnd: t.STRING,
	    SwipeRight: t.STRING,
	    SwipeRightStart: t.STRING,
	    SwipeRightEnd: t.STRING,
	    EdgeSwipe: t.STRING,
	    EdgeSwipeStart: t.STRING,
	    EdgeSwipeEnd: t.STRING,
	    EdgeSwipeTop: t.STRING,
	    EdgeSwipeTopStart: t.STRING,
	    EdgeSwipeTopEnd: t.STRING,
	    EdgeSwipeRight: t.STRING,
	    EdgeSwipeRightStart: t.STRING,
	    EdgeSwipeRightEnd: t.STRING,
	    EdgeSwipeBottom: t.STRING,
	    EdgeSwipeBottomStart: t.STRING,
	    EdgeSwipeBottomEnd: t.STRING,
	    EdgeSwipeLeft: t.STRING,
	    EdgeSwipeLeftStart: t.STRING,
	    EdgeSwipeLeftEnd: t.STRING,
	    Pan: t.STRING,
	    PanStart: t.STRING,
	    PanEnd: t.STRING,
	    PanLeft: t.STRING,
	    PanRight: t.STRING,
	    PanUp: t.STRING,
	    PanDown: t.STRING,
	    Pinch: t.STRING,
	    PinchStart: t.STRING,
	    PinchEnd: t.STRING,
	    Scale: t.STRING,
	    ScaleStart: t.STRING,
	    ScaleEnd: t.STRING,
	    Rotate: t.STRING,
	    RotateStart: t.STRING,
	    RotateEnd: t.STRING
	  }
	});


/***/ },
/* 26 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	FJS = exports.FJS = {};

	FJS.Gestures = t.object({
	  name: "Gestures",
	  asDictOfType: t.STRING,
	  members: {
	    Tap: t.STRING,
	    TapStart: t.STRING,
	    TapEnd: t.STRING,
	    DoubleTap: t.STRING,
	    ForceTap: t.STRING,
	    ForceTapChange: t.STRING,
	    ForceTapStart: t.STRING,
	    ForceTapEnd: t.STRING,
	    LongPress: t.STRING,
	    LongPressStart: t.STRING,
	    LongPressEnd: t.STRING,
	    Swipe: t.STRING,
	    SwipeStart: t.STRING,
	    SwipeEnd: t.STRING,
	    SwipeUp: t.STRING,
	    SwipeUpStart: t.STRING,
	    SwipeUpEnd: t.STRING,
	    SwipeDown: t.STRING,
	    SwipeDownStart: t.STRING,
	    SwipeDownEnd: t.STRING,
	    SwipeLeft: t.STRING,
	    SwipeLeftStart: t.STRING,
	    SwipeLeftEnd: t.STRING,
	    SwipeRight: t.STRING,
	    SwipeRightStart: t.STRING,
	    SwipeRightEnd: t.STRING,
	    EdgeSwipe: t.STRING,
	    EdgeSwipeStart: t.STRING,
	    EdgeSwipeEnd: t.STRING,
	    EdgeSwipeTop: t.STRING,
	    EdgeSwipeTopStart: t.STRING,
	    EdgeSwipeTopEnd: t.STRING,
	    EdgeSwipeRight: t.STRING,
	    EdgeSwipeRightStart: t.STRING,
	    EdgeSwipeRightEnd: t.STRING,
	    EdgeSwipeBottom: t.STRING,
	    EdgeSwipeBottomStart: t.STRING,
	    EdgeSwipeBottomEnd: t.STRING,
	    EdgeSwipeLeft: t.STRING,
	    EdgeSwipeLeftStart: t.STRING,
	    EdgeSwipeLeftEnd: t.STRING,
	    Pan: t.STRING,
	    PanStart: t.STRING,
	    PanEnd: t.STRING,
	    PanLeft: t.STRING,
	    PanRight: t.STRING,
	    PanUp: t.STRING,
	    PanDown: t.STRING,
	    Pinch: t.STRING,
	    PinchStart: t.STRING,
	    PinchEnd: t.STRING,
	    Scale: t.STRING,
	    ScaleStart: t.STRING,
	    ScaleEnd: t.STRING,
	    Rotate: t.STRING,
	    RotateStart: t.STRING,
	    RotateEnd: t.STRING
	  }
	});


/***/ },
/* 27 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	FJS = exports.FJS = {};

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	FJS = exports.FJS = {};

	FJS.print = t.func({
	  returns: t.DYNAMIC
	});

	FJS.Canvas = t.object({
	  name: "Canvas",
	  members: {
	    width: t.NUMBER,
	    height: t.NUMBER,
	    size: "@Size",
	    image: t.STRING,
	    backgroundColor: "@Color",
	    convertPointToScreen: t.func({
	      params: {
	        point: "@Point"
	      },
	      returns: "@Point"
	    }),
	    convertPointToLayer: t.func({
	      params: {
	        point: "@Point",
	        layer: "@Layer"
	      },
	      returns: "@Point"
	    }),
	    onChange: t.func(),
	    onResize: t.func()
	  }
	});

	FJS.Screen = t.object({
	  name: "Screen",
	  members: {
	    width: t.NUMBER,
	    height: t.NUMBER,
	    frame: "@Frame",
	    size: "@Size",
	    backgroundColor: "@Color",
	    canvasFrame: "@Frame",
	    perspective: t.NUMBER,
	    perspectiveOriginX: t.NUMBER,
	    perspectiveOriginY: t.NUMBER,
	    convertPointToCanvas: t.func({
	      params: {
	        point: "@Point"
	      },
	      returns: "@Point"
	    }),
	    convertPointToLayer: t.func({
	      params: {
	        point: "@Point",
	        layer: "@Layer"
	      },
	      returns: "@Point"
	    }),
	    onChange: t.func(),
	    onEdgeSwipe: t.func(),
	    onEdgeSwipeStart: t.func(),
	    onEdgeSwipeEnd: t.func(),
	    onEdgeSwipeTop: t.func(),
	    onEdgeSwipeTopStart: t.func(),
	    onEdgeSwipeTopEnd: t.func(),
	    onEdgeSwipeRight: t.func(),
	    onEdgeSwipeRightStart: t.func(),
	    onEdgeSwipeRightEnd: t.func(),
	    onEdgeSwipeBottom: t.func(),
	    onEdgeSwipeBottomStart: t.func(),
	    onEdgeSwipeBottomEnd: t.func(),
	    onEdgeSwipeLeft: t.func(),
	    onEdgeSwipeLeftStart: t.func(),
	    onEdgeSwipeLeftEnd: t.func()
	  }
	});

	FJS.Align = t.object({
	  name: "Align",
	  members: {
	    center: t.NUMBER,
	    left: t.NUMBER,
	    right: t.NUMBER,
	    top: t.NUMBER,
	    bottom: t.NUMBER
	  }
	});


/***/ },
/* 28 */
/***/ function(module, exports, __webpack_require__) {

	var AnimationReturnType, FJS, Layer, NodesMap, Obj, ObjMembers, TypeDict, TypeUtils, Utils, layer, t;

	t = (__webpack_require__(10)).Type;

	Utils = __webpack_require__(3);

	TypeDict = (__webpack_require__(44)).TypeDict;

	NodesMap = __webpack_require__(42);

	TypeUtils = __webpack_require__(45);

	AnimationReturnType = (__webpack_require__(22)).ReturnType;

	FJS = exports.FJS = {};

	Obj = (__webpack_require__(17)).JS;

	ObjMembers = Object.keys(Obj["@Object"].members).map(function(name) {
	  return name.replace("__reserved__", "");
	});

	FJS["Layer"] = Layer = TypeUtils.defineLayerLike("Layer");

	FJS["@LayerEventHandler"] = t.func({
	  bindCalleeLayer: true,
	  params: {
	    event: t.object(),
	    layer: "@Layer"
	  }
	});

	FJS["@LayerEventHandlerSetter"] = t.func({
	  bindCalleeLayer: true,
	  params: {
	    handler: "@LayerEventHandler"
	  }
	});

	FJS["@Layer"] = layer = t.object({
	  name: "layer",
	  ctor: "Layer",
	  members: {
	    id: t.STRING,
	    name: t.STRING,
	    x: t.NUMBER,
	    y: t.NUMBER,
	    z: t.NUMBER,
	    width: t.NUMBER,
	    height: t.NUMBER,
	    minX: t.NUMBER,
	    midX: t.NUMBER,
	    maxX: t.NUMBER,
	    minY: t.NUMBER,
	    midY: t.NUMBER,
	    maxY: t.NUMBER,
	    point: "@Point",
	    size: "@Size",
	    frame: "@Frame",
	    center: t.func({
	      returns: "@Layer"
	    }),
	    centerX: t.func({
	      params: {
	        offset: t.NUMBER
	      },
	      returns: "@Layer"
	    }),
	    centerY: t.func({
	      params: {
	        offset: t.NUMBER
	      },
	      returns: "@Layer"
	    }),
	    pixelAlign: t.func({
	      returns: "@Layer"
	    }),
	    screenFrame: "@Frame",
	    contentFrame: t.func(),
	    centerFrame: t.func(),
	    backgroundColor: "@Color",
	    color: "@Color",
	    image: t.STRING,
	    gradient: "@Gradient",
	    visible: t.BOOLEAN,
	    opacity: t.NUMBER,
	    clip: t.BOOLEAN,
	    ignoreEvents: t.BOOLEAN,
	    force2d: t.BOOLEAN,
	    originX: t.NUMBER,
	    originY: t.NUMBER,
	    originZ: t.NUMBER,
	    perspective: t.NUMBER,
	    perspectiveOriginX: t.NUMBER,
	    perspectiveOriginY: t.NUMBER,
	    backfaceVisible: t.BOOLEAN,
	    rotation: t.NUMBER,
	    rotationX: t.NUMBER,
	    rotationY: t.NUMBER,
	    rotationZ: t.NUMBER,
	    scale: t.NUMBER,
	    scaleX: t.NUMBER,
	    scaleY: t.NUMBER,
	    superLayer: "@Layer",
	    subLayers: t.array("@Layer"),
	    subLayersByName: t.func({
	      params: {
	        name: t.STRING
	      },
	      returns: t.array("@Layer")
	    }),
	    addSubLayer: t.func({
	      params: {
	        layer: "@Layer"
	      }
	    }),
	    removeSubLayer: t.func({
	      params: {
	        layer: "@Layer"
	      }
	    }),
	    siblingLayers: t.func({
	      returns: t.array("@Layer")
	    }),
	    parent: "@Layer",
	    children: t.array("@Layer"),
	    siblings: t.array("@Layer"),
	    ancestors: t.func({
	      returns: t.array("@Layer")
	    }),
	    addChild: t.func({
	      params: {
	        layer: "@Layer"
	      }
	    }),
	    removeChild: t.func({
	      params: {
	        layer: "@Layer"
	      }
	    }),
	    childrenWithName: t.func({
	      params: {
	        name: t.STRING
	      },
	      returns: t.array("@Layer")
	    }),
	    siblingsWithName: t.func({
	      params: {
	        name: t.STRING
	      },
	      returns: t.array("@Layer")
	    }),
	    childrenAbove: t.func({
	      params: {
	        point: "@Point",
	        originX: t.NUMBER,
	        originY: t.NUMBER
	      },
	      returns: t.array("@Layer")
	    }),
	    childrenBelow: t.func({
	      params: {
	        point: "@Point",
	        originX: t.NUMBER,
	        originY: t.NUMBER
	      },
	      returns: t.array("@Layer")
	    }),
	    childrenLeft: t.func({
	      params: {
	        point: "@Point",
	        originX: t.NUMBER,
	        originY: t.NUMBER
	      },
	      returns: t.array("@Layer")
	    }),
	    childrenRight: t.func({
	      params: {
	        point: "@Point",
	        originX: t.NUMBER,
	        originY: t.NUMBER
	      },
	      returns: t.array("@Layer")
	    }),
	    placeBefore: t.func({
	      params: {
	        layer: "@Layer"
	      }
	    }),
	    placeBehind: t.func({
	      params: {
	        layer: "@Layer"
	      }
	    }),
	    bringToFront: t.func(),
	    sendToBack: t.func(),
	    html: t.STRING,
	    style: "@Style",
	    computedStyle: t.func({
	      returns: "@Style"
	    }),
	    classList: "@ClassList",
	    destroy: t.func(),
	    copy: t.func({
	      returns: "@Layer"
	    }),
	    copySingle: t.func({
	      returns: "@Layer"
	    }),
	    blur: t.NUMBER,
	    brightness: t.NUMBER,
	    saturate: t.NUMBER,
	    hueRotate: t.NUMBER,
	    contrast: t.NUMBER,
	    invert: t.NUMBER,
	    grayscale: t.NUMBER,
	    sepia: t.NUMBER,
	    shadowX: t.NUMBER,
	    shadowY: t.NUMBER,
	    shadowBlur: t.NUMBER,
	    shadowSpread: t.NUMBER,
	    shadowColor: "@Color",
	    borderColor: "@Color",
	    borderWidth: t.object({
	      annotations: {
	        asLiteral: true,
	        excludeInherited: ObjMembers
	      },
	      members: {
	        top: t.NUMBER,
	        right: t.NUMBER,
	        bottom: t.NUMBER,
	        left: t.NUMBER
	      }
	    }),
	    borderRadius: t.object({
	      annotations: {
	        asLiteral: true,
	        excludeInherited: ObjMembers
	      },
	      members: {
	        topRight: t.NUMBER,
	        bottomRight: t.NUMBER,
	        bottomLeft: t.NUMBER,
	        topLeft: t.NUMBER
	      }
	    }),
	    animate: t.func({
	      params: {
	        properties: "@AnimateParameters",
	        options: "@AnimationOptions"
	      },
	      returns: AnimationReturnType
	    }),
	    stateSwitch: t.func({
	      params: {
	        state: t.STRING,
	        options: "@AnimationOptions"
	      }
	    }),
	    animateStop: t.func(),
	    animations: t.func({
	      returns: t.array("@Animation")
	    }),
	    isAnimating: t.BOOLEAN,
	    animationOptions: "@AnimationOptions",
	    states: "@States",
	    stateNames: t.array(t.STRING),
	    stateCycle: t.func({
	      params: {
	        states: t.array(t.STRING, {
	          options: "@AnimationOptions"
	        })
	      }
	    }),
	    propagateEvents: t.BOOLEAN,
	    on: t.func({
	      bindCalleeLayer: true,
	      params: {
	        name: t.STRING,
	        handler: "@LayerEventHandler"
	      }
	    }),
	    off: t.func({
	      bindCalleeLayer: true,
	      params: {
	        name: t.STRING,
	        handler: "@LayerEventHandler"
	      }
	    }),
	    draggable: "@Draggable",
	    pinchable: "@Pinchable",
	    custom: t.UNKNOWN,
	    props: t.UNKNOWN,
	    convertPointToCanvas: t.func({
	      params: {
	        point: "@Point"
	      },
	      returns: "@Point"
	    }),
	    convertPointToScreen: t.func({
	      params: {
	        point: "@Point"
	      },
	      returns: "@Point"
	    }),
	    convertPointToLayer: t.func({
	      params: {
	        point: "@Point",
	        layer: "@Layer"
	      },
	      returns: "@Point"
	    }),
	    onChange: "@LayerEventHandlerSetter",
	    onResize: "@LayerEventHandlerSetter",
	    onClick: "@LayerEventHandlerSetter",
	    onDoubleClick: "@LayerEventHandlerSetter",
	    onScroll: "@LayerEventHandlerSetter",
	    onScrollStart: "@LayerEventHandlerSetter",
	    onScrollEnd: "@LayerEventHandlerSetter",
	    onScrollAnimationDidStart: "@LayerEventHandlerSetter",
	    onScrollAnimationDidEnd: "@LayerEventHandlerSetter",
	    onTouchStart: "@LayerEventHandlerSetter",
	    onTouchEnd: "@LayerEventHandlerSetter",
	    onTouchMove: "@LayerEventHandlerSetter",
	    onMouseUp: "@LayerEventHandlerSetter",
	    onMouseDown: "@LayerEventHandlerSetter",
	    onMouseOver: "@LayerEventHandlerSetter",
	    onMouseOut: "@LayerEventHandlerSetter",
	    onMouseMove: "@LayerEventHandlerSetter",
	    onMouseWheel: "@LayerEventHandlerSetter",
	    onAnimationStart: "@LayerEventHandlerSetter",
	    onAnimationStop: "@LayerEventHandlerSetter",
	    onAnimationEnd: "@LayerEventHandlerSetter",
	    onImageLoaded: "@LayerEventHandlerSetter",
	    onImageLoadError: "@LayerEventHandlerSetter",
	    onImageLoadCancelled: "@LayerEventHandlerSetter",
	    onMove: "@LayerEventHandlerSetter",
	    onDragStart: "@LayerEventHandlerSetter",
	    onDragWillMove: "@LayerEventHandlerSetter",
	    onDragMove: "@LayerEventHandlerSetter",
	    onDragDidMove: "@LayerEventHandlerSetter",
	    onDrag: "@LayerEventHandlerSetter",
	    onDragEnd: "@LayerEventHandlerSetter",
	    onDragAnimationStart: "@LayerEventHandlerSetter",
	    onDragAnimationEnd: "@LayerEventHandlerSetter",
	    onDirectionLockStart: "@LayerEventHandlerSetter",
	    onStateSwitchStart: "@LayerEventHandlerSetter",
	    onStateSwitchStop: "@LayerEventHandlerSetter",
	    onStateSwitchEnd: "@LayerEventHandlerSetter",
	    onTap: "@LayerEventHandlerSetter",
	    onTapStart: "@LayerEventHandlerSetter",
	    onTapEnd: "@LayerEventHandlerSetter",
	    onDoubleTap: "@LayerEventHandlerSetter",
	    onForceTap: "@LayerEventHandlerSetter",
	    onForceTapChange: "@LayerEventHandlerSetter",
	    onForceTapStart: "@LayerEventHandlerSetter",
	    onForceTapEnd: "@LayerEventHandlerSetter",
	    onLongPress: "@LayerEventHandlerSetter",
	    onLongPressStart: "@LayerEventHandlerSetter",
	    onLongPressEnd: "@LayerEventHandlerSetter",
	    onSwipe: "@LayerEventHandlerSetter",
	    onSwipeStart: "@LayerEventHandlerSetter",
	    onSwipeEnd: "@LayerEventHandlerSetter",
	    onSwipeUp: "@LayerEventHandlerSetter",
	    onSwipeUpStart: "@LayerEventHandlerSetter",
	    onSwipeUpEnd: "@LayerEventHandlerSetter",
	    onSwipeDown: "@LayerEventHandlerSetter",
	    onSwipeDownStart: "@LayerEventHandlerSetter",
	    onSwipeDownEnd: "@LayerEventHandlerSetter",
	    onSwipeLeft: "@LayerEventHandlerSetter",
	    onSwipeLeftStart: "@LayerEventHandlerSetter",
	    onSwipeLeftEnd: "@LayerEventHandlerSetter",
	    onSwipeRight: "@LayerEventHandlerSetter",
	    onSwipeRightStart: "@LayerEventHandlerSetter",
	    onSwipeRightEnd: "@LayerEventHandlerSetter",
	    onPan: "@LayerEventHandlerSetter",
	    onPanStart: "@LayerEventHandlerSetter",
	    onPanEnd: "@LayerEventHandlerSetter",
	    onPanLeft: "@LayerEventHandlerSetter",
	    onPanRight: "@LayerEventHandlerSetter",
	    onPanUp: "@LayerEventHandlerSetter",
	    onPanDown: "@LayerEventHandlerSetter",
	    onPinch: "@LayerEventHandlerSetter",
	    onPinchStart: "@LayerEventHandlerSetter",
	    onPinchEnd: "@LayerEventHandlerSetter",
	    onScale: "@LayerEventHandlerSetter",
	    onScaleStart: "@LayerEventHandlerSetter",
	    onScaleEnd: "@LayerEventHandlerSetter",
	    onRotate: "@LayerEventHandlerSetter",
	    onRotateStart: "@LayerEventHandlerSetter",
	    onRotateEnd: "@LayerEventHandlerSetter"
	  }
	});

	FJS["@LayerOptions"] = t.options(layer, void 0, function(member, value) {
	  return value === "@LayerEventHandlerSetter" || t.isFunc(value);
	});

	FJS["@NumericalLayerOptions"] = t.options(layer, void 0, function(member, value) {
	  return value !== t.NUMBER && value !== "@Color" && value !== "@Gradient";
	});


/***/ },
/* 29 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Obj, ObjMembers, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Obj = (__webpack_require__(17)).JS;

	ObjMembers = Object.keys(Obj["@Object"].members).map(function(name) {
	  return name.replace("__reserved__", "");
	});

	FJS = exports.FJS = {};

	FJS["Gradient"] = t.func({
	  isConstructor: true,
	  returns: "@Gradient",
	  name: "Gradient",
	  params: {
	    options: "@GradientOptions"
	  },
	  members: {
	    isGradient: t.func({
	      params: {
	        gradient: "@Gradient"
	      },
	      returns: t.BOOL
	    }),
	    mix: t.func({
	      params: {
	        gradientA: "@Gradient",
	        gradientB: "@Gradient",
	        fraction: t.NUMBER
	      },
	      returns: "@Gradient"
	    }),
	    random: t.func({
	      returns: "@Gradient"
	    }),
	    equal: t.func({
	      params: {
	        gradientA: "@Gradient",
	        gradientB: "@Gradient"
	      },
	      returns: t.BOOL
	    })
	  }
	});

	FJS["@Gradient"] = t.object({
	  name: "gradient",
	  ctor: "Gradient",
	  members: {
	    mix: t.func({
	      params: {
	        gradientB: "@Gradient",
	        fraction: t.NUMBER
	      },
	      returns: "@Gradient"
	    }),
	    isEqual: t.func({
	      params: {
	        gradientB: "@Gradient"
	      },
	      returns: t.BOOL
	    }),
	    start: "@Color",
	    end: "@Color",
	    angle: t.NUMBER
	  }
	});

	FJS["@GradientOptions"] = t.object({
	  name: "gradient",
	  members: {
	    start: "@Color",
	    end: "@Color",
	    angle: t.NUMBER
	  },
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});


/***/ },
/* 30 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Layer, TypeDict, TypeUtils, Utils, options, t, textLayer;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Layer = (__webpack_require__(28)).FJS;

	Utils = __webpack_require__(3);

	TypeUtils = __webpack_require__(45);

	FJS = exports.FJS = {};

	FJS["TextLayer"] = TypeUtils.defineLayerLike("TextLayer", {
	  members: {
	    wrap: t.func({
	      params: {
	        layer: "@Layer"
	      },
	      returns: "@TextLayer"
	    })
	  }
	});

	FJS["@TextLayer"] = textLayer = t.object({
	  name: "textLayer",
	  ctor: "TextLayer",
	  xtends: "@Layer",
	  members: {
	    text: t.STRING,
	    padding: "@Padding",
	    fontFamily: t.STRING,
	    fontSize: t.NUMBER,
	    fontWeight: t.NUMBER,
	    fontStyle: t.STRING,
	    lineHeight: t.NUMBER,
	    letterSpacing: t.NUMBER,
	    wordSpacing: t.NUMBER,
	    textAlign: t.NUMBER,
	    textTransform: t.STRING,
	    textIndent: t.NUMBER,
	    textDecoration: t.STRING,
	    textOverflow: t.STRING,
	    textStyle: t.object,
	    direction: t.STRING,
	    textDirection: t.STRING,
	    font: t.STRING,
	    truncate: t.BOOLEAN,
	    textStyle: t.object()
	  }
	});

	options = t.options(textLayer, Layer["@LayerOptions"]);

	FJS["@TextLayerOptions"] = options;


/***/ },
/* 31 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Layer, TypeDict, TypeUtils, Utils, midiComponent, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Layer = (__webpack_require__(28)).FJS;

	Utils = __webpack_require__(3);

	TypeUtils = __webpack_require__(45);

	FJS = exports.FJS = {};

	FJS["MIDIComponent"] = t.func({
	  name: "MIDIComponent",
	  isConstructor: true,
	  returns: "@MIDIComponent",
	  params: {
	    options: "@MIDIComponentOptions"
	  }
	});

	FJS["@MIDIComponent"] = midiComponent = t.object({
	  name: "midiComponent",
	  ctor: "MIDIComponent",
	  members: {
	    min: t.NUMBER,
	    max: t.NUMBER,
	    control: t.NUMBER,
	    channel: t.NUMBER,
	    source: t.STRING,
	    onValueChange: t.func()
	  }
	});

	FJS["@MIDIComponentOptions"] = t.options(midiComponent);


/***/ },
/* 32 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Layer, TypeDict, TypeUtils, Utils, backgroundLayer, t, videoLayer;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Utils = __webpack_require__(3);

	Layer = (__webpack_require__(28)).FJS;

	TypeUtils = __webpack_require__(45);

	FJS = exports.FJS = {};

	FJS["BackgroundLayer"] = TypeUtils.defineLayerLike("BackgroundLayer");

	FJS["@BackgroundLayer"] = backgroundLayer = t.object({
	  name: "backgroundLayer",
	  ctor: "BackgroundLayer",
	  xtends: "@Layer"
	});

	FJS["@BackgroundLayerOptions"] = t.options(backgroundLayer, Layer["@LayerOptions"]);

	FJS["VideoLayer"] = TypeUtils.defineLayerLike("VideoLayer");

	FJS["@VideoLayer"] = videoLayer = t.object({
	  name: "videoLayer",
	  ctor: "VideoLayer",
	  xtends: "@Layer",
	  members: {
	    video: t.STRING,
	    player: t.DYNAMIC
	  }
	});

	FJS["@VideoLayerOptions"] = t.options(videoLayer, Layer["@LayerOptions"]);


/***/ },
/* 33 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Layer, TypeDict, TypeUtils, Utils, flowComponent, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Layer = (__webpack_require__(28)).FJS;

	Utils = __webpack_require__(3);

	TypeUtils = __webpack_require__(45);

	FJS = exports.FJS = {};

	FJS["FlowComponent"] = TypeUtils.defineLayerLike("FlowComponent");

	FJS["@FlowComponent"] = flowComponent = t.object({
	  name: "flowComponent",
	  ctor: "FlowComponent",
	  xtends: "@Layer",
	  members: {
	    current: "@Layer",
	    previous: "@Layer",
	    header: "@Layer",
	    footer: "@Layer",
	    stack: t.array("@Layer"),
	    reset: t.func(),
	    showNext: t.func({
	      params: {
	        layer: "@Layer",
	        options: "@ShowNextOptions"
	      }
	    }),
	    showPrevious: t.func({
	      params: {
	        layer: "@Layer",
	        options: "@ShowPreviousOptions"
	      }
	    }),
	    showOverlayCenter: t.func({
	      params: {
	        layer: "@Layer",
	        options: "@ShowOverlayOptions"
	      }
	    }),
	    showOverlayLeft: t.func({
	      params: {
	        layer: "@Layer",
	        options: "@ShowOverlayOptions"
	      }
	    }),
	    showOverlayRight: t.func({
	      params: {
	        layer: "@Layer",
	        options: "@ShowOverlayOptions"
	      }
	    }),
	    showOverlayTop: t.func({
	      params: {
	        layer: "@Layer",
	        options: "@ShowOverlayOptions"
	      }
	    }),
	    showOverlayBottom: t.func({
	      params: {
	        layer: "@Layer",
	        options: "@ShowOverlayOptions"
	      }
	    }),
	    transition: t.func({
	      params: {
	        layer: "@Layer",
	        transition: t.func(),
	        options: "@ShowOverlayOptions"
	      }
	    }),
	    onTransitionStart: "@LayerEventHandlerSetter",
	    onTransitionHalt: "@LayerEventHandlerSetter",
	    onTransitionStop: "@LayerEventHandlerSetter",
	    onTransitionEnd: "@LayerEventHandlerSetter"
	  }
	});

	FJS["@FlowComponentOptions"] = t.options(flowComponent, Layer["@LayerOptions"]);

	FJS["@ShowNextOptions"] = t.object({
	  members: {
	    animate: t.BOOLEAN,
	    scroll: t.BOOLEAN
	  }
	});

	FJS["@ShowPreviousOptions"] = t.object({
	  members: {
	    animate: t.BOOLEAN
	  }
	});

	FJS["@ShowOverlayOptions"] = t.object({
	  members: {
	    animate: t.BOOLEAN,
	    scroll: t.BOOLEAN,
	    modal: t.BOOLEAN
	  }
	});


/***/ },
/* 34 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, ScrollComponent, TypeDict, TypeUtils, Utils, pageComponent, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	ScrollComponent = (__webpack_require__(36)).FJS;

	Utils = __webpack_require__(3);

	TypeUtils = __webpack_require__(45);

	FJS = exports.FJS = {};

	FJS["PageComponent"] = TypeUtils.defineLayerLike("PageComponent", {
	  wrap: t.func({
	    params: {
	      layer: "@Layer"
	    },
	    returns: "@PageComponent"
	  })
	});

	FJS["@PageComponent"] = pageComponent = t.object({
	  name: "pageComponent",
	  ctor: "PageComponent",
	  xtends: "@ScrollComponent",
	  members: {
	    velocityThreshold: t.NUMBER,
	    animationOptions: "@AnimationOptions",
	    currentPage: "@Layer",
	    closestPage: "@Layer",
	    previousPage: "@Layer",
	    nextPage: t.func({
	      returns: "@Layer",
	      params: {
	        direction: "@Direction",
	        currentPage: "@Layer"
	      }
	    }),
	    snapToPage: t.func({
	      params: {
	        page: "@Layer",
	        animate: t.BOOLEAN,
	        animationOptions: "@AnimationOptions"
	      }
	    }),
	    snapToNextPage: t.func({
	      params: {
	        direction: "@Direction",
	        animate: t.BOOLEAN,
	        animationOptions: "@AnimationOptions"
	      }
	    }),
	    snapToPreviousPage: t.func(),
	    addPage: t.func({
	      params: {
	        page: "@Layer",
	        direction: "@Direction"
	      }
	    }),
	    nextPage: t.func({
	      params: {
	        page: "@Layer",
	        direction: "@Direction"
	      }
	    }),
	    horizontalPageIndex: t.func({
	      params: {
	        page: "@Layer"
	      },
	      returns: "@Layer"
	    }),
	    verticalPageIndex: t.func({
	      params: {
	        page: "@Layer"
	      },
	      returns: "@Layer"
	    })
	  }
	});

	FJS["@PageComponentOptions"] = t.options(pageComponent, ScrollComponent["@ScrollComponentOptions"]);


/***/ },
/* 35 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	FJS = exports.FJS = {};

	FJS["@Pinchable"] = t.object({
	  name: "layer.pinchable",
	  members: {
	    enabled: t.BOOLEAN,
	    threshold: t.NUMBER,
	    centerOrigin: t.BOOLEAN,
	    scale: t.BOOLEAN,
	    scaleIncrements: t.NUMBER,
	    minScale: t.NUMBER,
	    maxScale: t.NUMBER,
	    scaleFactor: t.NUMBER,
	    rotate: t.BOOLEAN,
	    rotateIncrements: t.NUMBER,
	    rotateMin: t.NUMBER,
	    rotateMax: t.NUMBER,
	    rotateFactor: t.NUMBER,
	    onPinchStart: "@LayerEventHandlerSetter",
	    onPinchEnd: "@LayerEventHandlerSetter",
	    onPinch: "@LayerEventHandlerSetter",
	    onRotateStart: "@LayerEventHandlerSetter",
	    onRotate: "@LayerEventHandlerSetter",
	    onRotateEnd: "@LayerEventHandlerSetter",
	    onScaleStart: "@LayerEventHandlerSetter",
	    onScale: "@LayerEventHandlerSetter",
	    onScaleEnd: "@LayerEventHandlerSetter"
	  }
	});


/***/ },
/* 36 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Layer, TypeDict, TypeUtils, Utils, options, scrollComponent, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Layer = (__webpack_require__(28)).FJS;

	Utils = __webpack_require__(3);

	TypeUtils = __webpack_require__(45);

	FJS = exports.FJS = {};

	FJS["ScrollComponent"] = TypeUtils.defineLayerLike("ScrollComponent", {
	  members: {
	    wrap: t.func({
	      params: {
	        layer: "@Layer"
	      },
	      returns: "@ScrollComponent"
	    })
	  }
	});

	FJS["@ScrollComponent"] = scrollComponent = t.object({
	  name: "scrollComponent",
	  ctor: "ScrollComponent",
	  xtends: "@Layer",
	  members: {
	    content: "@Layer",
	    contentInset: "@Rect",
	    speedX: t.NUMBER,
	    speedY: t.NUMBER,
	    scroll: t.BOOLEAN,
	    scrollHorizontal: t.BOOLEAN,
	    scrollVertical: t.BOOLEAN,
	    scrollX: t.NUMBER,
	    scrollY: t.NUMBER,
	    scrollPoint: "@Point",
	    scrollFrame: "@Frame",
	    velocity: t.NUMBER,
	    direction: "@Direction",
	    angle: t.NUMBER,
	    directionLock: t.BOOLEAN,
	    closestContentLayer: t.func({
	      params: {
	        originX: t.NUMBER,
	        originY: t.NUMBER
	      },
	      returns: "@Layer"
	    }),
	    closestContentLayerForScrollPoint: t.func({
	      params: {
	        point: "@Point"
	      },
	      returns: "@Layer"
	    }),
	    scrollToPoint: t.func({
	      params: {
	        point: "@Point",
	        animate: t.BOOLEAN,
	        animationOptions: "@AnimationOptions"
	      }
	    }),
	    scrollToLayer: t.func({
	      params: {
	        layer: "@Layer",
	        originX: t.NUMBER,
	        originY: t.NUMBER,
	        animate: t.BOOLEAN,
	        animationOptions: "@AnimationOptions"
	      }
	    }),
	    scrollToClosestLayer: t.func({
	      params: {
	        originX: t.NUMBER,
	        originY: t.NUMBER
	      }
	    }),
	    mouseWheelEnabled: t.BOOLEAN,
	    updateContent: t.func(),
	    copy: t.func({
	      returns: "@ScrollComponent"
	    })
	  }
	});

	options = t.options(scrollComponent, Layer["@LayerOptions"]);

	options.members.wrap = t.func({
	  params: {
	    layer: "@Layer"
	  },
	  returns: "@ScrollComponent"
	});

	FJS["@ScrollComponentOptions"] = options;


/***/ },
/* 37 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Layer, TypeDict, TypeUtils, Utils, sliderComponent, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Layer = (__webpack_require__(28)).FJS;

	Utils = __webpack_require__(3);

	TypeUtils = __webpack_require__(45);

	FJS = exports.FJS = {};

	FJS["SliderComponent"] = TypeUtils.defineLayerLike("SliderComponent");

	FJS["@SliderComponent"] = sliderComponent = t.object({
	  name: "sliderComponent",
	  ctor: "SliderComponent",
	  xtends: "@Layer",
	  members: {
	    knob: "@Layer",
	    knobSize: t.NUMBER,
	    fill: "@Layer",
	    min: t.NUMBER,
	    max: t.NUMBER,
	    value: t.NUMBER,
	    hitArea: t.NUMBER,
	    constrained: t.BOOLEAN,
	    pointForValue: t.func({
	      params: {
	        value: t.NUMBER
	      },
	      returns: t.NUMBER
	    }),
	    valueForPoint: t.func({
	      params: {
	        point: t.NUMBER
	      },
	      returns: t.NUMBER
	    }),
	    animateToValue: t.func({
	      params: {
	        value: t.NUMBER,
	        animationOptions: "@AnimationOptions"
	      }
	    }),
	    onValueChange: t.func()
	  }
	});

	FJS["@SliderComponentOptions"] = t.options(sliderComponent, Layer["@LayerOptions"]);


/***/ },
/* 38 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Layer, TypeDict, TypeUtils, Utils, rangeSliderComponent, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Layer = (__webpack_require__(28)).FJS;

	Utils = __webpack_require__(3);

	TypeUtils = __webpack_require__(45);

	FJS = exports.FJS = {};

	FJS["RangeSliderComponent"] = TypeUtils.defineLayerLike("RangeSliderComponent");

	FJS["@RangeSliderComponent"] = rangeSliderComponent = t.object({
	  name: "rangeSliderComponent",
	  ctor: "RangeSliderComponent",
	  xtends: "@Layer",
	  members: {
	    minKnob: "@Layer",
	    maxKnob: "@Layer",
	    knobSize: t.NUMBER,
	    fill: "@Layer",
	    min: t.NUMBER,
	    max: t.NUMBER,
	    minValue: t.NUMBER,
	    maxValue: t.NUMBER,
	    hitArea: t.NUMBER,
	    constrained: t.BOOLEAN,
	    pointForValue: t.func({
	      params: {
	        value: t.NUMBER
	      },
	      returns: t.NUMBER
	    }),
	    valueForPoint: t.func({
	      params: {
	        point: t.NUMBER
	      },
	      returns: t.NUMBER
	    }),
	    animateToMinValue: t.func({
	      params: {
	        value: t.NUMBER,
	        animationOptions: "@AnimationOptions"
	      }
	    }),
	    animateToMaxValue: t.func({
	      params: {
	        value: t.NUMBER,
	        animationOptions: "@AnimationOptions"
	      }
	    }),
	    onValueChange: t.func(),
	    onMinValueChange: t.func(),
	    onMaxValueChange: t.func()
	  }
	});

	FJS["@RangeSliderComponentOptions"] = t.options(rangeSliderComponent, Layer["@LayerOptions"]);


/***/ },
/* 39 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, Layer, Obj, ObjMembers, TypeDict, layer, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	Layer = (__webpack_require__(28)).FJS;

	Obj = (__webpack_require__(17)).JS;

	ObjMembers = Object.keys(Obj["@Object"].members).map(function(name) {
	  return name.replace("__reserved__", "");
	});

	FJS = exports.FJS = {};

	layer = Layer["@Layer"];

	FJS["@State"] = t.object({
	  name: "state",
	  xtends: "@NumericalLayerOptions",
	  members: {
	    options: "@AnimationOptions",
	    gradient: "@GradientOptions"
	  },
	  annotations: {
	    asLiteral: true,
	    excludeInherited: ObjMembers
	  }
	});

	FJS["@States"] = t.object({
	  name: "layer.states",
	  asDictOfType: "@State",
	  annotations: {
	    asLiteral: false,
	    excludeInherited: ObjMembers
	  }
	});


/***/ },
/* 40 */
/***/ function(module, exports, __webpack_require__) {

	var FJS, TypeDict, t;

	t = (__webpack_require__(10)).Type;

	TypeDict = (__webpack_require__(44)).TypeDict;

	FJS = exports.FJS = {};

	FJS.Utils = t.object({
	  name: "Utils",
	  members: {
	    modulate: t.func({
	      params: {
	        value: t.NUMBER,
	        a: t.array(t.NUMBER),
	        b: t.array(t.NUMBER),
	        limit: t.BOOLEAN
	      },
	      returns: t.NUMBER
	    }),
	    cycle: t.func({
	      params: {
	        values: t.array
	      }
	    }, t.func()),
	    labelLayer: t.func({
	      params: {
	        layer: "@Layer",
	        text: t.STRING
	      }
	    }),
	    round: t.func({
	      params: {
	        value: t.NUMBER,
	        decimals: t.NUMBER
	      },
	      returns: t.NUMBER
	    }),
	    randomChoice: t.func({
	      params: {
	        values: t.array
	      },
	      returns: t.DYNAMIC
	    }),
	    randomColor: t.func({
	      params: {
	        opacity: t.NUMBER
	      },
	      returns: t.STRING
	    }),
	    randomNumber: t.func({
	      params: {
	        a: t.NUMBER,
	        b: t.NUMBER
	      },
	      returns: t.NUMBER
	    }),
	    randomImage: t.func({
	      params: {
	        size: "@Size"
	      },
	      returns: t.STRING
	    }),
	    delay: t.func({
	      params: {
	        delay: t.NUMBER,
	        handler: t.func()
	      }
	    }),
	    interval: t.func({
	      params: {
	        delay: t.NUMBER,
	        interval: t.func()
	      }
	    }),
	    debounce: t.func({
	      params: {
	        delay: t.NUMBER,
	        interval: t.func()
	      }
	    }),
	    throttle: t.func({
	      params: {
	        delay: t.NUMBER,
	        interval: t.func()
	      }
	    }),
	    isWebKit: t.func({
	      returns: t.BOOLEAN
	    }),
	    isChrome: t.func({
	      returns: t.BOOLEAN
	    }),
	    isSafari: t.func({
	      returns: t.BOOLEAN
	    }),
	    isTouch: t.func({
	      returns: t.BOOLEAN
	    }),
	    isDesktop: t.func({
	      returns: t.BOOLEAN
	    }),
	    isPhone: t.func({
	      returns: t.BOOLEAN
	    }),
	    isTablet: t.func({
	      returns: t.BOOLEAN
	    }),
	    isMobile: t.func({
	      returns: t.BOOLEAN
	    }),
	    domLoadScriptSync: t.func({
	      params: {
	        url: t.STRING
	      }
	    }),
	    frameInset: t.func({
	      params: {
	        frame: "@Frame",
	        inset: t.NUMBER
	      }
	    }),
	    loadWebFont: t.func({
	      params: {
	        font: t.STRING,
	        weight: t.NUMBER
	      },
	      returns: t.object({
	        members: {
	          fontFamily: t.STRING,
	          fontWeight: t.NUMBER
	        }
	      })
	    })
	  }
	});


/***/ },
/* 41 */
/***/ function(module, exports, __webpack_require__) {

	var Scope, Type, TypeDict, Utils;

	Utils = __webpack_require__(3);

	Type = __webpack_require__(10).Type;

	TypeDict = __webpack_require__(44).TypeDict;

	Scope = exports.Scope = (function() {
	  Scope.prototype.OPTIONS = function() {
	    return {
	      parent: void 0,
	      children: [],
	      variables: {},
	      refs: {},
	      warnings: [],
	      location: {}
	    };
	  };

	  function Scope(options) {
	    if (options == null) {
	      options = {};
	    }
	    Utils.merge(options, this.OPTIONS());
	    Utils.extend(this, options);
	  }

	  Scope.prototype.addChildScope = function(location) {
	    var childScope;
	    childScope = new this.constructor({
	      parent: this,
	      location: location
	    });
	    this.children.push(childScope);
	    return childScope;
	  };

	  Scope.prototype.hasVariable = function(id) {
	    return this.variables.hasOwnProperty(id);
	  };

	  Scope.prototype.resolveVariableScope = function(id) {
	    var ref1;
	    if (this.hasVariable(id)) {
	      return this;
	    }
	    return (ref1 = this.parent) != null ? ref1.resolveVariableScope(id) : void 0;
	  };

	  Scope.prototype.addVariable = function(id, type, node) {
	    if (type == null) {
	      type = "?";
	    }
	    this.variables[id] = type;
	    this.refs[id] = {};
	    return this.addRef(id, node);
	  };

	  Scope.prototype.setVariableType = function(id, type, node, shadow, add) {
	    var currentType, scope;
	    if (shadow == null) {
	      shadow = false;
	    }
	    if (add == null) {
	      add = true;
	    }
	    this.addToTypeDict(type);
	    scope = this.resolveVariableScope(id);
	    if (this === scope) {
	      currentType = this.variables[id];
	      if (type === Type.UNKNOWN || type === Type.NULL || type === Type.UNDEFINED) {
	        this.variables[id];
	      } else if (type === Type.DYNAMIC || currentType === Type.UNKNOWN || ((currentType != null) && currentType.toString() === (type != null ? type.toString() : void 0))) {
	        this.variables[id] = type;
	      } else {
	        scope.warnings.push("Variable " + id + " changed type (from " + currentType + " to " + type + ")");
	        this.variables[id] = "*";
	      }
	      this.addRef(id, node);
	      return this.variables[id];
	    } else if (scope && !shadow) {
	      return scope.setVariableType(id, type, node);
	    } else if (add) {
	      return this.addVariable(id, type, node);
	    } else {
	      throw new Error("No such variable found: '" + id + "'");
	    }
	  };

	  Scope.prototype.getVariableType = function(id, node) {
	    var scope, type;
	    scope = this.resolveVariableScope(id);
	    if (this === scope) {
	      type = this.variables[id];
	      if (type != null) {
	        this.addRef(id, node);
	      }
	      return type;
	    } else if (scope) {
	      return scope.getVariableType(id, node);
	    } else {
	      return void 0;
	    }
	  };

	  Scope.prototype.getTypeDict = function() {
	    if (this.parent != null) {
	      return this.parent.getTypeDict();
	    }
	    return this.typeDict != null ? this.typeDict : this.typeDict = new TypeDict;
	  };

	  Scope.prototype.addToTypeDict = function(type) {
	    return this.getTypeDict().add(type);
	  };

	  Scope.prototype.addRef = function(id, node) {
	    var location, ref;
	    if ((node != null) && node.locationData && ((ref = this.refs[id]) != null)) {
	      location = Utils.locationToString(node.locationData);
	      return ref["" + location] = true;
	    }
	  };

	  Scope.prototype.getNewedInstances = function() {
	    var ref1;
	    return ((ref1 = this.parent) != null ? ref1.getNewedInstances() : void 0) || (this.newedInstances != null ? this.newedInstances : this.newedInstances = []);
	  };

	  Scope.prototype.getAnimationReturningFunctions = function() {
	    var ref1;
	    return ((ref1 = this.parent) != null ? ref1.getAnimationReturningFunctions() : void 0) || (this.animationReturningFunctions != null ? this.animationReturningFunctions : this.animationReturningFunctions = []);
	  };

	  Scope.prototype.toInspect = function(indent) {
	    var i, key, lines, padding, ref1, ref2, ref3, result, results, value;
	    if (indent == null) {
	      indent = 0;
	    }
	    lines = [];
	    if (indent) {
	      padding = ((function() {
	        results = [];
	        for (var i = 0, ref1 = indent - 1; 0 <= ref1 ? i <= ref1 : i >= ref1; 0 <= ref1 ? i++ : i--){ results.push(i); }
	        return results;
	      }).apply(this).map(function() {
	        return " ";
	      })).join("");
	    } else {
	      padding = "";
	    }
	    lines.push(Utils.locationToString(this.location));
	    ref2 = this.variables;
	    for (key in ref2) {
	      value = ref2[key];
	      lines.push("  " + key + ": " + value + " " + (value.hash || ''));
	    }
	    result = (lines.map(function(line) {
	      return padding + line;
	    })).concat(this.children.map(function(child) {
	      return child.toInspect(indent + 2);
	    })).join("\n");
	    if (((ref3 = this.warnings) != null ? ref3.length : void 0) > 0) {
	      result += "\n> warnings:\n" + this.warnings.join("\n");
	    }
	    return result;
	  };

	  Scope.prototype.toJSON = function() {
	    var k, key, ref1, ref2, result, v, variable;
	    result = {
	      location: Utils.locationToString(this.location)
	    };
	    if (this.variables && Object.keys(this.variables).length) {
	      result.vars = {};
	      ref1 = this.variables;
	      for (key in ref1) {
	        variable = ref1[key];
	        if ((variable != null ? variable.toJSON : void 0) != null) {
	          result.vars[key] = variable.toJSON(true);
	        } else {
	          result.vars[key] = variable;
	        }
	      }
	    }
	    if (this.children.length > 0) {
	      result.children = this.children.map(function(child) {
	        return child.toJSON();
	      });
	    }
	    if (this.typeDict != null) {
	      result.typeDict = this.typeDict.toJSON();
	    }
	    if (Object.keys(this.refs).length > 0) {
	      result.refs = {};
	      ref2 = this.refs;
	      for (k in ref2) {
	        v = ref2[k];
	        result.refs[k] = Object.keys(v);
	      }
	    }
	    return result;
	  };

	  Scope.prototype.toString = function() {
	    return this.toInspect();
	  };

	  return Scope;

	})();


/***/ },
/* 42 */
/***/ function(module, exports, __webpack_require__) {

	var code, key, lookup, name_pre, nodes, value;

	code = "x=1\nreturn\nx args...\n1+1\n[0..1]\nclass x extends y\n{}\n[1,2,3]\n(x,y...)->\nwhile true then ;\ntry ; catch ;\nif true then;\nswitch x\n    when a then null\n(1)\ntrue\nx.y\nundefined\nnull\nx[1]\nfor i in x\n    ;\n### ###\nx in y\nthrow e\ny[..]\n1?";

	nodes = CoffeeScript.nodes(code);

	lookup = {
	  "Block": nodes.constructor,
	  "Assign": nodes.expressions[0].constructor,
	  "Value": nodes.expressions[0].variable.constructor,
	  "Literal": nodes.expressions[0].variable.base.constructor,
	  "Return": nodes.expressions[1].constructor,
	  "Call": nodes.expressions[2].constructor,
	  "Splat": nodes.expressions[2].args[0].constructor,
	  "Op": nodes.expressions[3].constructor,
	  "Range": nodes.expressions[4].base.constructor,
	  "Class": nodes.expressions[5].constructor,
	  "Obj": nodes.expressions[6].base.constructor,
	  "Arr": nodes.expressions[7].base.constructor,
	  "Code": nodes.expressions[8].constructor,
	  "Param": nodes.expressions[8].params[0].constructor,
	  "While": nodes.expressions[9].constructor,
	  "Try": nodes.expressions[10].constructor,
	  "If": nodes.expressions[11].constructor,
	  "Switch": nodes.expressions[12].constructor,
	  "Parens": nodes.expressions[13].base.constructor,
	  "Bool": nodes.expressions[14].base.constructor,
	  "Access": nodes.expressions[15].properties[0].constructor,
	  "Undefined": nodes.expressions[16].base.constructor,
	  "Null": nodes.expressions[17].base.constructor,
	  "Index": nodes.expressions[18].properties[0].constructor,
	  "For": nodes.expressions[19].constructor,
	  "Comment": nodes.expressions[20].constructor,
	  "In": nodes.expressions[21].constructor,
	  "Throw": nodes.expressions[22].constructor,
	  "Slice": nodes.expressions[23].properties[0].constructor,
	  "Existence": nodes.expressions[24].constructor
	};

	for (key in lookup) {
	  value = lookup[key];
	  name_pre = "$" + (key[0].toLowerCase()) + (key.slice(1));
	  value._name_ = key;
	  value._name_pre_ = name_pre;
	  value._name_post_ = name_pre + "_post";
	}

	exports.nameForNode = function(node) {
	  return node.constructor._name_;
	};

	exports.handlerNameForNode = function(node, post) {
	  if (post) {
	    return node.constructor._name_post_;
	  }
	  return node.constructor._name_pre_;
	};


/***/ },
/* 43 */
/***/ function(module, exports, __webpack_require__) {

	var Info;

	Info = exports.Info = (function() {
	  function Info() {
	    this.whileNodes = [];
	    this.stateNames = {};
	  }

	  Info.prototype.toJSON = function() {
	    var result;
	    result = {};
	    if ((Object.keys(this.stateNames)).length > 0) {
	      result.stateNames = this.stateNames;
	    }
	    return result;
	  };

	  return Info;

	})();


/***/ },
/* 44 */
/***/ function(module, exports, __webpack_require__) {

	var Type, TypeDict, Utils;

	Utils = __webpack_require__(3);

	Type = __webpack_require__(10).Type;

	TypeDict = exports.TypeDict = (function() {
	  function TypeDict() {
	    this.types = {};
	  }

	  TypeDict.prototype.add = function(type) {
	    var hash;
	    if ((type == null) || typeof type === "string") {
	      return type;
	    }
	    hash = Type.getHash(type);
	    if (this.types[hash] == null) {
	      this.types[hash] = type;
	    }
	    return hash;
	  };

	  TypeDict.prototype.get = function(hash) {
	    return this.types[hash];
	  };

	  TypeDict.prototype.toInspect = function() {
	    var key, lines, ref, value;
	    lines = [];
	    ref = this.types;
	    for (key in ref) {
	      value = ref[key];
	      lines.push(key + ": " + value);
	    }
	    return lines.join('\n');
	  };

	  TypeDict.prototype.toJSON = function() {
	    var key, ref, result, value;
	    result = {};
	    ref = this.types;
	    for (key in ref) {
	      value = ref[key];
	      if (value.toJSON != null) {
	        result[key] = value.toJSON();
	      }
	    }
	    return result;
	  };

	  return TypeDict;

	})();


/***/ },
/* 45 */
/***/ function(module, exports, __webpack_require__) {

	var NodesMap, Utils, t;

	t = (__webpack_require__(10)).Type;

	NodesMap = __webpack_require__(42);

	Utils = __webpack_require__(3);

	exports.defineLayerLike = function(name, additionalMembers) {
	  var lowerCaseName;
	  if (additionalMembers == null) {
	    additionalMembers = {};
	  }
	  lowerCaseName = Utils.lowerCaseFirstChar(name);
	  return t.func({
	    name: lowerCaseName,
	    params: {
	      options: "@" + name + "Options"
	    },
	    isConstructor: true,
	    returns: function(node) {
	      var key, location, members, tLayer, tStates, value;
	      members = {};
	      for (key in additionalMembers) {
	        value = additionalMembers[key];
	        members[key] = value;
	      }
	      tStates = t.object({
	        name: lowerCaseName + ".states",
	        aliasOf: "@States"
	      });
	      members.states = tStates;
	      location = node.locationData.first_line + ":" + node.locationData.first_column + ")";
	      if (NodesMap.nameForNode(node) === "Op") {
	        location = node.first.locationData.first_line + ":" + node.first.locationData.first_column + ")";
	      }
	      tLayer = t.object({
	        name: lowerCaseName,
	        aliasOf: "@" + name,
	        dynamic: false,
	        annotations: {
	          location: location
	        },
	        members: members
	      });
	      tStates.getHash = function() {
	        return (tLayer.getHash()) + ";@States";
	      };
	      return tLayer;
	    }
	  });
	};


/***/ }
/******/ ]);