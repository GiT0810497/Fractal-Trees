#!/bin/sh
inliner -m https://login.framer.cloud/tutorial/ > tutorial.html
