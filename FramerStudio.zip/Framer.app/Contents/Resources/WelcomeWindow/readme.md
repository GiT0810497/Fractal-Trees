We actually use the inline version here for speed:
https://github.com/remy/inliner

- npm install -g inliner
- `inliner index.html > index.inline.html`