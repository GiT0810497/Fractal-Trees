#!/bin/sh
inliner -m https://login.framer.cloud/offline/ > offline.html