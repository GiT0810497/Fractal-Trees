
### Objective C

CDEvents MIT https://github.com/rastersize/CDEvents
Reachability MIT https://github.com/tonymillion/Reachability
AFNetworking MIT https://github.com/AFNetworking/AFNetworking
BFColorPickerPopover BSD https://github.com/DrummerB/BFColorPickerPopover
GRMustache MIT https://github.com/groue/GRMustache
FileMD5Hash Apache https://github.com/JoeKun/FileMD5Hash
WFColorCode MIT https://github.com/1024jp/WFColorCode
Mixpanel Apache https://github.com/orta/mixpanel-osx-unofficial
Sparkle MIT https://github.com/DevMate/Sparkle

### C

jaro_winkler MIT https://github.com/tonytonyjan/jaro_winkler

### Swift

Quick Apache https://github.com/Quick/Quick
Nimble Apache https://github.com/Quick/Nimble

### JavaScript

CoffeeScript MIT http://coffeescript.org
Framer MIT https://framer.com
FramerPS MIT https://github.com/koenbok/FramerPS
node-photoshop MIT https://github.com/subtleGradient/node-photoshop
V8 BSD https://developers.google.com/v8/

### Python

Tornado Apache https://github.com/tornadoweb/tornado
WatchDog Apache https://pypi.python.org/pypi/watchdog
netifaces MIT https://pypi.python.org/pypi/netifaces
MacFSEvents BSD https://pypi.python.org/pypi/MacFSEvents

### Fonts

Roboto Mono Apache https://www.google.com/fonts/specimen/Roboto+Mono

### Sounds, Devices and Hands artwork

Facebook Design https://facebook.github.io/design/
